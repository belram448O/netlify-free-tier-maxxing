# example.com — Subdomain Replication Recipe

> **Companion docs**: `KIT.md` (generalized playbook), `ARCHITECTURE.md` (current state), `CODEBASE.md` (script reference), `FLEET.md` (multi-pod scaling)

## TL;DR

To add a new subdomain (e.g., `status.example.com`):

```bash
# Edit scripts/22_stamp_all_subdomains.py
# Add this line to ALL_SUBDOMAINS:
#   ("status", "placeholder", False)
# Then run:
python3 scripts/22_stamp_all_subdomains.py
```

Done. The script creates the Netlify DNS zone, adds 7 DNS records (A, CNAME, SPF, DMARC, MTA-STS, 2 CAA), and adds 4 NS delegation records in the CF MAIN root zone.

Verify after 5-15 min:
```bash
dig +short NS status.example.com @1.1.1.1
# Should return 4 NS1 servers
```

## Current per-subdomain state

| Subdomain | Netlify Zone ID | NS1 Pool | Hosting | Email |
|---|---|---|---|---|
| `users.example.com` | `<your-netlify-zone-id>` | p07 | A placeholder (TBD) | TBD (ImprovMX) |
| `app.example.com` | `<your-netlify-zone-id>` | p01 | A placeholder (TBD) | — |
| `content.example.com` | `<your-netlify-zone-id>` | p07 | A placeholder (TBD) | — |
| `corp.example.com` | `<your-netlify-zone-id>` | p05 | A placeholder (TBD) | TBD (ImprovMX) |
| `api.example.com` | `<your-netlify-zone-id>` | p09 | A placeholder (TBD) | — |
| `cdn.example.com` | `<your-netlify-zone-id>` | p08 | A placeholder (TBD) | — |

(TBD hosting means the A record currently points to `192.0.2.1` placeholder. To wire up hosting, see "Hosting decision" below.)

## What gets created per subdomain

When you stamp out a new subdomain via `scripts/22_stamp_all_subdomains.py`, you get:

### Netlify DNS zone (per subdomain)
- Zone name: `<sub>.example.com`
- 4 NS records assigned by Netlify (different NS1 pools per zone for distribution)
- Zone ID saved to `state.json`

### DNS records inside the zone (7 records)
```
A      <sub>.example.com         192.0.2.1            (placeholder)
CNAME  www.<sub>.example.com     <sub>.example.com
TXT    <sub>.example.com         v=spf1 include:_spf.mx.cloudflare.net ~all
TXT    _dmarc.<sub>.example.com  v=DMARC1; p=quarantine; rua=mailto:admin@example.com; ...
TXT    _mta-sts.<sub>.example.com v=STSv1; id=20260815T000000
CAA    <sub>.example.com         0 issue "letsencrypt.org"
CAA    <sub>.example.com         0 issue "cloudflare.com"
```

### NS delegation in CF MAIN root zone (4 records)
```
NS  <sub>.example.com   dns1.pXX.nsone.net    (DNS-only)
NS  <sub>.example.com   dns2.pXX.nsone.net    (DNS-only)
NS  <sub>.example.com   dns3.pXX.nsone.net    (DNS-only)
NS  <sub>.example.com   dns4.pXX.nsone.net    (DNS-only)
```

### DMARC record in CF root zone (1 record)
```
TXT  _dmarc.<sub>.example.com  v=DMARC1; p=quarantine; rua=mailto:admin@example.com; ...
```

This is for visibility — some DMARC reporters query the parent zone.

## Hosting decision (per subdomain)

After the zone is created, pick a hosting pattern by replacing the A record:

### Pattern A: CF Worker (recommended for app/users/corp/api)
1. Deploy the Worker to CF MAIN account
2. In the Netlify sub-zone, replace the A record with a CNAME:
   ```
   CNAME  <sub>.example.com → <worker>.<acct>.workers.dev
   ```
3. Or use CF for SaaS to bind the hostname directly to the Worker (more advanced)

### Pattern B: Vercel (like docs/blog)
1. Create Vercel project + attach domain (use `scripts/08_setup_vercel.py` + `10_attach_vercel_domains.py` as templates)
2. In the Netlify sub-zone, replace the A record:
   ```
   CNAME  <sub>.example.com → cname.vercel-dns.com
   ```
3. Vercel auto-issues SSL (5-15 min)

### Pattern C: Netlify Functions
1. Create Netlify site + deploy
2. In the Netlify sub-zone, replace the A record:
   ```
   CNAME  <sub>.example.com → <site>.netlify.app
   ```

### Pattern D: Third-party SaaS (like help)
1. Sign up at vendor
2. In the Netlify sub-zone, replace the A record:
   ```
   CNAME  <sub>.example.com → <vendor-hostname>
   ```
3. Add any vendor-specific records (TXT verification, CAA, etc.)

### Pattern E: R2 bucket for cdn.*
1. Create R2 bucket + enable public access
2. In the Netlify sub-zone, replace the A record:
   ```
   CNAME  cdn.example.com → <bucket>.r2.dev
   ```

## Email routing decision (only for users.* and corp.*)

Sub-zones are on Netlify DNS, so CF Email Routing doesn't apply. Options:

### Option 1: ImprovMX (recommended — free, 25 aliases)
1. Sign up at https://improvmx.com (web, 2 min)
2. Generate API key at https://app.improvmx.com/account/api/
3. Save to `secrets.json`: `"improvmx_api_key": "<key>"`
4. Run `python3 scripts/23_setup_improvmx.py`

The script adds the domain to ImprovMX, sets catch-all aliases, updates MX records in the Netlify sub-zone:
```
MX  <sub>.example.com  mx1.improvmx.com  (priority 10)
MX  <sub>.example.com  mx2.improvmx.com  (priority 20)
TXT <sub>.example.com  v=spf1 include:spf.improvmx.com ~all  (replaces existing SPF)
```

### Option 2: AWS SES (production-grade, paid)
Out of scope for this runbook — see AWS SES docs.

### Option 3: Skip email entirely
Default state. The MX records stay empty, email to `*@<sub>.example.com` bounces.

## Kill-switch runbook (per subdomain)

If a subdomain's DNS zone is compromised:

1. **Revoke Netlify token**: https://app.netlify.com/user/applications
2. **Delete the compromised Netlify DNS zone**:
   ```bash
   curl -X DELETE "https://api.netlify.com/api/v1/dns_zones/<zone_id>" \
     -H "Authorization: Bearer $NETLIFY_TOKEN"
   ```
3. **Delete NS delegation records in CF root zone**:
   ```bash
   for rid in $(curl -sS "https://api.cloudflare.com/client/v4/zones/<root_zone_id>/dns_records?type=NS&name=<sub>.example.com" -H "Authorization: Bearer $CF_TOKEN" | jq -r '.result[].id'); do
     curl -X DELETE "https://api.cloudflare.com/client/v4/zones/<root_zone_id>/dns_records/$rid" -H "Authorization: Bearer $CF_TOKEN"
   done
   ```
4. **Re-create** a fresh Netlify DNS zone + NS delegation (add the sub to `ALL_SUBDOMAINS` in `scripts/22_stamp_all_subdomains.py` and re-run)
5. **Audit** the previous zone's audit logs

## Migration path (if you later upgrade to CF Enterprise)

If you eventually upgrade to CF Enterprise + get the "Subdomain Support" entitlement:

1. For each subdomain, create a CF sub-zone via API (the same `POST /zones` call we tried before, which now succeeds)
2. Move all DNS records from the Netlify zone to the CF sub-zone
3. Update NS records in CF MAIN root zone to point to CF-assigned NS (instead of NS1)
4. Delete the Netlify DNS zone

This gives you native CF Workers + Email Routing + KV + R2 + D1 per subdomain — the original D2 design.

The scripts in this repo will work as-is for this migration; just need to swap Netlify API calls for CF API calls.
