# Custom Domain Kit — Generalized Playbook

> **Status**: Generalized reference. Apply this pattern to ANY custom domain.
> **example.com** is the worked example — see `ARCHITECTURE.md` for its specific state.

This document captures the abstract pattern, applicable to any custom domain that needs:
- Multi-account isolation (billing / risk / access / TOS)
- Per-subdomain or per-region sharding
- Free-tier scaling
- Email forwarding
- Third-party SaaS integration

## When to use this kit

You want this kit if you answer "yes" to any of these:

- I want each subdomain (or each regional pod) to have its own account at the hosting provider, for billing/risk/access isolation
- I want to scale by adding more free-tier accounts (linear cost), not by upgrading one account to paid (exponential cost)
- I want per-subdomain or per-region WAF, rate-limiting, and audit logs
- I want to keep my apex domain on one provider (for TOS or strategic reasons) while distributing traffic across other providers
- I'm using Cloudflare at the root and want per-subdomain isolation without paying $200+/mo for Enterprise

You should NOT use this kit if:
- You have a single hosting provider and don't need isolation — just put everything in one account
- You're already on Cloudflare Enterprise — use CF's native subdomain zone feature instead (see `PIVOT.md`)
- You don't care about free-tier limits — pay for Pro/Enterprise everywhere and use native features

## The pattern in one diagram

```
                ┌────────────────────────────┐
                │ Registrar (Spaceship,      │
                │   Namecheap, Porkbun, etc)│
                │   Domain: example.com     │
                │   NS → Provider A          │
                └────────────┬───────────────┘
                             │
              ┌──────────────▼─────────────────┐
              │ Provider A — apex DNS zone    │
              │ (Free tier: Netlify or CF)     │
              │                                │
              │ A      example.com  → site    │
              │ CNAME  www          → apex    │
              │ NS     sub1         → Prov B  │ ← per-subdomain isolation
              │ NS     sub2         → Prov B  │
              │ CNAME  docs         → Vercel  │
              │ CNAME  blog         → Vercel  │
              └──┬────────────┬───────────────┘
                 │            │
        NS del.  │            │ NS del.
                 ▼            ▼
   ┌──────────────────┐  ┌──────────────────┐
   │ Provider B       │  │ Provider B       │
   │ zone sub1.ex.com │  │ zone sub2.ex.com │
   │ (own account)    │  │ (own account)    │
   └──────────────────┘  └──────────────────┘
```

**Key idea**: Use NS delegation to give each subdomain its own DNS zone in its own account. The apex zone handles the root + a few static subdomains; everything else gets delegated.

## The 5 core decisions

### Decision 1: Where does the apex DNS zone live?

| Option | Pros | Cons | When |
|---|---|---|---|
| Cloudflare | Free WAF, edge, Workers, KV, R2, Email Routing native | Section 2.8 historically risky (removed in 2026) | When you want maximum features at apex |
| Netlify | 100GB free bandwidth, commercial use OK, _redirects native | No WAF | When apex is mostly static + redirect logic |
| AWS Route 53 | Industry standard, geo-routing | $0.50/zone/mo + per-query cost | Avoid for free-tier goal |
| Vercel | Simple | No subdomain zones; no DNS API for sub-zones | Avoid |

**Recommendation**: Netlify for apex (TOS-safe, free 100GB), or Cloudflare if you want WAF at apex. Both free.

### Decision 2: Where do per-subdomain zones live?

| Option | Subdomain zone support on free tier? | Per-zone WAF? |
|---|---|---|
| Netlify DNS zones | ✅ Yes — `POST /api/v1/dns_zones` | ❌ No WAF |
| Cloudflare subdomain zones | ❌ Enterprise-only ($5K+/mo) | ✅ Yes (per zone) |
| AWS Route 53 | ✅ Yes ($0.50/zone/mo) | ❌ No |
| Vercel | ❌ No standalone subdomain zones | ❌ No |

**Recommendation**: Netlify DNS zones (free, first-class standalone subdomain support).

**Alternative**: If you MUST have per-zone WAF on each subdomain, use **Cloudflare per-pod accounts** — each pod is its own CF account with NS delegation from the apex zone. This is the "fleet" pattern; see `FLEET.md`.

### Decision 3: How is the apex hosted?

| Pattern | Free tier | TOS-safe for commercial | Geo-routing |
|---|---|---|---|
| Static site on Netlify | 100GB BW | ✅ | _redirects Country= rules |
| CF Worker | 100K req/day | ✅ (in 2026) | request.cf.colo |
| Vercel Next.js | 100GB BW | ⚠️ Hobby prohibits commercial | No native geo |
| AWS S3+CloudFront | 1GB egress/mo (12mo) | ✅ | CloudFront geo |

**Recommendation**: Static HTML on Netlify (TOS-safe, free 100GB). Use CF Worker only if apex needs server-side logic.

### Decision 4: How is each subdomain hosted?

| Pattern | Use for | Cost |
|---|---|---|
| CF Worker (own CF account per pod) | APIs, edge compute, regional pods | $0 to 100K req/day, then $5/mo |
| Vercel SSR | Docs/blog (non-commercial) | $0 (Hobby) or $20/mo (Pro) |
| Netlify Functions | Serverless functions | $0 to 125K invocations |
| AWS Lambda | Backend APIs | $0 to 1M req/mo (12mo) |
| Third-party SaaS CNAME | Help desk, status page | Varies |

**Recommendation**: CF Worker per pod (TOS-safe for commercial, free to 100K req/day). Vercel only for non-commercial surfaces.

### Decision 5: How is email handled?

| Pattern | Where it works | Cost |
|---|---|---|
| CF Email Routing | Apex zone only (must be on CF) | Free, 200 dest, 3K outbound/mo |
| ImprovMX | Any zone (just set MX) | Free, 25 aliases, 500 emails/day |
| AWS SES | Any zone | $0.10/1K emails |
| Forward Email | Any zone | Free, unlimited aliases (OSS) |

**Recommendation**: CF Email Routing for apex (free, native). ImprovMX for sub-zones (free, MX-based).

## The 7 implementation steps (generalized)

### Step 1: Procure domain + verify registrar API access

Pick a registrar with a public API. Options that work:
- **Spaceship** — `https://spaceship.dev/api`, X-Api-Key/Secret auth, full domain + DNS management
- **Porkbun** — has API for domain management but limited DNS
- **Namecheap** — has API but rate-limited
- **Cloudflare Registrar** — at-cost registration, full API integration with CF zones

Verify API access with a simple `GET /domains/{domain}` call before proceeding.

### Step 2: Create apex DNS zone at chosen provider

If Netlify:
```bash
curl -X POST "https://api.netlify.com/api/v1/dns_zones" \
  -H "Authorization: Bearer $NETLIFY_TOKEN" \
  -d '{"name":"example.com","account_id":"<acct>"}'
# Returns: {id, dns_servers: [dns1.p0X.nsone.net, ...]}
```

If Cloudflare:
```bash
curl -X POST "https://api.cloudflare.com/client/v4/zones" \
  -H "Authorization: Bearer $CF_TOKEN" \
  -d '{"name":"example.com","account":{"id":"<acct>"},"type":"full"}'
# Returns: {id, name_servers: [<name1>.ns.cloudflare.com, <name2>.ns.cloudflare.com]}
```

### Step 3: Migrate NS at registrar

For Spaceship:
```bash
curl -X PUT "https://spaceship.dev/api/v1/domains/example.com/nameservers" \
  -H "X-Api-Key: $SP_KEY" -H "X-Api-Secret: $SP_SECRET" \
  -H "Content-Type: application/json" \
  -d '{"provider":"custom","hosts":["<ns1>","<ns2>"]}'
```

For other registrars, use their NS-update endpoint. Wait 5-30 min for propagation.

Verify via `dig +short NS example.com @1.1.1.1`.

### Step 4: Configure apex DNS records

Minimum viable set:
- A record (apex) → hosting target (Netlify site, CF Worker proxy IP, etc.)
- CNAME www → apex
- TXT SPF (if email)
- TXT DMARC (if email): `_dmarc.example.com`
- CAA (defensive): restrict cert issuance

Add more as needed for third-party services:
- CNAME docs → cname.vercel-dns.com (Vercel)
- CNAME help → vendor.helpscoutdocs.com (HelpScout)
- MX → email forwarder (ImprovMX, CF Email Routing, etc.)

### Step 5: Create per-subdomain DNS zones

For each subdomain that needs isolation:
```bash
curl -X POST "https://api.netlify.com/api/v1/dns_zones" \
  -H "Authorization: Bearer $NETLIFY_TOKEN" \
  -d '{"name":"users.example.com","account_id":"<acct>"}'
```

For each zone, add the standard record set (7 records):
- A apex → 192.0.2.1 (placeholder)
- CNAME www → apex
- TXT apex → SPF
- TXT _dmarc → DMARC
- TXT _mta-sts → MTA-STS
- CAA × 2 → cert restrictions

### Step 6: Add NS delegation in apex zone

For each sub-zone, add NS records in the apex zone:
```bash
curl -X POST "https://api.cloudflare.com/client/v4/zones/<zone>/dns_records" \
  -H "Authorization: Bearer $CF_TOKEN" \
  -d '{"type":"NS","name":"users.example.com","content":"dns1.p0X.nsone.net","ttl":1,"proxied":false}'
# × 4 (one per assigned NS)
```

Verify via `dig +short NS users.example.com @1.1.1.1` — should return the sub-zone's NS.

### Step 7: Wire up hosting per subdomain

Per `FLEET.md`'s hosting decision tree. Common patterns:

**Static site / docs / blog**:
- Vercel project + attach domain → CNAME in sub-zone → cname.vercel-dns.com

**Worker / API / edge compute**:
- CF Worker deploy + Worker Route → A record in sub-zone → 192.0.2.1 proxied via CF
- OR: CF Worker in own CF account + NS delegation to that account (true per-pod isolation)

**Third-party SaaS**:
- CNAME in sub-zone → vendor hostname (e.g., `youracct.zendesk.com`)
- Add vendor-specific records (TXT verification, CAA for vendor cert)

## Free-tier budget reference (per pod, per service)

| Service | Free limit | Hard stop behavior | Upgrade cost |
|---|---|---|---|
| **CF Workers** | 100K req/day, 10ms CPU, 1GB KV, 10GB R2 | 5xx responses | $5/mo for 10M req/mo |
| **CF Pages** | 500 builds/mo, unlimited static | Build queue stops | $20/mo (Pro) |
| **CF Email Routing** | 200 dest, 200 rules, 3K outbound/mo | Hard stop | Free always |
| **Vercel Hobby** | 100GB BW, 1M invocations, 4 CPU-hrs, 100 deploys/day | Hard stop + email warning | $20/user/mo (Pro) |
| **Vercel Hobby TOS** | ⚠️ Non-commercial use only | Account suspension | $20/user/mo (Pro) |
| **Supabase** | 500MB DB, 5GB egress, 50K MAU, 7-day-inactivity pause | Auto-pause | $25/mo (Pro) |
| **Neon** | 100 CU-hrs, 0.5GB storage, scale-to-zero after 5 min | Auto-suspend at limit | $19/mo (Launch) |
| **Netlify** | 100GB BW, 300 build mins, 125K function calls, 1M edge fn calls | Hard stop (no overage) | $19/mo (Pro) |
| **ImprovMX** | 1 domain, 25 aliases, 500 emails/day | Hard stop | $9/mo (Premium) |

## Critical TOS findings (verified 2026-08-15)

These materially affect architecture decisions. Verify each periodically as ToS changes.

### Cloudflare
- ✅ Section 2.8 "non-HTML content" ban: **REMOVED** in 2026 TOS. JSON API proxy on Workers is now safe.
- ✅ Multiple CF accounts per person: **allowed**. Use different emails per account.
- ✅ Commercial use on free tier: **allowed**. Workers are the "Developer Platform" — sanctioned for production.
- ❌ **Subdomain zones (separate zone for `sub.example.com`)**: Enterprise-only ($5K+/mo).
- ❌ Partial/CNAME setup (sub-zone without NS delegation): Business-only ($200/mo).

### Netlify
- ✅ Multiple free accounts per person: **allowed**. No "one account per entity" clause.
- ✅ Commercial use on free tier: **allowed** within usage limits.
- ✅ Off-site 302 redirects: **allowed**. No restriction in AUP.
- ✅ Multi-tenant SaaS on free: **allowed**. No TOS prohibition.
- ⚠️ Free accounts can be terminated by Netlify "without cause, immediately upon notice."

### Vercel
- ⚠️ **Hobby tier: NON-COMMERCIAL USE ONLY**. ToS prohibits revenue-touching deployments.
- ⚠️ Multiple Hobby teams per Vercel login: **not allowed** (one login per third-party service).
- ⚠️ Exceeding limits: 48h grace, then suspension (no overage billing without consent).
- ✅ Pro tier ($20/user/mo): commercial use allowed.

### Supabase
- ✅ Multiple free accounts per person: **allowed** (standard workaround for 2-project limit).
- ✅ No "one account per entity" clause.
- ⚠️ Free projects auto-pause after 7 days of API inactivity (~30s cold start to unpause).
- ✅ Upgrade to Pro ($25/mo) lifts all limits.

### Neon
- ✅ Multiple free projects per account: **allowed** (within compute-hours budget).
- ✅ Each project gets its own 100 CU-hours + 0.5GB storage.
- ⚠️ Scale-to-zero after 5 min idle (~300ms cold start to wake).
- ✅ Upgrade to Launch ($19/mo) for more storage/compute.

### GitHub
- ❌ **"One person or legal entity may maintain no more than one free Account."**
- Workaround: ONE GitHub account + multiple repos + per-repo deploy tokens.
- Alternative: GitLab free for secondary repos, or Bitbucket.

### Spaceship
- ✅ Multiple free accounts: no documented restriction.
- ✅ API at `https://spaceship.dev/api` (NOT `api.spaceship.net` — that hostname refuses TCP 443 globally).
- ✅ Auth: `X-Api-Key` + `X-Api-Secret` headers (NOT Basic auth).

## Decision matrix — pick the right mix for your project

| Goal | Recommended mix |
|---|---|
| Single landing + 1 product | Apex on Netlify + CF Worker for product + Vercel Hobby for docs |
| Multi-tenant SaaS, ≤5 pods | Apex on Netlify + per-pod CF account + Supabase per pod |
| Multi-tenant SaaS, 5-30 pods | Above + Doppler for secrets + per-region Supabase/Neon sharding |
| Multi-tenant SaaS, 30+ pods | Migrate router to paid CF Worker ($5/mo) + Netlify Pro for apex ($19/mo) + Workers for Platforms ($25/mo) at hyperscale |
| Docs + blog only | Apex on Netlify + 2 Vercel Hobby projects (non-commercial) |
| E-commerce site | Apex on Netlify + CF Worker for backend (commercial-safe) + Shopify for storefront |
| Internal corporate tools | Apex on Netlify + per-team Netlify sub-zones + Cloudflare Access for auth |

## What you CANNOT automate (truly manual)

These items require human action — no API exists for them:

1. **Account creation** at any provider (CF, Netlify, Vercel, Supabase, Neon, GitHub) — all require email verification + web signup
2. **2FA setup** at any provider — most don't expose 2FA enforcement via API (CF is an exception: `enforce_twofactor: true` can be set via `PUT /accounts/{id}` with an admin token)
3. **Email Routing destination verification** (CF) — destination inbox must click a CSRF-bound link
4. **ImprovMX signup** — web form only, no account-creation API
5. **Master token rotation** at any provider — must be done via dashboard
6. **DNSSEC DS record at registrar** — some registrars don't expose DS record management via API

## What you CAN automate (everything else)

- NS migration at registrar (via registrar API)
- Apex zone creation + DNS records + Worker deployment
- Per-subdomain zone creation (Netlify `POST /dns_zones`)
- NS delegation records in apex zone
- Vercel project creation + domain attachment + production deploys
- Email Routing enablement + catch-all rules (CF, apex zone only)
- 2FA enforcement on CF accounts (via admin token + `PUT /accounts/{id}`)
- DMARC/MTA-STS/CAA record creation on all zones
- End-to-end verification (via dig + curl)
- Backup to GitHub (via Contents API)
- Per-pod provisioning after manual account creation

## Reusability checklist — applying this kit to a new domain

- [ ] Pick registrar (with API support)
- [ ] Pick apex DNS provider (Netlify or CF)
- [ ] Pick per-subdomain DNS provider (Netlify DNS zones recommended)
- [ ] Pick hosting pattern per subdomain (CF Worker, Vercel, Netlify, SaaS)
- [ ] Pick email routing pattern (CF Email Routing for apex, ImprovMX for sub-zones)
- [ ] Copy `infra/secrets.json.example` → `secrets.json`, fill in real creds
- [ ] Edit `scripts/22_stamp_all_subdomains.py` → update `ALL_SUBDOMAINS` list
- [ ] Edit `scripts/06_configure_root_zone.py` → update WORKER_SCRIPT
- [ ] Run scripts in order (see `README.md` "Scripts in execution order")
- [ ] Run `20_final_verify.py` to confirm health
- [ ] Archive to private GH repo via `14_archive_to_gh.py`

## Cost projection (generalized)

For N pods across M regions, fully free:
- N CF accounts × $0 = $0/mo
- N Supabase projects × $0 = $0/mo
- N Vercel teams × $0 = $0/mo (non-commercial)
- 1 apex Netlify × $0 (100GB BW)
- **Total: $0/mo until limits hit**

When limits hit per pod:
- 1 hot pod → upgrade that pod only → $5-25/mo per hot pod
- 5 hot pods simultaneously → $25-125/mo total
- Compare: single-account scale-up at 100M req/mo → $35+/mo just for CF Workers paid

**Linear cost scaling** beats single-account at moderate scale; loses edge at hyperscale (>1B req/mo) where Workers for Platforms ($25/mo + $0.30/M req) wins.

## References

- Worked example: `ARCHITECTURE.md` (example.com live state)
- Multi-pod scaling: `FLEET.md` (example.com future)
- Subdomain stamp-out: `REPLICATE.md` (example.com ops)
- Security + tokens: `SECURITY.md` (example.com secrets)
- Pitfalls + gotchas: `LESSONS.md` (generalized)
- Script reference: `CODEBASE.md` (every script explained)
- History: `PIVOT.md` + `worklog.md` (why we made each choice)
