# example.com — Security Handoff

## TL;DR

**Mostly automated. Three truly-manual items remain — all listed at the bottom.**

## Secrets inventory

Stored in `infra/secrets.json` (mode 0600, gitignored). NEVER commit.

| Key | Type | Purpose | Rotation schedule | Method |
|---|---|---|---|---|
| `cf_main_token` (cfat_) | CF Account API Token (master) | Mints scoped tokens for CF MAIN | **One-time — revoke after handoff** | CF dashboard |
| `cf_sub_token` (cfat_) | CF Account API Token (master) | Mints scoped tokens for CF SUB | **One-time — revoke after handoff** | CF dashboard |
| `cf_main_zone_scoped_token` (cfut_) | CF Zone-scoped token | Zone-read only (user-supplied) | Every 90 days | CF dashboard |
| `root_zone_token` (cfat_) | CF Scoped token (minted) | Daily ops on root zone (DNS, Worker, Email Routing) | Every 90 days | `scripts/03_mint_scoped_tokens.py` |
| `admin_token` (cfat_) | CF Scoped token (minted) | Account Settings + Members + 2FA enforcement | Every 90 days | `scripts/21_mint_admin_token.py` |
| `spaceship_key` / `spaceship_secret` | Spaceship API key/secret | Registrar API (NS migration, domain info) | Every 6 months | Spaceship dashboard |
| `netlify_token` (nfp_) | Netlify PAT | Netlify API (DNS zones, deploys) | Every 90 days | Netlify dashboard |
| `vercel_token` (vcp_) | Vercel PAT | Vercel API (projects, deployments) | Every 90 days | Vercel dashboard |
| `gh_primary_token` (ghp_) | GitHub PAT (classic) | Backup repo under `your-backup-user` | Every 90 days | GitHub dashboard |
| `gh_secondary_token` (ghp_) | GitHub PAT (classic) | site artifact repos under `your-site-artifacts-user` | Every 90 days | GitHub dashboard |
| `scrape_api_key` (nfp_) | Netlify PAT (scraper site) | For scrape proxy (unused now — Spaceship real API works directly) | N/A | N/A |
| `zenrows_pat` | ZenRows PAT | For browser-based scraping (unused) | N/A | N/A |
| `improvmx_api_key` *(user-supplied)* | ImprovMX API key | Email forwarding for users.*/corp.* | Every 90 days | ImprovMX dashboard |

## 2FA enforcement

### CF MAIN account
- **Status**: ✅ enabled (`enforce_twofactor: true`)
- Set via API call (`scripts/21_mint_admin_token.py` mints the admin token; the API call to `PUT /accounts/{id}` sets the flag)
- This means: any user added to the account must have 2FA enabled on their CF profile before they can access the account

### CF SUB account (Admin@example.com)
- **Status**: ⚠️ Not enforced — this account is now empty (we pivoted away from CF subdomain zones to Netlify). Recommend deleting this account entirely if you won't use it.

### Netlify account
- **Status**: ⚠️ Manual — Netlify does not expose 2FA enforcement via API. User must enable in dashboard:
  - https://app.netlify.com/user/security#two-factor-authentication

### Vercel team (SCLD)
- **Status**: ⚠️ Manual — Vercel does not expose 2FA enforcement via API for the team. User must enable:
  - https://vercel.com/account/security

### GitHub accounts
- **Status**: ⚠️ Manual — enable 2FA at https://github.com/settings/security for both `your-backup-user` and `your-site-artifacts-user`

## Token rotation procedure

### Rotate CF scoped tokens (every 90 days)

```bash
# Re-mint scoped token
python3 scripts/03_mint_scoped_tokens.py

# Re-mint admin token (with Account Settings Write)
python3 scripts/21_mint_admin_token.py

# Old tokens are still valid until revoked — revoke via CF dashboard:
# https://dash.cloudflare.com/profile/api-tokens
# Find tokens named "example-root-ops" / "example-admin-ops" → Delete
```

### Rotate CF master tokens (after handoff)

**Status**: TRULY MANUAL — Cloudflare API blocks sub-tokens (tokens minted by account API tokens) from having "Account API Tokens:Write" permission. Confirmed via Wave 2 review: returns `400 sub-token is not allowed to have permissions to manage other tokens`. The `scripts/33_rotate_master_tokens.py` script attempted this and failed — kept as documentation of the limitation.

Once you've confirmed scoped tokens work for daily ops:

1. Log into https://dash.cloudflare.com with `your-cf-main-account@example.com`
2. Go to **My Profile → API Tokens**
3. Find tokens named `your-cf-main-account@example.com's Account` (the master `cfat_` token — see `secrets.json` for value)
4. Click **Delete**
5. Repeat for `Admin@example.com` account (the master `cfat_` token — see `secrets.json`)
6. Remove `cf_main_token` + `cf_sub_token` keys from `secrets.json`

After this, future scoped-token rotation must be done via dashboard (since masters are gone):
1. CF dashboard → My Profile → API Tokens → Create Token
2. Use the "Custom Token" template
3. Permissions needed: see `scripts/03_mint_scoped_tokens.py` for the canonical list

**Wave 2 P0 status**: As of 2026-08-16, the original CF master tokens (see `infra/secrets.json` keys `cf_main_token` and `cf_sub_token` for current values — both start with `cfat_`) are STILL ACTIVE because rotation cannot be automated. The scripts no longer contain them in plaintext (Wave 1 scrubbed), and the GH repo no longer contains them in current file versions — but old commits in GH history still do. **Operator MUST complete these manual steps**:
1. Revoke both CF master tokens via dashboard
2. Revoke Spaceship key+secret at https://www.spaceship.com/application/api-manager/
3. Revoke Netlify PAT at https://app.netlify.com/user/applications
4. Revoke Vercel PAT at https://vercel.com/account/tokens
5. Revoke GitHub PATs at https://github.com/settings/tokens (both accounts)
6. Mint fresh credentials at each provider, update `infra/secrets.json`
7. Delete + recreate the GH repo `your-backup-user/domain-infra-kit` to scrub commit history (Contents API cannot rewrite history)
8. Re-upload via `python3 scripts/14_archive_to_gh.py`

### Rotate Netlify / Vercel / GitHub tokens

All require dashboard access — cannot be done via API:
- Netlify: https://app.netlify.com/user/applications
- Vercel: https://vercel.com/account/tokens
- GitHub: https://github.com/settings/tokens

After rotating, update `secrets.json` with new values.

### Rotate Spaceship API key

Every 6 months:
1. https://www.spaceship.com/application/api-manager/
2. Delete old key
3. Create new key
4. Update `secrets.json`

## Email Routing destination verification

The CF Email Routing catch-all rule forwards `*@example.com → admin@example.com`. **CF requires verifying that you own the destination inbox.**

Cannot be automated:
- CF sends a verification email with a unique token-bound link
- Link has CSRF protection — cannot be auto-clicked
- Even with IMAP access to read the email, clicking the link requires browser session

**Action required**: Check inbox of `admin@example.com`, find the email from Cloudflare, click the verification link.

If `admin@example.com` is forwarded to another mailbox (e.g., Gmail), check that mailbox.

## Email forwarding for users.* and corp.*

CF Email Routing is zone-level — works on `example.com` apex but NOT on sub-zones (which are on Netlify DNS). For users.* and corp.* email forwarding, use ImprovMX (free) or AWS SES (paid).

**ImprovMX setup (one-time, ~5 min)**:
1. Sign up at https://improvmx.com (web form, no API)
2. Generate API key at https://app.improvmx.com/account/api/
3. Save to `secrets.json`: `"improvmx_api_key": "<key>"`
4. Run: `python3 scripts/23_setup_improvmx.py`

The script will:
- Add `users.example.com` and `corp.example.com` to ImprovMX
- Set catch-all aliases: `*@users.example.com → admin+users@example.com`, `*@corp.example.com → admin+corp@example.com`
- Update MX records in the Netlify sub-zones to point to `mx1.improvmx.com` (priority 10) + `mx2.improvmx.com` (priority 20)
- Update SPF records to include `spf.improvmx.com`

Free tier limit: 1 domain, 25 aliases, 500 emails/day. Plenty for our 2 subdomains.

## GitHub PAT scope (hardening)

The `gh_secondary_token` (classic PAT, `repo` scope) has read/write access to ALL repos under `your-site-artifacts-user`. Recommend replacing with a **fine-grained PAT** scoped to only:
- `your-site-artifacts-user/example-docs` (Contents: Read+Write, Metadata: Read)
- `your-site-artifacts-user/example-blog` (Contents: Read+Write, Metadata: Read)

Limit blast radius if token leaks.

Procedure:
1. https://github.com/settings/personal-access-tokens/new
2. Resource owner: `your-site-artifacts-user`
3. Repository access: Only select repositories
4. Select: `example-docs`, `example-blog`
5. Permissions: Contents = Read and write, Metadata = Read-only
6. Generate
7. Update `secrets.json`: replace `gh_secondary_token` value
8. Revoke old classic PAT at https://github.com/settings/tokens

## Incident response (security breach)

If any account is compromised:

### CF MAIN compromise
1. **Revoke all API tokens**: https://dash.cloudflare.com/profile/api-tokens → Revoke all
2. **Rotate password**: https://dash.cloudflare.com/profile/auth
3. **Audit changes**: https://dash.cloudflare.com/?to=/:account/audit-log — review last 30 days
4. **Inspect Workers**: confirm no unauthorized worker deployments
5. **Inspect DNS records**: confirm no unauthorized changes (use `scripts/20_final_verify.py` to compare state)

### Netlify compromise
1. **Revoke token**: https://app.netlify.com/user/applications
2. **Audit DNS zones**: list all zones, compare to `state.json`
3. **Re-create compromised zones**: delete + re-create with fresh NS, update CF root zone NS records

### Vercel compromise
1. **Revoke token**: https://vercel.com/account/tokens
2. **Audit deployments**: review recent deploys for unauthorized code
3. **Force redeploy**: from known-good commit

### Spaceship compromise
1. **Revoke API key**: https://www.spaceship.com/application/api-manager/
2. **Lock transfer**: https://www.spaceship.com/control-panel/domains/example.com/transfer-lock — enable
3. **Verify NS**: confirm NS still points to Cloudflare
4. **Rotate password**: https://www.spaceship.com/account/security

### Full disaster recovery
If everything is destroyed and you need to rebuild from scratch:

```bash
git clone https://github.com/your-backup-user/domain-infra-kit.git
cd domain-infra-kit
# Re-create secrets.json with fresh credentials
cp infra/secrets.json.example infra/secrets.json
# Edit with new credentials
# Then run the scripts in order (see README.md "Scripts in execution order")
```

The GitHub repo has all the scripts + docs needed for a full rebuild. Only secrets + state need to be re-created.

## Backup

The entire infrastructure is codified in:
- GitHub repo: https://github.com/your-backup-user/domain-infra-kit (private)
- All scripts are idempotent — re-running is safe
- `state.json` is the source of truth for live zone IDs and NS assignments

To make a fresh backup after any change:
```bash
python3 scripts/14_archive_to_gh.py
```

## Truly manual items (cannot be automated — ACTION REQUIRED)

1. **CF Email Routing destination verification** — check inbox of `admin@example.com`, click verification link from Cloudflare
2. **Netlify 2FA enforcement** — https://app.netlify.com/user/security (enable 2FA)
3. **Vercel 2FA enforcement** — https://vercel.com/account/security (enable 2FA)
4. **GitHub 2FA enforcement** — https://github.com/settings/security (both accounts)
5. **Rotate CF master tokens** — CF dashboard → revoke the `cf_main_token` and `cf_sub_token` master tokens (see `infra/secrets.json` for current values — they start with `cfat_`)
6. **ImprovMX signup** (if email forwarding on users.*/corp.* is needed) — https://improvmx.com (web form, 2 min)
7. **Help-desk vendor selection** for `help.example.com` (Zendesk/Intercom/HelpScout) — business decision
8. **Spaceship transfer lock** — visit https://www.spaceship.com/control-panel/domains/example.com/transfer-lock and enable. Note: Spaceship's API now actively blocks our IP (HTTP 403 "browser_signature_banned" — Cloudflare error 1010). The `scripts/32_enable_transfer_lock.py` script attempts to enable this but cannot due to the IP block.
9. **Rotate GitHub secondary token** to fine-grained PAT — see procedure above (CF/Vercel master rotation procedure is automated via scripts/03 + 21, but GitHub does not allow token rotation via API)

Everything else is automated.
