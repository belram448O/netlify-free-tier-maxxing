# Architecture — Multi-Account Custom Domain Pattern

> **Companion docs**: `KIT.md` (playbook), `FLEET.md` (multi-pod scaling), `LESSONS.md` (pitfalls), `CODEBASE.md` (scripts), `SECURITY.md` (tokens), `REPLICATE.md` (add subdomains), `PIVOT.md` (design decisions)

## Pattern overview

This kit implements a multi-account custom domain architecture using:
- **Cloudflare** for the apex DNS zone (Workers, Email Routing, WAF, SSL)
- **Netlify DNS zones** for per-subdomain isolation (free, standalone subdomain zones via NS delegation)
- **Vercel** for SSR sites (docs, blog — non-commercial only on Hobby tier)
- **Spaceship** (or any registrar with API) for domain registration + NS management

```
                ┌────────────────────────────┐
                │ Registrar (Spaceship,      │
                │   Namecheap, Porkbun, etc)│
                │   Domain: example.com     │
                │   NS → Cloudflare          │
                └────────────┬───────────────┘
                             │
              ┌──────────────▼─────────────────┐
              │ CF apex account (Free tier)    │
              │ Zone: example.com (active)     │
              │                                │
              │ A      example.com  → Worker   │
              │ CNAME  www          → apex     │
              │ CNAME  docs         → Vercel   │
              │ CNAME  blog         → Vercel   │
              │ CNAME  help         → vendor   │
              │ NS     users        → Netlify  │ ← per-subdomain isolation
              │ NS     app          → Netlify  │
              │ NS     content      → Netlify  │
              │ NS     corp         → Netlify  │
              │ NS     api          → Netlify  │
              │ NS     cdn          → Netlify  │
              │ TXT    apex         SPF/DMARC  │
              │ CAA    apex         cert restrict│
              │                                │
              │ Worker: example-root-worker    │
              │ Email Routing: enabled          │
              │ 2FA enforcement: enabled        │
              └──┬──────────────────────────────┘
                 │
        NS del.  │  to Netlify NS1
                 ▼
        ┌────────────────────────────────────┐
        │ Netlify DNS zones (Free tier)      │
        │ Per-zone: 7 DNS records            │
        │ (A, CNAME, SPF, DMARC, MTA-STS,    │
        │  2× CAA)                            │
        │ Each zone = separate billing/       │
        │ access envelope                     │
        └────────────────────────────────────┘
```

## Design rationale (why each choice)

### Why Netlify DNS zones (not CF subdomain zones)?

- **CF subdomain zones**: Enterprise-only ($5K+/mo). Error 1116 ("Please ensure you are providing the root domain") is misleading — it's a missing-entitlement error, not a malformed-request error.
- **Netlify DNS zones**: free, first-class "standalone subdomain DNS zone" feature via `POST /api/v1/dns_zones`.
- Same isolation goals achieved: separate zone, separate billing, separate access tokens.
- See `PIVOT.md` for the full history of this discovery.

### Why CF apex + Netlify for sub-zones? (TOS strategy)

- CF apex: free WAF, edge, Workers, KV, R2, Email Routing native
- Netlify sub-zones: TOS-safe separation — Netlify allows commercial use on free tier (unlike Vercel Hobby)
- Netlify AUP has no redirect restriction — off-site 302s to third-party domains allowed
- CF Section 2.8 "non-HTML ban" historically risky (removed in 2026, but strategically Netlify is safer for sub-zones)
- Per-pod CF accounts (for app/users/etc.) get their own abuse-detection envelope — one pod's traffic spike doesn't risk the apex
- Trade-off: Netlify sub-zones have no WAF, but sub-zones are typically static/placeholder until fleet scaling

### Why Worker Routes (not Worker Custom Domain)?

- Worker Custom Domain endpoint URL is non-obvious (`PUT /accounts/{id}/workers/domains` not `POST /accounts/{id}/workers/scripts/{name}/domains`)
- Worker Routes simpler: `POST /zones/{id}/workers/routes` with `{pattern, script}`
- Worker Routes supports wildcards (`*.example.com/*`) which Custom Domain doesn't
- Both approaches use CF Universal SSL (no SSL difference)
- Custom Domain auto-manages apex A record; Routes requires manual `192.0.2.1` placeholder (documented canonical pattern)

### Why `192.0.2.1` placeholder A record (proxied=true)?

- `192.0.2.1` is TEST-NET-1 documentation IP (RFC 5737) — not routable
- When proxied=true at CF, the record returns CF anycast IPs (e.g., 104.21.x.x, 172.67.x.x) — NOT 192.0.2.1
- CF Worker Route then intercepts the traffic at the edge and routes to the Worker
- Documented pattern at https://developers.cloudflare.com/dns/llms-full.txt

### Why DMARC + MTA-STS + CAA on every zone?

- **DMARC p=quarantine**: tells receiving mail servers to quarantine emails that fail SPF/DKIM checks (defensive against spoofing)
- **MTA-STS**: enforces TLS for inbound mail (prevents downgrade attacks)
- **CAA**: restricts which CAs can issue certificates for the domain (defensive against rogue cert issuance)
- All three are free, all three are best-practice for any production domain

### Why per-zone 2FA enforcement on CF apex?

- Account-level 2FA enforcement requires all members to have 2FA enabled before they can access the account
- Automatable via API (`PUT /accounts/{id}` with `enforce_twofactor: true`)
- Free feature, no plan requirement
- Protects against password leaks (you already use account API tokens which is good — 2FA on the underlying user account is the foundation)

### Why scoped API tokens (not user-scoped tokens)?

- Account-scoped tokens (`cfat_`) are bound to a single CF account — a leaked token from one pod's account literally cannot enumerate others
- User-scoped tokens (`cfut_`) have broader access across all the user's accounts
- The `cfat_` master tokens can only mint scoped tokens — perfect for bootstrapping, then rotate masters away

## Per-subdomain target service map

| Subdomain | DNS zone location | Hosting target | Email | Notes |
|---|---|---|---|---|
| `example.com` (apex) | CF apex | CF Worker (landing) | CF Email Routing → admin mailbox | Root identity |
| `www.example.com` | CF apex | CNAME → apex (legacy compat) | — | Legacy compatibility |
| `docs.example.com` | CF apex | Vercel (SSR / Next.js) | — | Non-commercial only (Hobby TOS) |
| `blog.example.com` | CF apex | Vercel (SSR / Next.js) | — | Non-commercial only (Hobby TOS) |
| `help.example.com` | CF apex | CNAME → third-party SaaS | vendor-managed | Help desk vendor (TBD) |
| `users.example.com` | Netlify DNS zone | TBD (CF Worker / Vercel / etc.) | ImprovMX (separate) | User-facing app |
| `app.example.com` | Netlify DNS zone | TBD | — | Main SPA |
| `content.example.com` | Netlify DNS zone | TBD (R2 + Worker) | — | CMS / media |
| `corp.example.com` | Netlify DNS zone | TBD | ImprovMX (separate) | Internal corporate |
| `api.example.com` | Netlify DNS zone | TBD (Worker + D1) | — | Public API edge |
| `cdn.example.com` | Netlify DNS zone | TBD (R2 public bucket) | — | Static asset CDN |

## What's automated vs truly manual

### ✅ Fully automated
- NS migration at registrar → Cloudflare (via registrar API)
- CF apex zone creation + DNS records + Worker + Email Routing
- Netlify DNS zone creation for all subdomains + NS delegation
- Vercel project setup + domain attachment + production deploys
- DMARC/MTA-STS/CAA on every zone
- 2FA enforcement on CF apex account (via API)
- Drift detection (state.json vs live API)
- E2E test suite (25 tests)
- CI/CD (GitHub Actions, hourly cron)

### ⚠️ Truly manual (cannot be automated — see SECURITY.md)
1. CF Email Routing destination verification (click link in inbox)
2. Account creation at any provider (CF, Netlify, Vercel, Supabase, Neon, GitHub)
3. 2FA setup at Netlify, Vercel, GitHub (CF is the exception — automatable)
4. Master token rotation (CF API blocks sub-token self-revocation)
5. ImprovMX signup (web form only, no account-creation API)
6. Help-desk vendor selection (business decision)
7. Spaceship transfer lock (when API is IP-blocked)

## Live status

After running `make deploy` + `make verify`, your live status should show:
- `dig NS example.com @1.1.1.1` → CF nameservers
- `dig NS users.example.com @1.1.1.1` → Netlify NS1 nameservers
- `curl https://example.com/__health` → 200 JSON from Worker
- `curl https://docs.example.com/` → 200 from Vercel
- `make verify` → 20/20 checks pass
- `make drift` → 0 drift detected
- `make e2e` → 25/25 tests pass
