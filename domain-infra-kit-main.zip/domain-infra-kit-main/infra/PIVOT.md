# Design Decisions — Why This Architecture

> **Companion docs**: `ARCHITECTURE.md` (pattern overview), `LESSONS.md` (pitfalls), `KIT.md` (playbook)
> **Status**: Reference — explains WHY certain choices were made over alternatives.

## TL;DR

| Decision | Chosen | Alternative | Why |
|---|---|---|---|
| Per-subdomain isolation | Netlify DNS zones | CF subdomain zones | CF requires Enterprise ($5K+/mo); Netlify is free |
| Apex DNS provider | Cloudflare | Netlify | CF gives free WAF + Workers + Email Routing at apex |
| Worker binding | Worker Routes | Worker Custom Domain | Routes simpler + supports wildcards; Custom Domain endpoint URL is non-obvious |
| Apex A record | 192.0.2.1 (proxied) | CF-managed A | Canonical CF pattern; 192.0.2.1 is TEST-NET-1 (RFC 5737) |
| Email Routing | CF on apex, ImprovMX on sub-zones | Single provider | CF Email Routing is zone-level (only works on CF apex); sub-zones are on Netlify |
| Email security | DMARC p=quarantine + MTA-STS + CAA | Minimal | Best-practice for any production domain; all free |
| Token strategy | Scoped cfat_ tokens | User-scoped cfut_ tokens | Account-scoped = limited blast radius if leaked |
| CI/CD | GitHub Actions | None (local only) | Production needs automated verification + drift detection |
| Secrets | secrets.json (mode 0600, gitignored) | Vault / Doppler | Sufficient for single-operator; upgrade to Doppler at >5 pods |

## Decision details

### Why Netlify DNS zones (not CF subdomain zones)?

**CF subdomain zones require Enterprise tier** ($5K+/mo). The API returns error 1116 "Please ensure you are providing the root domain" which is misleading — it's a missing-entitlement error, not a malformed-request error. Confirmed by CF engineer Patryk Szczygłowski in GitHub terraform-provider-cloudflare#655: *"This is expected when you don't have Subdomain Support enabled on your account."*

**Netlify DNS zones** are free, first-class "standalone subdomain DNS zone" feature via `POST /api/v1/dns_zones`. Returns NS for delegation. Same isolation goals achieved: separate zone, separate billing, separate access tokens.

### Why CF apex + Netlify for sub-zones? (TOS strategy)

- **CF apex**: free WAF, edge, Workers, KV, R2, Email Routing native
- **Netlify sub-zones**: TOS-safe separation — Netlify allows commercial use on free tier (unlike Vercel Hobby)
- **Netlify AUP**: no redirect restriction — off-site 302s to third-party domains allowed
- **CF Section 2.8**: "non-HTML ban" removed in 2026 TOS, but Netlify is strategically safer for sub-zones
- **Per-pod isolation**: each subdomain's traffic spike doesn't risk the apex

### Why Worker Routes (not Worker Custom Domain)?

- Worker Custom Domain endpoint URL: `PUT /accounts/{id}/workers/domains` (not `POST /accounts/{id}/workers/scripts/{name}/domains` which returns 405 "Method not allowed for this authentication scheme")
- Worker Routes: `POST /zones/{id}/workers/routes` with `{pattern, script}` — simpler, works with Bearer tokens
- Worker Routes supports wildcards (`*.example.com/*`) which Custom Domain doesn't
- Both use CF Universal SSL (no SSL difference)

### Why `192.0.2.1` placeholder A record (proxied=true)?

- `192.0.2.1` is TEST-NET-1 documentation IP (RFC 5737) — not routable
- When `proxied=true` at CF, the record returns CF anycast IPs (104.x/172.x) — NOT 192.0.2.1
- CF Worker Route intercepts the traffic at the edge and routes to the Worker
- Documented canonical pattern at https://developers.cloudflare.com/dns/llms-full.txt

### Why CF Email Routing on apex + ImprovMX on sub-zones?

- CF Email Routing is **zone-level** — only works on the apex zone (which is on CF)
- Sub-zones are on Netlify DNS — CF Email Routing doesn't apply
- **ImprovMX** is MX-based — works on any DNS zone, regardless of provider
- Free tier: 25 aliases, 500 emails/day, 1 domain
- Alternative: AWS SES (paid, programmatic, production-grade)

### Why scoped cfat_ tokens (not user-scoped cfut_)?

- Account-scoped tokens (`cfat_`) are bound to a single CF account — a leaked token from one pod's account cannot enumerate others
- User-scoped tokens (`cfut_`) have broader access across all the user's accounts
- The `cfat_` master tokens can only mint scoped tokens — perfect for bootstrapping, then rotate masters away
- CF API blocks sub-tokens from having `Account API Tokens:Write` — master rotation is truly manual

### Alternatives considered and rejected

| Alternative | Why rejected |
|---|---|
| All-in-root-zone + scoped tokens | No per-subdomain billing/access isolation; one compromised token = all subdomains at risk |
| AWS Route 53 sub-zones | $0.50/zone/mo + per-query cost — breaks the $0 free-tier goal |
| Vercel for sub-zones | Vercel does NOT support standalone subdomain DNS zones (confirmed via research) |
| CF Enterprise subdomain zones | $5K+/mo — not free-tier-friendly |
| Multiple apex domains | Requires registering multiple domains (~$10-15/yr each) — not needed for v1 |
