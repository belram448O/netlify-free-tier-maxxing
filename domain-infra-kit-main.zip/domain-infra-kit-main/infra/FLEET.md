# example.com — Multi-Pod Fleet Architecture (Future-Proof Design)

> **Status**: Research + design complete. Implementation pending user go-ahead.
> **Date**: 2026-08-15
> **Audience**: Architect + future operators

This document extends `ARCHITECTURE.md` with the future-proof "fleet of free-tier accounts" pattern the user described. It addresses regional sharding, the "redirect magic" question, when to upgrade to paid, and how to tie NS + apex site + pods together.

## TL;DR

The current architecture (Netlify DNS zones per subdomain + CF root zone + Vercel for docs/blog) **extends cleanly** to a fleet of regional pods. The recommended pattern:

1. **Netlify apex stays** (TOS-safe, free 100GB bandwidth, natively supports `_redirects` with Country= rules)
2. **Netlify `_redirects` with Country= rules** is the "redirect magic" — zero latency, zero extra hop, free, no CF Worker needed
3. **Each regional pod = isolated account per service** (CF account for edge worker, Vercel team for SSR, Supabase project for DB, Neon project for serverless PG)
4. **Naming**: `app-<region>-<2-digit-shard>.example.com` for v1 (e.g., `app-us-east-01`)
5. **Upgrade path**: per-pod — when one pod's account hits limits, upgrade only that pod (typically $5–25/mo per hot pod)
6. **Worst-case scaling**: 100 pods fully free = $0/mo. When 5 pods hit limits simultaneously = ~$125/mo total. Linear, not exponential.

## Why keep apex on Netlify (the user's constraint — verified)

The user's instinct is correct. Netlify as apex with isolated per-pod CF accounts gives the best TOS posture:

| Concern | Netlify apex | CF apex |
|---|---|---|
| Commercial use on free tier | ✅ Allowed (verified in AUP) | ✅ Allowed (Workers Developer Platform is sanctioned) |
| Section 2.8 "non-HTML" ban (2023 case) | N/A | ✅ **Removed** from 2026 TOS — JSON API proxy on Workers is now safe |
| Multi-tenant SaaS allowed | ✅ No prohibition | ✅ No prohibition |
| Off-site 302 redirects allowed | ✅ No restriction in AUP | ✅ Allowed via Worker or Redirect Rules |
| Hard limit on free bandwidth | 100GB/account/mo | N/A (Workers don't meter bandwidth) |
| Per-zone WAF | ❌ Not provided | ✅ Free (1 managed rule + 5 custom rules per zone) |
| Edge geo-aware routing | ✅ `_redirects` Country= rules or Edge Functions | ✅ Worker reading `request.cf.colo` |

**Verdict**: Keep apex on Netlify (TOS-safe, simpler, free up to 100GB) — **but accept the trade-off of no CF WAF at the apex zone**. The apex is just a static landing + redirect page, so WAF isn't needed there. Per-pod CF accounts get their own WAF (free, per-zone).

## Fleet architecture (target)

```
                        ┌─────────────────────────────┐
                        │ Spaceship (registrar)       │
                        │ example.com               │
                        │ NS → Netlify NS1            │
                        └────────────┬────────────────┘
                                     │
                ┌────────────────────▼─────────────────────┐
                │ Netlify apex DNS zone (Free)              │
                │                                           │
                │ A   example.com     → Netlify site IP   │
                │ CNAME www            → example.com      │
                │ CNAME docs           → cname.vercel-dns   │
                │ CNAME blog           → cname.vercel-dns   │
                │ NS  users            → NS1 (sub-zone)    │
                │ NS  app              → NS1 (sub-zone)    │
                │ NS  content          → NS1 (sub-zone)    │
                │ NS  corp             → NS1 (sub-zone)    │
                │ NS  api              → NS1 (sub-zone)    │
                │ NS  cdn              → NS1 (sub-zone)    │
                │ NS  pods             → NS1 (sub-zone)    │
                │                                           │
                │ Netlify site (apex landing)              │
                │   - Static HTML landing page              │
                │   - _redirects file with Country= rules   │
                │   - Edge Function for geo-aware routing   │
                └───┬────────────────────────────────────────┘
                    │
                    │ _redirects: 302 to regional pods
                    │
        ┌───────────▼───────────────────────────────────────────┐
        │ Per-region pod fleet                                 │
        │                                                      │
        │ app-us-east-01.example.com                         │
        │   DNS: A record in app.example.com Netlify zone    │
        │   Hosting: CF Worker (own CF account #1, free)       │
        │   DB: Supabase project (own Supabase acct) us-east-1 │
        │   Edge compute: same CF Worker                       │
        │                                                      │
        │ app-us-west-01.example.com                         │
        │   DNS: A record in app.example.com zone            │
        │   Hosting: CF Worker (own CF account #2, free)       │
        │   DB: Supabase project (own Supabase acct) us-west-1│
        │                                                      │
        │ app-eu-west-01.example.com                         │
        │   DNS: A record                                      │
        │   Hosting: CF Worker (own CF account #3, free)       │
        │   DB: Neon project (own Neon acct) aws-eu-west-1     │
        │                                                      │
        │ api-us-east-01.example.com                         │
        │   DNS: A record in api.example.com zone            │
        │   Hosting: CF Worker (own CF account, free)          │
        │   KV + R2 for state (in same CF account)              │
        └──────────────────────────────────────────────────────┘
```

## "Redirect magic" — the three options compared

The question: when a user visits `app.example.com`, how do they end up at the right regional pod?

### Option A: Netlify `_redirects` with Country= rules — ⚠️ COUNTRY-LEVEL ONLY (NOT RECOMMENDED for US regional split)

**How it works**: Netlify's CDN edge reads the incoming request's country (MaxMind GeoIP) and matches against `_redirects` rules in priority order.

**Critical limitation**: Netlify `_redirects` supports only country-level granularity. **You cannot distinguish US-East from US-West via `_redirects`** — both go to the same pod if both rules match `Country=us`.

**When to use**: v0 / single-pod-per-region (no within-US split). Example:
```
/app/*  https://app-us.example.com/:splat  302  Country=us,ca
/app/*  https://app-eu.example.com/:splat  302  Country=gb,de,fr,it,es,nl,ie,se,no,fi,dk,pt,at,ch,be
/app/*  https://app-ap.example.com/:splat  302  Country=sg,my,id,ph,th,vn,au,nz
/app/*  https://app-us.example.com/:splat  302
```

**Pros**: zero added latency, free, native Netlify CDN edge.
**Cons**: country-level only; no US-East vs US-West split; no health-check failover; static rules.

### Option B: Netlify Edge Function reading `context.geo` — ⭐ RECOMMENDED for v1+ (sub-country routing)

Best for: when you need US-East vs US-West split, health-check failover, or dynamic pod registry. Use this from day 1 if you anticipate US regional sharding — `_redirects` (Option A) cannot do this.

**Implementation** (`netlify/edge-functions/router.ts`):
```typescript
export default async (req: Request, ctx: Context) => {
  const country = ctx.geo.country?.code || 'US';
  const region = ctx.geo.subdivision?.code || ''; // e.g., 'CA', 'NY'

  // Routing table — could be fetched from KV/API for dynamic updates
  const pod = pickPod(country, region);

  const url = new URL(req.url);
  return Response.redirect(`https://${pod}.example.com${url.pathname}${url.search}`, 302);
};

function pickPod(country: string, region: string): string {
  if (country === 'US') {
    const westStates = ['CA','OR','WA','NV','AZ','UT','ID','MT','WY','CO','NM','AK','HI'];
    const eastStates = ['NY','NJ','PA','MA','CT','FL','GA','VA','MD','NC','SC','OH','MI','IL','TN'];
    if (westStates.includes(region)) return 'app-us-west-01';
    if (eastStates.includes(region)) return 'app-us-east-01';
    return hashPick('app-us-east-01', 'app-us-west-01');  // default: hash-based
  }
  if (['GB','DE','FR','IT','ES','NL','IE','SE','NO','FI','DK','PT','AT','CH','BE'].includes(country))
    return 'app-eu-west-01';
  if (['SG','MY','ID','PH','TH','VN','AU','NZ'].includes(country))
    return 'app-ap-southeast-01';
  return 'app-us-east-01';  // fallback
}

function hashPick(...pods: string[]): string {
  const hash = Math.floor(Math.random() * pods.length);
  return pods[hash];
}
```

**Pros**: Sub-country granularity (`ctx.geo.subdivision.code` gives US state); programmatic — can do health-check failover; dynamic pod registry; 1M invocations/month free; Deno Deploy edge runs globally close to user.

**Cons**: Edge Functions historically had stability issues (better in 2026, but still some flakiness); Deno-only; 1MB code cap; ~5–15ms added per request.

### Option C: CF Worker at apex zone (if apex on CF)

Not recommended for our architecture (apex is on Netlify). Listed for completeness.

If apex were on CF, you'd deploy a `example-router` Worker reading `request.cf.colo` (3-letter IATA code — more granular than country, distinguishes LAX from SJC). Free up to 100K req/day; $5/mo for 10M req/mo.

### Option D: DNS-level geo routing (Route 53 geolocation)

Not recommended — costs $0.50/zone/mo + $0.40/M queries, breaks the free-tier goal.

### Option E: Client-side JS routing

Not recommended — adds round-trip, breaks SEO, breaks curl, breaks bots.

## Recommendation: B from day 1 (skip A if you need US regional split)

**v0 (single pod per region, country-level routing)**: Option A (`_redirects`) is acceptable. Free, zero latency. But you CANNOT distinguish US-East from US-West — only whole-country.

**v1 (any US regional sharding)**: **Option B (Netlify Edge Function) from day 1.** The `_redirects` approach cannot do US-East vs US-West split — adopting it first means an immediate rewrite when you add a second US pod. The Edge Function approach is also free (1M invocations/month) and adds only ~5-15ms latency.

**v2 (10+ pods OR health-check failover)**: Extend Option B with dynamic pod registry (fetch list from Netlify Blobs or external KV), add health-check probes via `fetch()` before redirecting.

**v3 (when you outgrow Netlify free 100GB)**: Move the router off Netlify to a CF Worker at `router.example.com` (a separate sub-zone on its own CF account, $5/mo paid). All pods still free, only the router is paid. Apex on Netlify stays static + 302s to `router.example.com/<region>/<path>`.

## Free-tier budget per pod

| Service | Free limit per pod | Hard stop behavior | Upgrade cost |
|---|---|---|---|
| CF Workers (per account) | 100K req/day, 10ms CPU, 1GB KV, 10GB R2 | Worker returns 5xx | $5/mo for 10M req/mo |
| CF Pages (per account) | 500 builds/mo, unlimited static | Build queue stops | $20/mo (Pro) |
| CF Email Routing (per zone) | 200 dest, 200 rules, 3K outbound emails/mo | Hard stop | Free always |
| Vercel Hobby (per team) | 100GB BW, 1M invocations, 4 CPU-hrs, 100 deploys/day | Hard stop + email | $20/user/mo (Pro) |
| Supabase (per project) | 500MB DB, 5GB egress, 50K MAU, 7-day-inactivity pause | Auto-pause after 7 days idle | $25/mo (Pro) |
| Neon (per project) | 100 CU-hrs, 0.5GB storage, scale-to-zero after 5 min | Auto-suspend at limit | $19/mo (Launch) |
| Netlify (per account) | 100GB BW, 300 build mins, 125K function calls, 1M edge fn calls | Hard stop (no overage) | $19/mo (Pro) |

**Key insight**: Per-pod scaling is **linear**. Doubling users → doubling pods → doubling free-tier accounts. Adding one pod costs $0 until that pod's limits are hit.

## When to upgrade `app.example.com` itself

**Answer**: You don't need to upgrade the apex. The apex is just a static landing page + `_redirects` file. It uses ~10KB per visit. At 100GB free bandwidth, you can serve ~10M visits/month before hitting Netlify's free cap. When that happens (would mean ~10M monthly active users — at that scale you have revenue), upgrade the apex Netlify account to Pro ($19/mo).

**The CF Worker router case (Option C, not chosen)**: If you go with Option C, you'd upgrade the apex CF Worker to paid ($5/mo) when:
- Daily router requests > 95K consistently
- You need health-check failover (requires KV writes >1K/day for state)
- You need >10ms CPU per redirect (e.g., JWT validation)

## Vercel Hobby TOS landmine ⚠️

**Critical finding from research**: Vercel Hobby tier prohibits commercial use:
> *"You shall only use the Services under a Hobby plan for your personal or non-commercial use."* — Vercel ToS, June 2026

If `app.example.com` (or any pod) ever touches revenue (Stripe, ads, paid tiers, affiliate links), Vercel Hobby is a TOS violation.

**Recommended mitigation**:
- Keep docs.example.com and blog.example.com on Vercel Hobby (pure marketing, no revenue)
- For `app.*` and `api.*` pods: use CF Workers (free, no commercial-use restriction) or Netlify Functions (commercial OK on free within limits)
- Plan to upgrade to Vercel Pro ($20/user/mo) the moment revenue touches any deployment — budget for this

## Supabase 7-day pause workaround

Supabase free tier auto-pauses projects after 7 days of no API activity. Unpausing takes ~30s (cold start).

**Free workaround**: Deploy a tiny CF Worker (one free CF account) that pings each Supabase pod's `/__health` endpoint every 6 days. Keeps all pods warm.

```javascript
// keepalive-worker.js — runs every 6 days via Cron Trigger
export default {
  async scheduled(event, env, ctx) {
    const pods = JSON.parse(await env.POD_REGISTRY.get('supabase-pods'));
    await Promise.all(pods.map(pod => 
      fetch(`https://${pod}.supabase.co/rest/v1/`, {
        headers: { 'apikey': env.SUPABASE_ANON_KEY }
      })
    ));
  }
};
```

## GitHub multi-account TOS landmine ⚠️

GitHub ToS: *"One person or legal entity may maintain no more than one free Account"*.

If you use multiple GitHub accounts under one entity to back separate Vercel teams, that's a GitHub ToS violation.

**Mitigation**:
- Use ONE GitHub account with multiple repos + per-repo deploy tokens
- Or use GitLab free for secondary pod repos
- Or use Bitbucket free

## Naming convention

**Recommendation**: `app-<region>-<2-digit-shard>.example.com` for v1.

| Pattern | Example | Use case |
|---|---|---|
| `<service>-<region>-<NN>` | `app-us-east-01` | v1, ≤9 shards/region |
| `<service>-<region>-<hex4>` | `app-us-east-a1b2` | v2, when 10+ shards/region (hexcode = first 4 chars of sha256(pod_uuid)) |
| `<service>-<hex6>` | `app-a1b2c3` | When you want to hide region info from URL (server-side routing) |
| `<service>-<region>` | `app-us-east` | Single pod per region (v0, before sharding) |

**Hexcode naming trade-offs**:
- ✅ Hides pod count from attackers (don't leak that you have N pods)
- ✅ Collision-free (vs numeric which requires coordination)
- ❌ Less greppable (`grep app-us-east-` no longer works)
- ❌ Harder for ops to identify pod region from URL alone

## Per-pod secrets management

`infra/secrets.json` won't scale past ~10 pods. Recommended:

### v1 (1–5 pods): Per-pod secrets.json
```
infra/secrets.json             ← apex + router
infra/pods/
  ├── app-us-east-01.json      ← pod-specific secrets
  ├── app-us-west-01.json
  └── app-eu-west-01.json
```

Each pod secrets file contains: CF account token, Supabase URL + anon key, Neon connection string, Vercel deploy token.

### v2 (5–30 pods): Doppler (free for individuals)
- One Doppler project per pod
- Doppler syncs to CF Worker env vars + Vercel project env + Supabase env (via CLI on deploy)
- Master Doppler token in GitHub Actions secrets (one per pod)

### v3 (30+ pods): 1Password Secrets Automation or HashiCorp Vault
- Per-pod vault
- CI service-account tokens scoped per vault

## Account bootstrapping — what can/cannot be automated

**Cannot be automated** (truly manual, one-time per pod):
- CF account creation (web signup, no API)
- Supabase account creation (web or GitHub OAuth)
- Vercel team creation (web)
- Neon account creation (web or GitHub OAuth)
- Netlify account creation (web, no API)
- Email verification on each
- 2FA setup on each (where supported)

**Can be automated** (after account creation):
- CF zone creation, DNS records, Worker deploy, KV/R2 setup
- Netlify DNS zone creation, NS delegation in parent zone
- Vercel project creation + domain attachment + deploys
- Supabase project creation (via API after account exists)
- Neon project creation (via API after account exists)
- Pod registry entry (CSV or JSON)

**Recommended workflow**:
1. Maintain `infra/pods.csv` with one row per pod:
   ```csv
   pod_id,service,region,shard,cf_account_id,supabase_project_id,neon_project_id,vercel_team_id,created_date
   app-us-east-01,app,us-east,01,<cf-id>,<supabase-id>,<neon-id>,<vercel-id>,2026-08-15
   ```
2. After manually creating accounts, add row to `pods.csv`
3. Run `scripts/30_provision_pod.py app-us-east-01` — this script reads the CSV row and provisions all the automated parts

## Cost projection: 1 → 100 pods

| Stage | Total pods | Cost (free only) | Hot pods | Cost (with upgrades) |
|---|---|---|---|---|
| v1 launch | 3 (us-east, us-west, eu-west) | $0/mo | 0 | $0/mo |
| 10K MAU | 3 | $0/mo | 0 | $0/mo |
| 100K MAU | 5–10 | $0/mo | 1 (us-east hot) | $5/mo (CF Workers paid for hot pod) |
| 1M MAU | 10–20 | $0/mo | 2–3 | $10–25/mo |
| 10M MAU | 50–100 | $0/mo | 5–10 | $50–250/mo |
| 100M MAU | 100+ | N/A | many | $500–2K/mo (consider Workers for Platforms $25/mo + req-based) |

Compare to single-account scale-up: At 100M req/mo, CF Workers paid alone = $35/mo + KV costs. Per-pod scaling wins at moderate scale; loses edge at hyperscale (>1B req/mo) where Workers for Platforms ($25/mo + $0.30/M req) wins.

## Implementation plan (phased)

### Phase 1 (NOW — already done): Single-pod proof-of-concept
- ✅ Apex on Netlify (TOS-safe)
- ✅ Netlify DNS zones for all 6 subdomains (users/app/content/corp/api/cdn)
- ✅ docs.example.com + blog.example.com on Vercel Hobby (non-commercial)
- ✅ example.com landing page on CF Worker (apex zone)
- ✅ Email Routing on apex

### Phase 2 (next 1–4 weeks): Add regional pod capability
- [ ] Add `app.example.com` Netlify sub-zone (already exists)
- [ ] Set up first regional pod: `app-us-east-01.example.com`
  - Create new CF account (manual, ~2 min)
  - Mint scoped tokens
  - Deploy app Worker
  - Set up Supabase project in us-east-1 (manual signup)
  - Update DNS in `app.example.com` Netlify zone: A record `app-us-east-01` → CF Worker IP
- [ ] Set up second pod: `app-us-west-01.example.com`
- [ ] Add `_redirects` to Netlify apex site with Country= rules
- [ ] Test end-to-end: visit `app.example.com` from US/EU/AP, verify regional routing

### Phase 3 (1–3 months): Fleet management tooling
- [ ] `scripts/30_provision_pod.py` — takes pod_id, provisions everything
- [ ] `scripts/31_deprovision_pod.py` — tears down a pod
- [ ] `scripts/32_keepalive_worker.py` — CF Worker cron that pings Supabase pods every 6 days
- [ ] `infra/pods.csv` registry
- [ ] Doppler setup (when pod count >5)

### Phase 4 (3–6 months): Hyperscale preparation
- [ ] Terraform migration (when pod count >10)
- [ ] Per-pod state files in Terraform Cloud (free for individuals up to 500 resources)
- [ ] Health-check failover via Netlify Edge Function
- [ ] Migrate `_redirects` to Edge Function for dynamic pod registry

### Phase 5 (6–12 months): Hyperscale
- [ ] Consider CF Workers for Platforms ($25/mo) when pod count >50
- [ ] Consider Netlify Pro for apex ($19/mo) when apex bandwidth >100GB
- [ ] Per-pod Pro upgrades for hot regions

## Key decisions to make now

1. **Naming convention**: Numeric (`app-us-east-01`) or hexcode (`app-us-east-a1b2`)?
   - Recommendation: numeric for v1, reserve hexcode for v2

2. **DB per pod**: Supabase (Postgres + auth + storage) or Neon (Postgres only)?
   - Recommendation: Supabase for pods that need auth/storage, Neon for pure DB

3. **Hosting for app pods**: CF Workers or Vercel?
   - Recommendation: CF Workers (no commercial-use TOS risk, free 100K req/day, runs at edge globally)

4. **When to upgrade**: Now or later?
   - Recommendation: stay on free for v1, upgrade per-pod when limits hit

5. **Secrets management**: Plain JSON files, Doppler, or Vault?
   - Recommendation: plain JSON for v1 (≤5 pods), Doppler for v2

## Sources cited

- Cloudflare Workers limits: https://developers.cloudflare.com/workers/platform/limits
- Cloudflare Service-Specific Terms (2026): https://www.cloudflare.com/service-specific-terms-application-services/
- Netlify pricing: https://www.netlify.com/pricing
- Netlify Acceptable Use Policy: https://www.netlify.com/legal/acceptable-use-policy/
- Netlify redirects docs: https://docs.netlify.com/manage/routing/redirects/redirect-options
- Netlify Edge Functions: https://docs.netlify.com/build/edge-functions/api
- Vercel Hobby limits: https://vercel.com/docs/plans/hobby
- Vercel ToS (commercial use): https://vercel.com/legal/terms
- Vercel regions: https://vercel.com/docs/regions
- Supabase pricing: https://supabase.com/pricing
- Supabase regions: https://supabase.com/docs/guides/platform/regions
- Neon pricing: https://neon.com/pricing
- Neon regions: https://neon.com/docs/introduction/regions
- Neon free plan tips: https://neon.com/blog/how-to-make-the-most-of-neons-free-plan
- CF community on multiple accounts: https://community.cloudflare.com/t/multiple-cloudflare-accounts-not-multi-user-accounts-solved/203214
- GitHub one-free-account ToS: https://github.com/orgs/community/discussions/78043
- Multi-tenant SaaS on free CF Workers: https://medium.com/@docat0209/how-to-build-a-multi-tenant-saas-on-cloudflare-workers-for-0-month-2026
- CF Workers for Platforms (upgrade path): https://developers.cloudflare.com/cloudflare-for-platforms/workers-for-platforms/reference/pricing
