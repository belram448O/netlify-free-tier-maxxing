# Lessons Learned — Pitfalls, Gotchas, and Design Rationale

> **Status**: Generalized. Every item here applies to any custom-domain kit deployment.
> **Companion to**: `KIT.md` (the playbook), `PIVOT.md` (example-specific history)

This doc captures every surprise, gotcha, misdiagnosis, and design decision made during the example.com build. Reading this BEFORE starting a new deployment will save hours.

## Top 10 gotchas (TL;DR)

1. **Cloudflare's `api.spaceship.net` is not the Spaceship API.** The real endpoint is `https://spaceship.dev/api`. The other hostname refuses TCP 443 globally.
2. **Cloudflare subdomain zones require Enterprise tier** ($5K+/mo), not just a different API call. Error 1116 ("Please ensure you are providing the root domain") is misleading — it's an entitlement-missing error.
3. **CF Workers Custom Domain endpoint doesn't exist** at `POST /accounts/{id}/workers/scripts/{name}/domains`. The correct path is `PUT /accounts/{id}/workers/domains` with body `{hostname, service: "production.<worker_name>", zone_id}`. Worker Routes (`POST /zones/{id}/workers/routes`) is the simpler alternative.
4. **Vercel Hobby tier prohibits commercial use**. Don't deploy anything revenue-touching on Hobby — use CF Workers (TOS-safe) or upgrade to Pro ($20/mo).
5. **GitHub ToS prohibits multiple free accounts per entity**. Use ONE GitHub account + multiple repos + per-repo deploy tokens, or use GitLab.
6. **CAA records require structured `data` field, not `content` string**. Using `content: '0 issue "cloudflare.com"'` silently stores as opaque text — clients may not parse it.
7. **Multiple DNS records at same name (e.g., 3 CAA records) require direct POST, not `upsert`**. `upsert_record` matches by (type, name) only — would silently overwrite the first CAA when creating the second.
8. **CF "Method not allowed for this authentication scheme" is misleading** — it's actually a 405 from CF's catch-all handler for unknown sub-paths, not an auth issue. Verify the endpoint URL exists in CF docs.
9. **`enforce_twofactor: true` CAN be set via API** — but only with a token that has `Account Settings:Write` permission. Mint an admin token first (`scripts/21_mint_admin_token.py`).
10. **Email Routing destination verification cannot be automated** — CSRF-bound link, requires human click in destination inbox.

## Detailed pitfalls (by category)

### A. Spaceship API gotchas

#### A1. Wrong API hostname (`api.spaceship.net` refuses connections)
- **Symptom**: `curl https://api.spaceship.net/api/v1/domains` → `connect to 198.54.117.249:443 failed: Connection refused`
- **Cause**: This hostname is not where the API lives. It looks like the API endpoint (because `<your-registrar-default-ns-1>` and `<your-registrar-default-ns-2>` are the NS), but it's not.
- **Real endpoint**: `https://spaceship.dev/api`
- **Discovery**: User attached `spaceship-openapi.json` which lists the server URL in `servers[0].url`.
- **Lesson**: When a provider's docs say "API endpoint at api.example.com" but it doesn't work, check their OpenAPI spec — they may have a different hostname.

#### A2. Wrong auth scheme (Basic auth doesn't work)
- **Symptom**: `Authorization: Basic <base64>` returns 401
- **Cause**: Spaceship uses custom headers `X-Api-Key` + `X-Api-Secret`, NOT Basic auth
- **Discovery**: OpenAPI spec's `security` scheme shows `apiKey` + `apiSecret` (custom headers)
- **Lesson**: Don't assume auth scheme from convention. Always check the spec.

#### A3. Pagination params required
- **Symptom**: `GET /v1/domains` returns `422 {"data":[{"field":"take","details":"The take field is required."}]}`
- **Cause**: Spaceship requires `take` and `skip` query params
- **Fix**: Always pass `?take=100&skip=0` (or appropriate pagination)
- **Lesson**: Read the OpenAPI spec's `parameters` section before calling any endpoint

#### A4. NS update is a 3-field body
- **Endpoint**: `PUT /v1/domains/{domain}/nameservers`
- **Body**: `{"provider":"custom","hosts":["ns1.example.com","ns2.example.com"]}`
- **Gotcha**: `provider` must be `"custom"` (not "basic" or omitted) when providing custom NS. For "basic" provider (Spaceship default), omit `hosts`.
- **Min/max NS**: 2 to 12 nameservers per domain
- **Rate limit**: 5 requests per domain per 300 seconds

### B. Cloudflare API gotchas

#### B1. Subdomain zone creation requires Enterprise
- **Symptom**: `POST /zones` with `name: "users.example.com"` returns `400 {"errors":[{"code":1116,"message":"Please ensure you are providing the root domain and not any subdomains"}]}`
- **Misdiagnosis**: I initially said "the API blocks subdomain zones". This was wrong.
- **Real cause**: Missing "Subdomain Support" entitlement, which is gated to Enterprise tier
- **Source**: https://developers.cloudflare.com/dns/zone-setups/subdomain-setup/setup/ — *"Subdomain setup is only available for Enterprise accounts."*
- **CF engineer confirmation**: Patryk Szczygłowski in GitHub terraform-provider-cloudflare#655: *"This is expected when you don't have Subdomain Support enabled on your account."*
- **Lesson**: Web-search the error code BEFORE concluding "the API doesn't support this".

#### B2. Workers Custom Domain endpoint URL is non-obvious
- **Wrong URL**: `POST /accounts/{acct}/workers/scripts/{name}/domains` → returns 405 "Method not allowed for this authentication scheme"
- **Misdiagnosis**: Initially thought the token lacked permissions. Actually the endpoint doesn't exist.
- **Correct URL**: `PUT /accounts/{acct}/workers/domains` (no `/scripts/{name}/` subpath)
- **Correct body**: `{"hostname": "...", "service": "production.<worker_name>", "zone_id": "..."}`
- **Reference**: https://developers.cloudflare.com/api/resources/workers/subresources/domains/methods/update
- **Lesson**: When you get "Method not allowed for this authentication scheme" with code 10000, the endpoint URL is wrong — CF's catch-all returns this for unknown sub-paths.

#### B3. Worker Routes as simpler alternative
- **Pattern**: `POST /zones/{zone_id}/workers/routes` with body `{"pattern": "example.com/*", "script": "worker-name"}`
- **Pros**: Works with Bearer token auth; supports wildcard patterns (e.g., `*.example.com/*`) which Custom Domains don't
- **Cons**: Requires manual apex A record (`192.0.2.1` proxied=true is the canonical placeholder)
- **Reference**: https://developers.cloudflare.com/dns/llms-full.txt

#### B4. CAA records need structured `data` field
- **Wrong**: `{"type":"CAA","name":"example.com","content":"0 issue \"cloudflare.com\""}` — stored as opaque text
- **Right**: `{"type":"CAA","name":"example.com","data":{"flags":0,"tag":"issue","value":"cloudflare.com"},"ttl":1,"proxied":false}`
- **Lesson**: Always use CF's structured `data` field for record types that have semantic structure (CAA, SRV, LOC, etc.)

#### B5. Multiple records at same (type, name) need direct POST
- **Symptom**: Creating 3 CAA records via an `upsert` helper silently truncates to 1
- **Cause**: `upsert_record` matches by `(type, name)` only — finds the first CAA, "updates" it to the second value, then "updates" again to the third
- **Fix**: Use direct `POST /zones/{zone_id}/dns_records` per record, with idempotency check by matching `(type, name, data)` tuple
- **Lesson**: For multi-value record types (CAA, MX, TXT at same name), use direct POST with idempotency match on full record content.

#### B6. CF Token permission names use spaces, not colons
- **Wrong**: `"Zone:Read"`, `"DNS:Edit"` (these don't exist)
- **Right**: `"Zone Read"`, `"DNS Write"`, `"Workers Scripts Write"`
- **Discovery**: Dumped the permission group catalog (`scripts/04_dump_perm_catalog.py`) and grepped
- **Lesson**: Always introspect the catalog before assuming names. CF has 386 permission groups with inconsistent naming.

#### B7. Email Routing requires zone to be `active`
- **Symptom**: `POST /zones/{id}/email/routing/enable` returns `403 Active zone required`
- **Cause**: Zone must be `status: active` (NS migrated) before Email Routing can be enabled
- **Fix**: Wait 5-30 min after NS migration; CF scans periodically. Check status via `GET /zones?name=...`
- **Lesson**: Plan for the NS migration delay — Email Routing setup happens AFTER NS is live, not before.

#### B8. 2FA enforcement IS automatable (with admin token)
- **Wrong assumption**: "2FA can only be enabled via dashboard"
- **Right**: Mint a token with `Account Settings:Write` permission, then `PUT /accounts/{id}` with body `{"settings":{"enforce_twofactor":true}}`
- **Caveat**: `api_access_enabled` field requires Enterprise — but `enforce_twofactor` works on free tier
- **Reference**: `scripts/21_mint_admin_token.py` mints the token; `scripts/06_configure_root_zone.py` calls the API

#### B9. CF zone scanner lags real DNS state
- **Symptom**: `GET /zones?name=example.com` shows `status: pending` even after `dig NS example.com @1.1.1.1` shows CF NS
- **Cause**: CF's `observed_name_servers` field caches for ~1 hour after migration
- **Lesson**: Use `dig +short NS example.com @1.1.1.1` as the source of truth, not CF dashboard status.

### C. Netlify API gotchas

#### C1. `account_id` is a UUID/hash, not a slug
- **Symptom**: `POST /dns_zones` with `account_slug: "your-name"` returns `422 {"errors":{"account":"Missing account"}}`
- **Cause**: Netlify wants `account_id` (the UUID/hash), not the slug
- **Fix**: `GET /accounts` to list accounts → take the `id` field (looks like `<your-netlify-account-id>`)
- **Lesson**: Always list the resource first to see the ID format expected.

#### C2. DNS zone creation returns NS immediately
- **Behavior**: `POST /dns_zones` returns `{id, dns_servers: [...]}` synchronously — no need to poll
- **NS pattern**: `dns1-4.p0X.nsone.net` where `p0X` is a pool assignment (Netlify uses NS1 as backend)
- **Lesson**: Netlify DNS zones are immediately ready for NS delegation — no propagation wait needed.

#### C3. DNS records API returns a list, not wrapped in `result`
- **Symptom**: `jq '.result'` returns null for `/dns_zones/{id}/dns_records`
- **Cause**: Netlify returns a bare array `[{...}, {...}]`, not CF's `{result: [...]}`
- **Lesson**: Always check the actual response shape — providers differ.

#### C4. Netlify supports subdomain DNS zones on free tier (unlike CF)
- **Feature**: `POST /dns_zones` with `name: "users.example.com"` works on free tier
- **Why**: Netlify has first-class "standalone subdomain DNS zone" support documented at https://docs.netlify.com/manage/domains/configure-domains/delegate-a-standalone-subdomain
- **Lesson**: When CF gates a feature behind Enterprise, check if Netlify offers it free.

### D. Vercel API gotchas

#### D1. Project creation field is `gitRepository`, not `gitSource`
- **Wrong**: `{"gitSource": {"type":"github","repo":"..."}}` → `400 should NOT have additional property gitSource`
- **Right**: `{"gitRepository": {"type":"github","repo":"..."}}`
- **Discovery**: Probed with minimal payload first, then added fields one at a time
- **Lesson**: When the API rejects unknown fields, probe with a minimal payload and add fields incrementally.

#### D2. Domain attachment — `gitBranch` makes it a Preview Domain
- **Symptom**: `POST /v9/projects/{id}/domains` with `gitBranch: "main"` returns `400 Cannot set Production Branch "main" for a Preview Domain`
- **Cause**: Including `gitBranch` makes Vercel treat it as a Preview Domain (per-branch domain)
- **Fix**: Omit `gitBranch` for production domains
- **Lesson**: Read the API docs carefully — field presence can change semantic meaning, not just value.

#### D3. Deploy trigger field is `gitSource` (different from project creation)
- **For project creation**: use `gitRepository`
- **For deployment trigger**: use `gitSource` with `{type, org, repo, ref, sha}`
- **Lesson**: Even within the same API, field names differ between endpoints. Don't assume consistency.

#### D4. Hobby tier TOS prohibits commercial use
- **Quote**: *"You shall only use the Services under a Hobby plan for your personal or non-commercial use."* — Vercel ToS, June 2026
- **Impact**: Any revenue-touching deployment on Hobby is a TOS violation
- **Mitigation**: Use CF Workers (no such restriction) for commercial pods; reserve Vercel for docs/blog (pure marketing)
- **Lesson**: Read the TOS of every free tier BEFORE architecting around it. Vercel's restriction is buried but enforceable.

#### D5. Vercel SSL DCV takes 5-15 minutes after CNAME is live
- **Symptom**: After attaching domain and triggering deploy, `curl https://docs.example.com` returns TLS handshake error
- **Cause**: Vercel needs to issue a Domain Control Validation cert — not instant
- **Fix**: Trigger DCV via `POST /v6/domains/{domain}/verify?teamId=...` then wait 5-15 min
- **Lesson**: SSL provisioning is async — poll or wait, don't assume failure on first timeout.

### E. GitHub API gotchas

#### E1. ToS prohibits multiple free accounts per entity
- **Quote**: *"One person or legal entity may maintain no more than one free Account."* — GitHub ToS
- **Impact**: Using multiple GitHub accounts under one entity for separate Vercel teams is a violation
- **Workaround**: ONE GitHub account + multiple repos + per-repo deploy tokens
- **Alternative**: Use GitLab or Bitbucket for secondary repos

#### E2. Contents API has a 100MB file size limit
- **Symptom**: Uploading spaceship-openapi.json (729KB) worked, but large files would fail
- **Workaround**: For files >1MB, use Git LFS or split into multiple smaller files
- **Lesson**: Use Contents API for code/config; use Git LFS for binaries.

#### E3. Secondary rate limit (5000 req/hour, but per-account)
- **Symptom**: After ~30 PUT /contents/ calls, get `403 You have exceeded your secondary rate limit`
- **Fix**: Add `time.sleep(0.5)` between sequential file uploads
- **Lesson**: GH's primary rate limit (5000/hr/user) is well-known; the secondary (per-resource) limit is less documented. Always add small delays in batch operations.

### F. Architecture decision rationale (why each choice was made)

#### F1. Why Netlify DNS zones (not CF subdomain zones)?
- CF subdomain zones: Enterprise-only ($5K+/mo)
- Netlify DNS zones: free, first-class "standalone subdomain DNS zone" feature
- Same isolation goals achieved: separate zone, separate billing, separate access

#### F2. Why Netlify apex (not CF apex)?
- TOS-safe separation: Netlify allows commercial use on free tier (unlike Vercel Hobby)
- Netlify AUP has no redirect restriction (off-site 302s allowed)
- Native `_redirects` with `Country=` rules — free, zero-latency redirect magic
- CF Section 2.8 "non-HTML ban" historically risky (now removed in 2026, but Netlify is still safer strategically)
- Trade-off: Netlify apex has no WAF, but apex is static HTML so WAF isn't needed

#### F3. Why Worker Routes (not Worker Custom Domain binding)?
- Worker Custom Domain endpoint URL is non-obvious (`PUT /accounts/{id}/workers/domains` not `POST /accounts/{id}/workers/scripts/{name}/domains`)
- Worker Routes simpler: `POST /zones/{id}/workers/routes` with `{pattern, script}`
- Worker Routes supports wildcards (`*.example.com/*`) which Custom Domain doesn't
- Both approaches use CF Universal SSL (no SSL difference)
- Custom Domain auto-manages apex A record; Routes requires manual `192.0.2.1` placeholder (documented in CF docs)

#### F4. Why per-pod CF accounts (not single CF account with multiple zones)?
- Free tier Workers limit is per-account (100K req/day shared across all Workers in the account)
- One pod's traffic spike would exhaust the limit for ALL pods
- Per-account isolation = each pod gets its own 100K req/day budget
- Per-account also gives: separate billing, separate audit logs, separate access tokens, separate WAF rules
- Trade-off: more accounts to manage (acceptable up to ~30 pods)

#### F5. Why `_redirects` (not CF Worker) for "redirect magic"?
- `_redirects` is native to Netlify CDN edge — zero added latency
- Free, no extra service
- Country-level granularity is enough for v1 (most traffic is country-level)
- Hard limit: 2,500 redirect rules per site
- Upgrade path: Netlify Edge Function for sub-country routing, then CF Worker at apex if needed

#### F6. Why ImprovMX (not CF Email Routing) for sub-zones?
- CF Email Routing is zone-level — only works on the apex zone (the one on CF)
- Sub-zones are on Netlify DNS — CF Email Routing doesn't apply
- ImprovMX is MX-based — works on any DNS zone
- Free tier: 25 aliases, 500 emails/day, 1 domain
- Trade-off: ImprovMX requires web signup (no account-creation API)

#### F7. Why `app-<region>-<2-digit-shard>` naming?
- Self-documenting (region visible from URL)
- Easy to grep (`grep app-us-east-`)
- Reserve hexcode (`app-us-east-a1b2`) for v2 when 10+ shards per region
- Pure hexcode (`app-a1b2c3`) only when hiding region info from URL is desirable

### G. Free-tier scaling math

| Pods | Cost (free) | Hot pods | Cost (with upgrades) |
|---|---|---|---|
| 1 | $0 | 0 | $0 |
| 3 | $0 | 0 | $0 |
| 10 | $0 | 1 | $5/mo |
| 30 | $0 | 2-3 | $10-25/mo |
| 100 | $0 | 5-10 | $50-250/mo |
| 1000 | $0 | many | $500-2K/mo (consider Workers for Platforms $25/mo + $0.30/M req) |

**Key insight**: Linear cost scaling. Doubling users → doubling pods → doubling free-tier accounts. Adding one pod costs $0 until that pod's limits are hit.

## How to apply these lessons to a new domain

1. Read `KIT.md` first for the generalized playbook
2. Read this doc for pitfalls to avoid
3. Read `CODEBASE.md` for script reference
4. Read `ARCHITECTURE.md` for a worked example (example.com)
5. Read `FLEET.md` for multi-pod scaling
6. Read `SECURITY.md` for token management
7. Read `PIVOT.md` for the full history of design decisions

When in doubt about a CF API behavior, check:
- https://developers.cloudflare.com/api/ (API reference)
- https://developers.cloudflare.com/<product>/ (product docs)
- https://community.cloudflare.com/ (community forum — search for the error message)
- https://github.com/cloudflare/terraform-provider-cloudflare/issues (GitHub issues — CF engineers respond here)

When in doubt about Netlify API behavior, check:
- https://openapi.netlify.com/ (OpenAPI spec)
- https://docs.netlify.com/ (docs)
- https://answers.netlify.com/ (community forum)

When in doubt about Vercel API behavior, check:
- https://vercel.com/docs/rest-api (API reference)
- https://vercel.com/docs (general docs)
- https://vercel.com/changelog (recent changes)

When in doubt about ToS:
- Read the actual TOS document (don't rely on blog posts — they may be outdated)
- Look for the "Last Updated" date
- Search the TOS text for keywords ("commercial", "non-commercial", "multiple accounts", "free tier")
