# Codebase Guide — Script Reference

> **Status**: Reference for every script in `scripts/`. Read alongside `KIT.md` and `ARCHITECTURE.md`.
> **Order**: Scripts are numbered by execution order. Re-running earlier scripts is safe (idempotent).

## Script inventory

| # | Script | Purpose | Idempotent? |
|---|---|---|---|
| 00 | `00_validate_all.sh` | Validate all credentials in parallel (reads secrets.json — never hardcoded) | ✅ |
| 00b | `00b_rebuild_state.py` | Rebuild `state.json` from CF + Netlify API (DR recovery) | ✅ |
| 01 | `01_create_zones.py` | Create CF root zone | ✅ |
| 02 | `02_probe_token_perms.py` | Introspect what permissions a CF token has | ✅ |
| 03 | `03_mint_scoped_tokens.py` | Mint scoped CF API tokens (with 23 perms) | ✅ |
| 04 | `04_dump_perm_catalog.py` | Dump CF permission group catalog (reference) | ✅ |
| 06 | `06_configure_root_zone.py` | Full root zone config: DNS + Worker Routes + Email Routing | ✅ |
| 08 | `08_setup_vercel.py` | Create Vercel projects + GH repos for docs/blog | ✅ |
| 10 | `10_attach_vercel_domains.py` | Attach docs./blog. to Vercel projects | ✅ |
| 11 | `11_trigger_vercel_deploys.py` | Trigger Vercel production deploys | ✅ |
| 13 | `13_fix_vercel_build.py` | Push devDependencies + ESLint config to fix Next.js build | ✅ |
| 14 | `14_archive_to_gh.py` | Archive all scripts + docs to private GH repo | ✅ |
| 15 | `15_clean_gh_repo.py` | Remove orphan files from GH repo (after local deletions) | ✅ |
| 18 | `18_migrate_ns_spaceship.py` | Migrate NS at Spaceship → Cloudflare via real API | ✅ |
| 19 | `19_configure_netlify_subzone.py` | Configure Netlify DNS zone for a subdomain | ✅ |
| 20 | `20_final_verify.py` | End-to-end verification (20 checks) | ✅ |
| 21 | `21_mint_admin_token.py` | Mint CF admin token (Account Settings:Write) for 2FA enforcement | ✅ |
| 22 | `22_stamp_all_subdomains.py` | Stamp out all subdomain Netlify DNS zones | ✅ |
| 23 | `23_setup_improvmx.py` | Set up ImprovMX email forwarding (after user provides API key) | ✅ |
| 30 | `30_provision_pod.py` | Provision a new regional pod (stub — exits 2 if not implemented) | ✅ |
| 31 | `31_drift_check.py` | Compare state.json to live CF + Netlify API; report drift | ✅ |
| 32 | `32_enable_transfer_lock.py` | Enable Spaceship transfer lock (manual fallback if API blocked) | ✅ |
| 33 | `33_rotate_master_tokens.py` | Attempt CF master token rotation (FAILED — CF API blocks; documented) | ✅ |
| — | `e2e_test.py` | pytest-compatible end-to-end test suite (~25 tests) | ✅ |
| — | `gitlab_backup.py` | Mirror GitHub repos to GitLab with auto-retry | ✅ |
| — | `Makefile` (root) | Orchestration: `make verify`, `make drift`, `make e2e`, `make ci`, `make deploy` | — |
| — | `.github/workflows/ci.yml` | GitHub Actions CI: verify + drift + e2e + secrets-scan (hourly cron + on push) | — |

## Execution order (fresh build)

```
00_validate_all.sh             # 1. Verify all credentials work
00b_rebuild_state.py           # 2. (Optional) Rebuild state.json if it's missing
01_create_zones.py             # 3. Create CF root zone
03_mint_scoped_tokens.py       # 4. Mint scoped CF tokens
06_configure_root_zone.py      # 5. Configure DNS records + Worker + Email Routing (root)
18_migrate_ns_spaceship.py     # 6. Migrate NS at registrar → CF (one-time)
22_stamp_all_subdomains.py     # 7. Create all Netlify DNS zones + NS delegation
08_setup_vercel.py             # 8. Create Vercel projects for docs/blog
10_attach_vercel_domains.py    # 9. Attach docs./blog. to Vercel projects
13_fix_vercel_build.py         # 10. Push devDependencies + eslint config
11_trigger_vercel_deploys.py   # 11. Trigger production deploys
20_final_verify.py             # 12. End-to-end verification (20 checks)
14_archive_to_gh.py            # 13. Archive everything to GitHub
```

## Execution order (operational / maintenance)

```
make verify                    # 20-check live verification (run anytime)
make drift                     # state.json vs live API drift detection
make e2e                       # pytest suite
make ci                        # full CI suite (verify + drift + e2e + secrets-check)
make rebuild-state             # DR recovery — fetch live state from APIs
make archive                   # backup to GitHub
make secrets-check             # scan for hardcoded tokens
make deploy                    # full deploy sequence (idempotent)
```

## CI/CD (GitHub Actions)

`.github/workflows/ci.yml` runs on every push + hourly cron:
- **verify** job — runs `20_final_verify.py` against live infra
- **drift** job — rebuilds state, runs `31_drift_check.py`
- **e2e** job — runs `e2e_test.py` (~25 tests)
- **secrets-scan** job — scans for hardcoded token patterns (cfat_/cfut_/nfp_/vcp_/ghp_)

Required GitHub Actions secret: `SECRETS_JSON` (the entire contents of `infra/secrets.json`).

## Detailed script reference

### `00_validate_all.sh` — Validate all credentials

**Purpose**: Verify all credentials in `secrets.json` actually work before running other scripts. Runs in parallel for speed.

**Usage**: `bash scripts/00_validate_all.sh`

**Output**: `infra/credentials_inventory.json` — aggregated results of every credential probe.

### `00b_rebuild_state.py` — Rebuild state.json

**Purpose**: Rebuild `infra/state.json` from scratch by querying CF + Netlify APIs. Useful after session reset or as disaster recovery.

**Usage**: `python3 scripts/00b_rebuild_state.py`

**Output**: Updates `infra/state.json` with current zone ID, NS, status, worker routes, email routing status, and all Netlify sub-zones. Sets file mode 0600.

### `01_create_zones.py` — Create CF root zone

**Purpose**: Create the apex CF zone at CF MAIN account.

**Usage**: `python3 scripts/01_create_zones.py`

**Idempotent**: Yes. If zone already exists, reuses it.

### `03_mint_scoped_tokens.py` — Mint scoped CF tokens

**Purpose**: Mint operational CF API tokens scoped to a single account, with 23 permission groups (Zone, DNS, Workers, KV, R2, Email Routing, Pages, Account Settings, SSL).

**Usage**: `python3 scripts/03_mint_scoped_tokens.py`

**Token required**: Master `cfat_` token (the one with `Account API Tokens:Edit` permission).

### `06_configure_root_zone.py` — Configure root zone (main workhorse)

**Purpose**: Full configuration of the apex CF zone:
- Create DNS records (apex A, www CNAME, docs/blog/help CNAMEs, NS delegation for sub-zones, SPF, DMARC, MTA-STS, CAA)
- Deploy CF Worker
- Bind Worker via Worker Routes
- Enable Email Routing + set up catch-all rule

**Usage**: `python3 scripts/06_configure_root_zone.py`

**CAA records**: Uses direct POST with structured `data` field (not `upsert_record` which would silently truncate multi-value records).

**Worker binding**: Uses Worker Routes (`POST /zones/{id}/workers/routes`) not Worker Custom Domain (which has a non-obvious endpoint URL). See `LESSONS.md` B2 + B3.

### `08_setup_vercel.py` — Set up Vercel projects

**Purpose**: Create Vercel projects for docs/blog, link to GH repos, populate with Next.js starter content.

**Usage**: `python3 scripts/08_setup_vercel.py`

### `10_attach_vercel_domains.py` — Attach Vercel domains

**Purpose**: Attach `docs.example.com` and `blog.example.com` to existing Vercel projects.

**Usage**: `python3 scripts/10_attach_vercel_domains.py`

### `11_trigger_vercel_deploys.py` — Trigger Vercel production deploys

**Purpose**: Trigger production deployments for Vercel projects.

**Usage**: `python3 scripts/11_trigger_vercel_deploys.py`

### `13_fix_vercel_build.py` — Fix Vercel Next.js build

**Purpose**: Push missing devDependencies + ESLint config to fix Next.js build on Vercel.

**Usage**: `python3 scripts/13_fix_vercel_build.py`

### `14_archive_to_gh.py` — Archive to GitHub

**Purpose**: Archive all scripts + docs to private GH repo.

**Usage**: `python3 scripts/14_archive_to_gh.py`

**Excludes** (via `.gitignore`): `infra/secrets.json`, `infra/state.json`, `infra/perms_*.json`, `tool-results/`, `skills/`, `upload/`, `domain-infra-kit/`.

### `15_clean_gh_repo.py` — Clean GH repo orphans

**Purpose**: Remove orphan files from GH repo after local script deletions. Recursively walks the GH repo tree via Git Trees API.

**Usage**: `python3 scripts/15_clean_gh_repo.py`

### `18_migrate_ns_spaceship.py` — Migrate NS at Spaceship

**Purpose**: Migrate domain NS from Spaceship defaults to CF-assigned NS via real Spaceship API.

**Usage**: `python3 scripts/18_migrate_ns_spaceship.py`

**API**: `PUT /v1/domains/{domain}/nameservers` at `https://spaceship.dev/api` with `X-Api-Key` + `X-Api-Secret` headers.

### `19_configure_netlify_subzone.py` — Configure Netlify sub-zone

**Purpose**: Create Netlify DNS zone for a subdomain, add DNS records, add NS delegation in CF root zone.

**Usage**: `python3 scripts/19_configure_netlify_subzone.py`

### `20_final_verify.py` — End-to-end verification

**Purpose**: 20-check end-to-end verification of the infrastructure.

**Usage**: `python3 scripts/20_final_verify.py`

**Checks**: CF zone status, public DNS (3 resolvers), apex records (A/SPF/DMARC/MTA-STS), NS delegation, Worker HTTP, Email Routing, Vercel deployments, CNAME resolution.

### `21_mint_admin_token.py` — Mint CF admin token

**Purpose**: Mint a CF token with `Account Settings:Write` permission, for 2FA enforcement.

**Usage**: `python3 scripts/21_mint_admin_token.py`

### `22_stamp_all_subdomains.py` — Stamp out all subdomain zones

**Purpose**: Stamp out all Netlify DNS zones in one script run.

**Usage**: Edit `ALL_SUBDOMAINS` list at top of script, then `python3 scripts/22_stamp_all_subdomains.py`

**Per subdomain**: Creates Netlify zone + 7 DNS records (A, CNAME, SPF, DMARC, MTA-STS, 2 CAA) + 4 NS delegation records in CF root zone.

### `23_setup_improvmx.py` — Set up ImprovMX email forwarding

**Purpose**: Set up ImprovMX email forwarding for sub-zones (requires user-supplied API key).

**Prerequisite**: Sign up at https://improvmx.com (web only, no API for account creation) and save API key to `secrets.json` as `improvmx_api_key`.

**Usage**: `python3 scripts/23_setup_improvmx.py`

### `30_provision_pod.py` — Provision a regional pod (stub)

**Purpose**: Provision a new regional pod (e.g., `app-us-east-01`). Currently a stub — exits with code 2.

**Usage**: `python3 scripts/30_provision_pod.py app-us-east-01`

See `FLEET.md` Phase 3 for planned implementation.

### `31_drift_check.py` — Drift detection

**Purpose**: Compare `state.json` to live CF + Netlify API state. Detects: DNS record changes, Netlify zone add/remove, Worker route changes, Email Routing disable, NS delegation breakage.

**Usage**: `python3 scripts/31_drift_check.py` or `make drift`

**Exit codes**: 0 = no drift, 1 = drift detected, 2 = API error.

### `32_enable_transfer_lock.py` — Enable Spaceship transfer lock

**Purpose**: Prevent unauthorized domain transfers if Spaceship account is compromised.

**Status**: May be blocked by Spaceship API (Cloudflare 1010 browser_signature_banned). Falls back to manual instructions.

**Usage**: `python3 scripts/32_enable_transfer_lock.py`

### `33_rotate_master_tokens.py` — Attempt CF master token rotation

**Purpose**: Attempt to rotate CF master tokens via API. **FAILED** — CF API blocks sub-tokens from having `Account API Tokens:Write` permission. Kept as documentation of the limitation.

**Usage**: `python3 scripts/33_rotate_master_tokens.py` (will exit with error explaining the limitation)

### `e2e_test.py` — pytest e2e suite

**Purpose**: pytest-compatible end-to-end test suite (~25 tests).

**Tests**: DNS resolution (3 resolvers), apex records (A/SPF/DMARC/MTA-STS/CAA), MX records, per-subzone NS delegation (parametrized), Worker HTTP, Vercel docs/blog, SSL cert validity, state.json consistency.

**Usage**: `python3 scripts/e2e_test.py` or `pytest scripts/e2e_test.py -v` or `make e2e`

### `gitlab_backup.py` — GitLab mirror with retry

**Purpose**: Mirror GitHub repos to GitLab with automatic retry (403/429 rate limits). Falls back to GitLab Repository Files API if git push fails.

**Usage**:
```bash
python3 scripts/gitlab_backup.py                    # backup both repos
python3 scripts/gitlab_backup.py --daemon             # run continuously (every 5 min)
python3 scripts/gitlab_backup.py --api-only           # use API fallback only
```

## Common patterns used across scripts

### CF API helper
```python
def cf(method, path, token, body=None, expect_json=True):
    # Returns (status_code, parsed_json_or_raw_text)
    # Handles HTTPError, JSON decode errors, empty responses
```

### Idempotent DNS record creation
- Check existing records before POST
- Match by `(type, name, value)` for single-value records
- Use direct POST with structured `data` field for multi-value records (CAA, MX)

### Project root resolution
```python
PROJECT_ROOT = pathlib.Path(__file__).resolve().parent.parent
SECRETS = json.loads((PROJECT_ROOT / 'infra' / 'secrets.json').read_text())
```
This makes scripts portable — works from any working directory, not just `/home/z/my-project/`.

## Troubleshooting script failures

| Symptom | Likely cause | Fix |
|---|---|---|
| `KeyError: 'root_zone_token'` | secrets.json missing or wiped | Run `00_validate_all.sh` then `03_mint_scoped_tokens.py` |
| `FileNotFoundError: state.json` | state.json wiped | Run `00b_rebuild_state.py` |
| `403 Authentication error` (CF) | Token lacks required permission | Run `02_probe_token_perms.py` to introspect, then `03_mint_scoped_tokens.py` |
| `400 Active zone required` (CF Email Routing) | Zone NS not yet propagated | Wait 5-30 min after running `18_migrate_ns_spaceship.py` |
| `400 Invalid request: should NOT have additional property X` (Vercel) | Wrong field name | Use `gitRepository` (not `gitSource`) for project creation; use `gitSource` for deployment trigger |
| `ECONNREFUSED` (Spaceship) | Wrong API endpoint | Use `https://spaceship.dev/api` (NOT `api.spaceship.net`) |
| `Makefile: missing separator` | Tabs converted to spaces | Run `sed -i 's/^        /\t/' Makefile` |
