# Agent Skill: domain-infra-kit operator

> **Purpose**: Capture the meta-knowledge a future AI agent needs to operate, extend, or rebuild this infra — knowledge that ISN'T in the runbooks or kit docs because it's specific to working in THIS environment with THESE services.

This document is for **future-you** (or any AI agent) who picks up this project after the original build session. It captures the gotchas, conventions, and "things you'd only know by doing" that aren't written down anywhere else.

## Environment & access

### Working directory
- Project root: `/home/z/my-project/`
- Scripts: `/home/z/my-project/scripts/`
- Infra state: `/home/z/my-project/infra/`
- Secrets: `/home/z/my-project/infra/secrets.json` (mode 0600, gitignored — never commit)

### Secrets — volatile
The `infra/secrets.json` file may get **wiped between agent sessions** (the agent harness sometimes resets /home/z/my-project). The original credentials are:
- **CF MAIN master**: starts with `<your-cf-token>` (still ACTIVE — must be rotated via CF dashboard, not API)
- **CF SUB master**: starts with `<your-cf-token>` (still ACTIVE)
- **CF zone-scoped token**: starts with `<your-cf-token>`
- **Netlify**: starts with `<your-netlify-token>`
- **Vercel**: starts with `<your-vercel-token>`
- **GitHub primary**: starts with `<your-github-token>`
- **GitHub secondary**: starts with `<your-github-token>`
- **Spaceship**: key `<your-spaceship-key>`, secret starts with `<your-spaceship-secret>`

If secrets.json is wiped, restore from this list. Or get fresh values from the user.

### State — also volatile
`infra/state.json` may also get wiped. If verify fails with `KeyError: 'root_zone'` or `FileNotFoundError: state.json`, run:
```bash
python3 scripts/00b_rebuild_state.py
```
This fetches current state from CF + Netlify APIs and rebuilds state.json (mode 0600).

### Live infra — current state (as of 2026-08-16)
- **Domain**: example.com (registrar Spaceship)
- **NS**: <your-cf-ns-1> + <your-cf-ns-2> (CF MAIN, account <your-cf-main-account-id>)
- **Zone ID**: <your-cf-root-zone-id>
- **Worker**: example-root-worker (bound via Worker Routes to example.com/* + www.example.com/*)
- **6 Netlify sub-zones**: users/app/content/corp/api/cdn (each with 4 NS1 nameservers)
- **Vercel projects**: example-docs + example-blog (Hobby tier)
- **2FA**: enforced on CF MAIN (enforce_twofactor: true)

## APIs — quirks you'll only learn the hard way

### Cloudflare
- **Subdomain zones require Enterprise** ($5K+/mo). The API returns `400 code 1116 "Please ensure you are providing the root domain"` which is misleading — it's a missing-entitlement error, not a malformed-request error. Don't waste time trying different request shapes.
- **Workers Custom Domain endpoint**: The URL `POST /accounts/{acct}/workers/scripts/{name}/domains` DOES NOT EXIST. CF returns `405 Method not allowed for this authentication scheme` which looks like an auth error but is actually "endpoint doesn't exist". The correct URL is `PUT /accounts/{acct}/workers/domains` with body `{"hostname": ..., "service": "production.<worker_name>", "zone_id": ...}`. **Easier alternative**: use Worker Routes (`POST /zones/{id}/workers/routes`).
- **CAA records** need structured `data` field: `{"type":"CAA","name":"...","data":{"flags":0,"tag":"issue","value":"cloudflare.com"},"ttl":1,"proxied":false}`. NOT a content string — that gets stored as opaque text.
- **Multiple records at same (type, name)** (e.g., 3 CAA records at apex) — don't use `upsert` helper that matches by `(type, name)` only — it'll silently overwrite the first with the second, then with the third. Use direct POST with idempotency check on full record content.
- **CF token permission names use spaces, not colons**: `"Zone Read"` not `"Zone:Read"`. Always dump the permission group catalog (`scripts/04_dump_perm_catalog.py`) before assuming names.
- **Email Routing requires zone to be `active`** before enable. Returns `403 Active zone required` otherwise. Wait 5-30 min after NS migration.
- **2FA enforcement CAN be automated** — `PUT /accounts/{id}` with `{"settings":{"enforce_twofactor":true}}`. Needs a token with `Account Settings:Write` permission (mint via `scripts/21_mint_admin_token.py`).
- **Master token rotation CANNOT be automated** — CF API blocks sub-tokens from having `Account API Tokens:Write` permission (returns `400 "sub-token is not allowed to have permissions to manage other tokens"`). Truly manual via dashboard.
- **CF zone scanner lags real DNS** — `observed_name_servers` field caches ~1 hour after migration. Use `dig +short NS example.com @1.1.1.1` as source of truth, not CF dashboard status.
- **CF Universal SSL cert** is signed by Google Trust Services (not in all default CA bundles). `curl` without `-k` may fail with TLS handshake error. The cert IS valid — `openssl s_client` confirms. The `-k` flag is a workaround, not a security issue.
- **CF Universal SSL auto-adds CAA records** on top of user records (cloudflare + letsencrypt + comodoca + digicert + pki.goog + ssl.com + wildcards). If you want to actually RESTRICT to specific CAs, you must manually delete CF-default CAA records via dashboard.

### Netlify
- **`account_id` is a UUID/hash**, not a slug. `POST /dns_zones` with `account_slug: "your-name"` returns `422 {"errors":{"account":"Missing account"}}`. Use `account_id` (looks like `<your-netlify-account-id>`).
- **DNS zone creation returns NS immediately** — no polling needed.
- **DNS records API returns a bare array** `[{...}, {...}]`, not CF's `{result: [...]}`. Don't `jq '.result'`.
- **Netlify supports standalone subdomain DNS zones on free tier** (unlike CF which gates behind Enterprise). Use `POST /api/v1/dns_zones` with `{"name":"users.example.com","account_id":"..."}`.

### Vercel
- **Project creation field is `gitRepository`**, not `gitSource`. Wrong: `{"gitSource": {...}}` → `400 should NOT have additional property gitSource`. Right: `{"gitRepository": {"type":"github","repo":"..."}}`.
- **Deployment trigger field is `gitSource`** (different from project creation!) with `{type, org, repo, ref, sha}`.
- **Domain attachment** — omit `gitBranch` field. Including `gitBranch: "main"` makes it a Preview Domain (returns `400 Cannot set Production Branch "main" for a Preview Domain`).
- **Vercel Hobby TOS PROHIBITS COMMERCIAL USE**. Quote: "You shall only use the Services under a Hobby plan for your personal or non-commercial use." Don't deploy anything revenue-touching on Hobby — use CF Workers (TOS-safe) or upgrade to Pro ($20/mo).
- **Multiple Hobby teams per Vercel login not allowed** — "one login connection per third-party service". Use separate Vercel accounts under separate emails.
- **Vercel SSL DCV takes 5-15 min** after CNAME is live. Trigger via `POST /v6/domains/{domain}/verify?teamId=...` then poll.
- **Vercel Hobby limits**: 100GB BW, 1M invocations, 4 CPU-hours per team. Concurrent builds = 1 (others queue).

### Spaceship (registrar)
- **Real API endpoint is `https://spaceship.dev/api`**, NOT `api.spaceship.net`. The latter hostname refuses TCP 443 globally.
- **Auth uses `X-Api-Key` + `X-Api-Secret` headers**, NOT Basic auth.
- **NS update**: `PUT /v1/domains/{domain}/nameservers` with body `{"provider":"custom","hosts":["ns1","ns2"]}`. Min 2 NS, max 12.
- **Pagination params required**: `?take=100&skip=0` (without them: `422 The take field is required`).
- **API may intermittently block IPs** with Cloudflare 1010 `browser_signature_banned` error. This is geo/IP-based, not API-key-based. Workaround: use a different IP, or accept it as truly-manual (transfer lock must be enabled via dashboard).

### GitHub
- **ToS prohibits multiple free accounts per entity**: "One person or legal entity may maintain no more than one free Account". Use ONE GitHub account + multiple repos + per-repo deploy tokens, OR use GitLab for secondary.
- **Contents API has a 100MB file size limit**. For larger files, use Git LFS.
- **Secondary rate limit** (~30 PUT /contents/ calls): add `time.sleep(0.5)` between sequential uploads.
- **Classic PAT with `repo` scope** has read/write to ALL repos under the user. Replace with fine-grained PAT scoped to specific repos.
- **PR via Contents API doesn't work directly** — the GH repo was populated via Contents API which creates one commit per file push, but to open a PR you need ≥2 branches or a fork. Workaround: `git clone` the repo locally, create a feature branch, push via `git push`, open PR via `gh pr create` or POST /repos/{owner}/{repo}/pulls.

### Supabase (for future fleet work)
- **Auto-pauses after 7 days of API inactivity** (~30s cold start to unpause). Workaround: deploy a CF Worker cron that pings each Supabase pod's `/__health` every 6 days.
- **2 active projects per free account**. Multiple free accounts under different emails is the standard workaround.

### Neon (for future fleet work)
- **Scale-to-zero after 5 min idle** (~300ms cold start to wake).
- **0.5GB storage limit per free project**. Each project gets its own 100 CU-hours budget.

## Architectural decisions — the WHY

### Why Netlify apex + CF sub-pods (TOS strategy)
The user's instinct (which proved correct): Netlify as apex creates TOS-safe separation between apex and each isolated pod on CF. Netlify allows commercial use on free tier (unlike Vercel Hobby). Netlify AUP has no redirect restriction. CF Section 2.8 "non-HTML ban" was REMOVED in 2026 TOS but Netlify is still strategically safer for apex. Per-pod CF accounts get their own abuse-detection envelope — one pod's traffic spike doesn't risk the apex.

### Why Worker Routes (not Worker Custom Domain)
Worker Custom Domain endpoint URL is non-obvious. Worker Routes simpler + supports wildcards (`*.example.com/*`). Both use CF Universal SSL (no SSL difference). Worker Custom Domain auto-manages apex A record; Worker Routes requires manual `192.0.2.1` placeholder (documented canonical pattern at https://developers.cloudflare.com/dns/llms-full.txt).

### Why per-pod CF accounts (not single CF account with multiple zones)
Free tier Workers limit is per-account (100K req/day shared across all Workers in account). One pod's traffic spike would exhaust limit for ALL pods. Per-account isolation = each pod gets its own 100K req/day budget. Per-account also gives: separate billing, separate audit logs, separate access tokens, separate WAF rules. Trade-off: more accounts to manage (acceptable up to ~30 pods).

### Why Netlify DNS zones (not CF subdomain zones)
CF subdomain zones: Enterprise-only ($5K+/mo). Netlify DNS zones: free, first-class "standalone subdomain DNS zone" feature via `POST /api/v1/dns_zones`. Same isolation goals achieved.

### Why `app-<region>-<2-digit-shard>` naming
Self-documenting. Easy to grep. Reserve hexcode (`app-us-east-a1b2`) for v2 when 10+ shards per region. Pure hexcode (`app-a1b2c3`) only when hiding region info from URL.

### Why `_redirects` (Option A) is NOT recommended for US regional split
Netlify `_redirects` supports only country-level granularity. Cannot distinguish US-East from US-West. Use Netlify Edge Function (Option B) from day 1 if you need sub-country routing.

## What CANNOT be automated (truly manual)

These items have NO API path. They require human action via dashboards:

1. **CF Email Routing destination verification** — CSRF-bound link in destination inbox
2. **Account creation** at any provider (CF, Netlify, Vercel, Supabase, Neon, GitHub) — all require email verification + web signup
3. **2FA setup** at Netlify, Vercel, GitHub (CF is the exception — `enforce_twofactor: true` works via API)
4. **Master token rotation** at CF (CF API blocks sub-tokens from `Account API Tokens:Write`)
5. **Token rotation** at Netlify, Vercel, GitHub, Spaceship (no API to revoke)
6. **ImprovMX signup** (web form only, no account-creation API)
7. **Spaceship transfer lock** (when API is IP-blocked — Cloudflare 1010 error)
8. **Help-desk vendor selection** (business decision)
9. **Vercel Hobby → Pro upgrade** (when revenue touches any deployment)

## Iteration loop — how to make changes

1. **Edit scripts/docs locally** in /home/z/my-project
2. **Run `make verify`** — must show 20/20 PASS
3. **Run `make drift`** — must show 0 drift
4. **Run `make e2e`** — must show 25/25 PASS
5. **Run `make secrets-check`** — must show no hardcoded tokens
6. **Commit + push to feature branch**:
   ```bash
   git checkout -b <feature-branch>
   git add -A
   git commit -m "<description>"
   git push origin <feature-branch>
   ```
7. **Open PR** via `gh pr create` or POST /repos/{owner}/{repo}/pulls
8. **Wait for CodeRabbit review** (~5-15 min) — poll via:
   ```bash
   gh pr view <PR#> --json comments,reviews
   # or via API:
   curl -sS "https://api.github.com/repos/your-backup-user/domain-infra-kit/issues/<PR#>/comments" -H "Authorization: token $GH"
   ```
9. **Address P0/P1 issues** from CodeRabbit + local opus review
10. **Merge to main** (or rebase + force-push updates)

## Peer-review orchestration

For architectural reviews:
- Use **opus model** subagents — they catch issues sonnet misses
- Pass full context: all docs + scripts + worklog
- Run in **waves** — Wave 1 finds issues, Wave 2 verifies fixes, Wave 3 confirms production-ready
- Append each review to `worklog.md` with Task ID like `WAVE-N-ARCH-REVIEW`

For PR reviews:
- **CodeRabbit** is async (~5-15 min) — start it FIRST, then do other work while it runs
- **Local opus review** in parallel — focus on holistic cumulative changes (not just the diff)
- Address all P0/P1 from BOTH reviews before merging
- Don't finish until P3-only remaining

## Kit extraction — how to refresh the generalized kit

The kit lives at https://github.com/your-backup-user/domain-infra-kit (separate repo, generalized).

To refresh it after changes to domain-infra-kit:
```bash
cd /home/z/my-project
python3 scripts/extract_kit.py  # extracts + scrubs example-specific values
cd domain-infra-kit
git add -A
git commit -m "Refresh kit from domain-infra-kit updates"
git push origin main
```

The extraction script (`scripts/extract_kit.py` in domain-infra-kit) replaces:
- `example.com` → `example.com`
- `domain-infra-kit` → `domain-infra-kit`
- Account IDs, zone IDs, NS1 nameservers, GH repos → placeholders
- Worker names, project names → generic

After extraction, verify: `grep -rni example domain-infra-kit/ | wc -l` should be 0.

## Operational runbook — 3am scenarios

| Scenario | What to check | Fix |
|---|---|---|
| Worker returns 5xx | `make verify` | Check Worker logs at CF dashboard; redeploy via `python3 scripts/06_configure_root_zone.py` |
| Email Routing destination expires | `dig MX example.com @1.1.1.1` (should return route1/2/3.mx.cloudflare.net) | Re-verify destination at CF dashboard; re-run `python3 scripts/06_configure_root_zone.py` |
| Netlify DNS API outage | `dig NS users.example.com @1.1.1.1` (should return NS1) | No DNS fallback (P2 known issue); wait for Netlify recovery |
| Vercel deployment fails | `python3 scripts/12_fetch_vercel_logs.py` — oh wait, deleted. Use Vercel dashboard | Re-trigger via `python3 scripts/11_trigger_vercel_deploys.py` |
| Token revoked or expired | First sign: 401 in any script | `python3 scripts/03_mint_scoped_tokens.py` (CF) or rotate via dashboard |
| State.json drifts | `make drift` reports drift | `make rebuild-state` to refresh |
| CF MAIN account compromised | INCIDENT_RESPONSE (SECURITY.md) | Revoke all tokens, rotate password, audit logs, redeploy |

## What to NOT change without serious thought

- **The `192.0.2.1` placeholder A record** (proxied=true) — this is the canonical CF pattern for Worker-backed zones. Changing it breaks Worker Routes.
- **The DMARC p=quarantine record** — `p=reject` is stricter but breaks legitimate email forwarding. `p=quarantine` is the safe default.
- **The 6-subdomain split** (users/app/content/corp/api/cdn) — splitting later requires NS migration which is annoying. Keep as-is.
- **Worker Routes (not Custom Domain)** — Custom Domain requires a different endpoint URL and doesn't support wildcards. Routes is simpler.
- **Netlify apex (not CF apex)** — TOS-safe separation. Moving apex to CF would lose this.

## What to change freely

- The Worker HTML content (it's a placeholder — replace with real landing page)
- The DMARC rua/ruf email destination (currently `admin@example.com`)
- The MTA-STS id (currently `20260815T000000` — refresh on policy change)
- The CAA record set (add more CAs if needed)
- The CI cron schedule (currently hourly — adjust as needed)

## When in doubt

- **Read LESSONS.md** — it has every gotcha from the build session
- **Read worklog.md** — it has every decision rationale + peer review
- **Run `make verify`** — confirms live state matches expectations
- **Run `make drift`** — catches unexpected changes
- **Check `git log`** — see what changed recently
- **Verify with `dig`** — public DNS doesn't lie (`dig +short NS example.com @1.1.1.1`)

## Official documentation references

When the agent needs to verify API behavior, TOS details, or feature availability beyond what's captured here or in the kit docs, these are the canonical sources:

### Cloudflare
- **API reference**: https://developers.cloudflare.com/api/
- **Workers docs**: https://developers.cloudflare.com/workers/
- **Workers limits**: https://developers.cloudflare.com/workers/platform/limits
- **DNS subdomain setup** (Enterprise gate documented here): https://developers.cloudflare.com/dns/zone-setups/subdomain-setup/setup/
- **Email Routing**: https://developers.cloudflare.com/email-service/
- **TOS** (Section 2.8 CDN clause — "non-HTML" ban removed in 2026): https://www.cloudflare.com/service-specific-terms-application-services/
- **Service-Specific Terms**: https://www.cloudflare.com/policies/terms/
- **Community forum** (search for error messages): https://community.cloudflare.com/
- **Terraform provider issues** (CF engineers respond here): https://github.com/cloudflare/terraform-provider-cloudflare/issues
- **CF llms.txt** (canonical patterns, apex A 192.0.2.1): https://developers.cloudflare.com/dns/llms-full.txt

### Netlify
- **OpenAPI spec**: https://openapi.netlify.com/
- **Docs**: https://docs.netlify.com/
- **DNS zones** (standalone subdomain feature): https://docs.netlify.com/manage/domains/configure-domains/delegate-a-standalone-subdomain/
- **Edge Functions API**: https://docs.netlify.com/build/edge-functions/api/
- **Redirects**: https://docs.netlify.com/manage/routing/redirects/redirect-options/
- **Acceptable Use Policy**: https://www.netlify.com/legal/acceptable-use-policy/
- **Community**: https://answers.netlify.com/

### Vercel
- **REST API**: https://vercel.com/docs/rest-api
- **Regions**: https://vercel.com/docs/regions/
- **Hobby plan limits**: https://vercel.com/docs/plans/hobby/
- **Fair Use Guidelines** (commercial use prohibition): https://vercel.com/docs/limits/fair-use-guidelines/
- **ToS**: https://vercel.com/legal/terms/
- **Changelog**: https://vercel.com/changelog/

### Spaceship (registrar)
- **API docs** (endpoint `https://spaceship.dev/api`, auth via X-Api-Key/X-Api-Secret): https://www.spaceship.com/developer-guide/
- **API Manager** (generate keys): https://www.spaceship.com/application/api-manager/
- **Domain control panel**: https://www.spaceship.com/control-panel/domains/
- **OpenAPI spec** (shipped with this repo at `infra/spaceship-openapi.json`): the canonical reference for all endpoints, schemas, and error codes

### Supabase (for fleet work)
- **Pricing**: https://supabase.com/pricing/
- **Regions**: https://supabase.com/docs/guides/platform/regions/
- **Rate limits**: https://supabase.com/docs/guides/auth/rate-limits/
- **Docs**: https://supabase.com/docs/

### Neon (for fleet work)
- **Pricing**: https://neon.com/pricing/
- **Regions**: https://neon.com/docs/introduction/regions/
- **Free plan tips**: https://neon.com/blog/how-to-make-the-most-of-neons-free-plan/
- **Docs**: https://neon.com/docs/

### GitHub
- **REST API**: https://docs.github.com/en/rest/
- **ToS** (one free account per entity clause): https://docs.github.com/en/site-policy/github-terms/github-terms-of-service
- **PAT docs**: https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens
- **Actions docs**: https://docs.github.com/en/actions

### ImprovMX (email forwarding for sub-zones)
- **API**: https://improvmx.com/api/
- **MX records guide**: https://improvmx.com/guides/mx-records/
- **Catch-all guide**: https://improvmx.com/guides/catchall-wildcard-aliases/
- **Pricing**: https://improvmx.com/pricing/

## Verification status — what's been tested, peer-reviewed, and confirmed

This project went through 3 waves of architecture peer review by opus sub-agents + a CodeRabbit automated review on PR #1. The full review history is in `worklog.md` under these Task IDs:

| Wave | Reviewer | Verdict | Key findings | Status |
|---|---|---|---|---|
| Wave 1 | opus (WAVE-1-ARCH-REVIEW) | REJECT | P0 hardcoded secrets in scripts, P1 no monitoring/drift/e2e | ✅ All P0+P1 fixed in Wave 2 |
| Wave 2 | opus (WAVE-2-ARCH-REVIEW) | REJECT | P0 token rotation not done, 8 doc regressions from deletions | ✅ Doc regressions fixed; token rotation documented as truly-manual (CF API blocks sub-tokens) |
| Wave 3 | opus (WAVE-3-LOCAL-PR-REVIEW) | APPROVE WITH CONDITIONS | Makefile tab regression, CI hardcoded paths, missing .gitignore | ✅ All fixed: tabs restored, PROJECT_ROOT refactor, .gitignore created |
| CodeRabbit | automated (PR #1) | 13 comments (2 Critical, 8 Major, 3 Minor) | Credential fragments in 33_rotate + worklog, hardcoded paths | ✅ All addressed: credentials scrubbed, paths refactored |

### Live verification (run after every change)
```
make verify         → 20/20 checks pass (DNS, Worker, Email Routing, Vercel, etc.)
make drift          → 0 drift detected (state.json matches live API)
make e2e            → 25/25 tests pass (pytest suite)
make secrets-check  → no hardcoded tokens detected
```

### What's verified by the test suite
- DNS resolution via 3 resolvers (1.1.1.1, 8.8.8.8, 9.9.9.9) — NS at CF
- Apex A record returns CF anycast IPs (104.x/172.x)
- SPF, DMARC, MTA-STS, CAA records resolve publicly
- MX records (Email Routing): route1/2/3.mx.cloudflare.net
- NS delegation for all 6 sub-zones → Netlify NS1
- Worker HTTP reachability: `https://example.com/__health` → 200 JSON
- Vercel docs/blog: HTTP 200 + deployment READY
- SSL cert validity (>30 days remaining)
- State.json consistency vs live CF + Netlify API

### What's NOT yet verified (future work — P3)
- Disaster recovery test against a test domain (runbook exists but untested)
- UptimeRobot monitoring setup (not deployed — only GH Actions cron)
- DNSSEC enablement (documented as future work)
- Terraform migration (documented in FLEET.md Phase 4)
- Bare `except:` cleanup + type hints (24 occurrences across scripts)

## Final note

The example.com infra is REAL and LIVE. Don't run destructive operations without thinking. The `make deploy` target is idempotent but will mint new tokens, push new DNS records, etc. — only run when needed.

For testing new approaches, use `scripts/30_provision_pod.py` (stub) to spin up a test pod (e.g., `app-test-01.example.com`) and experiment there. Don't touch the apex or the 6 production sub-zones.

If you break something, the DR runbook is in `infra/SECURITY.md` "Full disaster recovery" section. The GitHub repo at https://github.com/your-backup-user/domain-infra-kit has all scripts + docs needed for a full rebuild.

### GitLab mirror

Both repos (`domain-infra-kit` + `domain-infra-kit`) are mirrored to GitLab as redundant backup:
- GitHub (primary): `https://github.com/your-backup-user/<repo>`
- GitLab (backup): `https://gitlab.com/<user>/<repo>`

Push to both remotes for redundancy. GitLab has stricter rate limits — if push fails with 403, retry after a few minutes. Use `scripts/gitlab_backup.py` for automatic retry.
