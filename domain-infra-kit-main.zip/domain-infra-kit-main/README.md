# domain-infra-kit — Multi-Account Custom Domain Infrastructure Kit

> **Status**: Generalized kit extracted from a real multi-account Cloudflare + Netlify + Vercel setup.
> **License**: MIT

A reusable, production-grade infrastructure kit for setting up a custom domain with:
- Multi-account isolation (per-subdomain or per-region CF/Vercel/Netlify accounts)
- Free-tier scaling (linear cost — add pods at $0 each)
- Email Routing (CF on apex, ImprovMX on sub-zones)
- DMARC/MTA-STS/CAA on every zone
- 2FA enforcement (automated on CF via API)
- Drift detection (state.json vs live API)
- E2E test suite (~25 tests)
- CI workflow (GitHub Actions, hourly cron)

## Quick start

```bash
git clone https://github.com/your-gh-user/domain-infra-kit.git
cd domain-infra-kit

# 1. Copy secrets template
cp infra/secrets.json.example infra/secrets.json
# Edit secrets.json with your credentials

# 2. Update DOMAIN and ALL_SUBDOMAINS in scripts:
#    - scripts/06_configure_root_zone.py (DOMAIN constant)
#    - scripts/22_stamp_all_subdomains.py (ALL_SUBDOMAINS list)

# 3. Validate credentials
bash scripts/00_validate_all.sh

# 4. Run deployment
make deploy

# 5. Verify
make verify
make e2e
```

## Documentation

Read in order:
1. `infra/KIT.md` — the generalized playbook (start here)
2. `infra/ARCHITECTURE.md` — architecture pattern + design rationale
3. `infra/FLEET.md` — multi-pod future-proof scaling
4. `infra/LESSONS.md` — pitfalls + gotchas (READ THIS — saves hours)
5. `infra/CODEBASE.md` — every script explained
6. `infra/REPLICATE.md` — add new subdomain recipe
7. `infra/SECURITY.md` — token inventory + 2FA + incident response
8. `infra/PIVOT.md` — design decision history (why certain choices were made)
9. `AGENT.md` — meta-knowledge for AI agents operating this kit

## What's included

- 22 idempotent Python scripts (run in any order, safe to re-run)
- Makefile for orchestration
- GitHub Actions CI workflow (verify + drift + e2e + secrets-scan, hourly cron)
- pytest e2e test suite
- Drift detection script (state.json vs live API)
- Comprehensive documentation (~30K words across 9 docs)

## What's NOT included (truly manual — see SECURITY.md)

- Account creation at any provider (CF, Netlify, Vercel, Supabase, Neon, GitHub)
- 2FA setup at providers that don't expose it via API (Netlify, Vercel, GitHub)
- CF Email Routing destination verification (CSRF-bound link)
- ImprovMX signup (web form only)
- Master token rotation (CF blocks sub-token self-revocation)
- Help-desk vendor selection (business decision)

## License

MIT — see LICENSE file (TODO before publishing).
