#!/usr/bin/env bash
# 00_validate_all.sh — Validate all credentials in parallel and dump JSON inventory.
#
# Reads secrets from infra/secrets.json (NEVER hardcode secrets in scripts).
# Usage:
#   bash scripts/00_validate_all.sh
#
# Output: infra/credentials_inventory.json — aggregated results.

set -uo pipefail

# Locate secrets.json
SECRETS_FILE="${SECRETS_FILE:-$(cd "$(dirname "$0")/.." && pwd)/infra/secrets.json}"
if [ ! -f "$SECRETS_FILE" ]; then
  echo "✗ Missing $SECRETS_FILE"
  echo "  Copy infra/secrets.json.example → infra/secrets.json and fill in real values"
  exit 2
fi

# Helper: pull a key from secrets.json
secret() { python3 -c "import json,sys;print(json.load(open('$SECRETS_FILE'))[sys.argv[1]])" "$1"; }

SP_KEY=$(secret spaceship_key)
SP_SECRET=$(secret spaceship_secret)
CF_MAIN=$(secret cf_main_token)
CF_SUB=$(secret cf_sub_token)
NETLIFY=$(secret netlify_token)
VERCEL=$(secret vercel_token)
GH1=$(secret gh_primary_token)
GH2=$(secret gh_secondary_token)

OUT="$(dirname "$SECRETS_FILE")/credentials_inventory.json"
mkdir -p "$(dirname "$SECRETS_FILE")"
tmp=$(mktemp -d)
trap 'rm -rf $tmp' EXIT

echo "==> [1/9] Spaceship: list domains"
curl -sS -m 20 -X GET "https://spaceship.dev/api/v1/domains?take=10&skip=0" \
  -H "X-Api-Key: $SP_KEY" -H "X-Api-Secret: $SP_SECRET" -H "Accept: application/json" \
  -o "$tmp/spaceship.json" -w '%{http_code}' > "$tmp/spaceship.code"
echo "code=$(cat $tmp/spaceship.code)"

echo "==> [2/9] CF MAIN: /accounts"
curl -sS -m 20 -X GET "https://api.cloudflare.com/client/v4/accounts" \
  -H "Authorization: Bearer $CF_MAIN" \
  -o "$tmp/cf_main_accounts.json" -w '%{http_code}' > "$tmp/cf_main_accounts.code"
echo "code=$(cat $tmp/cf_main_accounts.code)"

echo "==> [3/9] CF MAIN: list zones"
curl -sS -m 20 -X GET "https://api.cloudflare.com/client/v4/zones?per_page=50" \
  -H "Authorization: Bearer $CF_MAIN" \
  -o "$tmp/cf_main_zones.json" -w '%{http_code}' > "$tmp/cf_main_zones.code"
echo "code=$(cat $tmp/cf_main_zones.code)"

echo "==> [4/9] CF SUB: /accounts"
curl -sS -m 20 -X GET "https://api.cloudflare.com/client/v4/accounts" \
  -H "Authorization: Bearer $CF_SUB" \
  -o "$tmp/cf_sub_accounts.json" -w '%{http_code}' > "$tmp/cf_sub_accounts.code"
echo "code=$(cat $tmp/cf_sub_accounts.code)"

echo "==> [5/9] Netlify: /api/v1/user"
curl -sS -m 20 -X GET "https://api.netlify.com/api/v1/user" \
  -H "Authorization: Bearer $NETLIFY" \
  -o "$tmp/netlify_user.json" -w '%{http_code}' > "$tmp/netlify_user.code"
echo "code=$(cat $tmp/netlify_user.code)"

echo "==> [6/9] Netlify: list DNS zones"
curl -sS -m 20 -X GET "https://api.netlify.com/api/v1/dns_zones" \
  -H "Authorization: Bearer $NETLIFY" \
  -o "$tmp/netlify_zones.json" -w '%{http_code}' > "$tmp/netlify_zones.code"
echo "code=$(cat $tmp/netlify_zones.code)"

echo "==> [7/9] Vercel: /v2/user"
curl -sS -m 20 -X GET "https://api.vercel.com/v2/user" \
  -H "Authorization: Bearer $VERCEL" \
  -o "$tmp/vercel_user.json" -w '%{http_code}' > "$tmp/vercel_user.code"
echo "code=$(cat $tmp/vercel_user.code)"

echo "==> [8/9] GitHub primary: /user"
curl -sS -m 20 -X GET "https://api.github.com/user" \
  -H "Authorization: token $GH1" -H "Accept: application/vnd.github+json" \
  -o "$tmp/gh1_user.json" -w '%{http_code}' > "$tmp/gh1_user.code"
echo "code=$(cat $tmp/gh1_user.code)"

echo "==> [9/9] GitHub secondary: /user"
curl -sS -m 20 -X GET "https://api.github.com/user" \
  -H "Authorization: token $GH2" -H "Accept: application/vnd.github+json" \
  -o "$tmp/gh2_user.json" -w '%{http_code}' > "$tmp/gh2_user.code"
echo "code=$(cat $tmp/gh2_user.code)"

# Aggregate into one inventory JSON
python3 - <<PY
import json, os, pathlib
t = pathlib.Path("$tmp")
def load(name):
    p = t / f"{name}.json"
    try:
        return json.loads(p.read_text())
    except Exception as e:
        return {"_error": str(e), "_raw": (p.read_text() if p.exists() else "")}
def code(name):
    p = t / f"{name}.code"
    try:
        return int(p.read_text().strip())
    except Exception:
        return None

inv = {
  "spaceship":         {"code": code("spaceship"),         "body": load("spaceship")},
  "cf_main_accounts":  {"code": code("cf_main_accounts"),  "body": load("cf_main_accounts")},
  "cf_main_zones":     {"code": code("cf_main_zones"),     "body": load("cf_main_zones")},
  "cf_sub_accounts":   {"code": code("cf_sub_accounts"),   "body": load("cf_sub_accounts")},
  "netlify_user":      {"code": code("netlify_user"),      "body": load("netlify_user")},
  "netlify_zones":     {"code": code("netlify_zones"),    "body": load("netlify_zones")},
  "vercel_user":       {"code": code("vercel_user"),       "body": load("vercel_user")},
  "gh1_user":          {"code": code("gh1_user"),          "body": load("gh1_user")},
  "gh2_user":          {"code": code("gh2_user"),          "body": load("gh2_user")},
}
pathlib.Path("$OUT").write_text(json.dumps(inv, indent=2))
print(f"\nInventory written to $OUT")
PY

echo "--- summary ---"
python3 -c "
import json
inv = json.load(open('$OUT'))
for k, v in inv.items():
    code = v.get('code', 0)
    icon = '✓' if 200 <= code < 300 else '✗'
    print(f'  {icon} {k:25s} {code}')
"
