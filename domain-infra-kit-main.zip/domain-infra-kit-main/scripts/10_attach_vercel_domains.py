#!/usr/bin/env python3
"""10_attach_vercel_domains.py — Attach docs.example.com / blog.example.com to existing Vercel projects."""
import json, pathlib, urllib.request, urllib.error
PROJECT_ROOT = pathlib.Path(__file__).resolve().parent.parent

SECRETS = json.loads((PROJECT_ROOT / 'infra' / 'secrets.json').read_text())
API_V = "https://api.vercel.com"
VERCEL_TOKEN = SECRETS["vercel_token"]
VERCEL_TEAM  = SECRETS["vercel_team_id"]

def api(method, url, token, body=None):
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url, data=data, method=method)
    req.add_header("Authorization", f"Bearer {token}")
    if body is not None: req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            text = r.read().decode()
            if not text: return r.status, {}
            try: return r.status, json.loads(text)
            except: return r.status, {"_raw": text}
    except urllib.error.HTTPError as e:
        text = e.read().decode()
        try: return e.code, json.loads(text or "{}")
        except: return e.code, {"_raw": text}

# Fetch all projects
code, body = api("GET", f"{API_V}/v9/projects?teamId={VERCEL_TEAM}", VERCEL_TOKEN)
projects = body.get("projects", [])
print(f"Found {len(projects)} projects")

for proj in projects:
    pid = proj["id"]
    pname = proj["name"]
    print(f"\n  project: {pname} (id={pid[:12]})")
    # Determine target domain
    if "docs" in pname:
        domain = "docs.example.com"
    elif "blog" in pname:
        domain = "blog.example.com"
    else:
        print(f"    skip (not a docs/blog project)")
        continue

    # Check existing domains
    code, body = api("GET", f"{API_V}/v9/projects/{pid}/domains?teamId={VERCEL_TEAM}", VERCEL_TOKEN)
    existing = body.get("domains", [])
    already = [d for d in existing if d.get("name") == domain]
    if already:
        d = already[0]
        print(f"    ✓ domain {domain} already attached (verified={d.get('verified')})")
        continue
    # Attach WITHOUT gitBranch (production domain, not preview)
    code, body = api("POST", f"{API_V}/v9/projects/{pid}/domains?teamId={VERCEL_TEAM}", VERCEL_TOKEN, {
        "name": domain,
    })
    if code in (200, 201):
        print(f"    ✓ domain {domain} attached")
    else:
        msg = body.get("error", {}).get("message", "") if isinstance(body, dict) else ""
        if not msg and isinstance(body, dict):
            msg = body.get("message", str(body)[:200])
        print(f"    ✗ attach failed: code={code} err={msg}")

# Final state — list projects with their domains
print("\n== Final state ==")
code, body = api("GET", f"{API_V}/v9/projects?teamId={VERCEL_TEAM}", VERCEL_TOKEN)
for proj in body.get("projects", []):
    print(f"\n  {proj['name']} ({proj.get('framework', '?')}):")
    pcode, pbody = api("GET", f"{API_V}/v9/projects/{proj['id']}/domains?teamId={VERCEL_TEAM}", VERCEL_TOKEN)
    for d in pbody.get("domains", []):
        print(f"    {d['name']:30s}  verified={d.get('verified')}  src={d.get('gitBranch','prod')}")
