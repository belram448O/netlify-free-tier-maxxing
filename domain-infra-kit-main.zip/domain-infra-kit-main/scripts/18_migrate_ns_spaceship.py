#!/usr/bin/env python3
"""18_migrate_ns_spaceship.py — Migrate example.com NS from Spaceship to Cloudflare.

Uses the REAL Spaceship API at https://spaceship.dev/api (not api.spaceship.net!).
Auth: X-Api-Key + X-Api-Secret headers (NOT Basic auth).

Endpoint: PUT /v1/domains/{domain}/nameservers
Body: {"provider": "custom", "hosts": ["<ns1>", "<ns2>"]}
"""
import json, urllib.request, urllib.error, pathlib
PROJECT_ROOT = pathlib.Path(__file__).resolve().parent.parent

SECRETS = json.loads((PROJECT_ROOT / 'infra' / 'secrets.json').read_text())
SP_KEY = SECRETS['spaceship_key']
SP_SECRET = SECRETS['spaceship_secret']
DOMAIN = SECRETS['domain']

# CF-assigned NS from the root zone we created earlier
STATE = json.loads((PROJECT_ROOT / 'infra' / 'state.json').read_text())
CF_NS = STATE['root_zone']['name_servers']
print(f"CF-assigned NS for {DOMAIN}: {CF_NS}")

# Validate: must be at least 2 NS, max 12
if len(CF_NS) < 2:
    print(f"  FATAL: CF zone has fewer than 2 NS — cannot migrate")
    exit(1)

API_BASE = "https://spaceship.dev/api"
HEADERS = {
    "X-Api-Key": SP_KEY,
    "X-Api-Secret": SP_SECRET,
    "Accept": "application/json",
    "Content-Type": "application/json",
    "User-Agent": "domain-infra-kit/1.0",
}

def sp(method, path, body=None):
    url = f"{API_BASE}{path}"
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url, data=data, method=method)
    for k, v in HEADERS.items():
        req.add_header(k, v)
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            text = r.read().decode()
            if not text: return r.status, {}
            try: return r.status, json.loads(text)
            except: return r.status, {"_raw": text}
    except urllib.error.HTTPError as e:
        text = e.read().decode()
        try: return e.code, json.loads(text)
        except: return e.code, {"_raw": text}

# Step 1: Confirm current NS state
print("\n== Step 1: Get current NS state at Spaceship ==")
code, body = sp("GET", f"/v1/domains/{DOMAIN}")
if code != 200:
    print(f"  ✗ err: {code} {body}")
    exit(1)
current_hosts = body.get('nameservers', {}).get('hosts', [])
current_provider = body.get('nameservers', {}).get('provider', '?')
print(f"  current provider: {current_provider}")
print(f"  current hosts: {current_hosts}")

# Step 2: PUT new NS
print(f"\n== Step 2: Update NS to Cloudflare ({CF_NS}) ==")
code, body = sp("PUT", f"/v1/domains/{DOMAIN}/nameservers", {
    "provider": "custom",
    "hosts": CF_NS,
})
if code == 200:
    new_hosts = body.get('hosts', [])
    print(f"  ✓ NS updated successfully!")
    print(f"     new hosts: {new_hosts}")
    print(f"     provider: {body.get('provider', '?')}")
else:
    print(f"  ✗ update failed: code={code}")
    print(f"     body: {json.dumps(body, indent=2)[:1000]}")
    exit(1)

# Step 3: Verify
print(f"\n== Step 3: Verify NS updated ==")
code, body = sp("GET", f"/v1/domains/{DOMAIN}")
if code == 200:
    hosts = body.get('nameservers', {}).get('hosts', [])
    provider = body.get('nameservers', {}).get('provider', '?')
    print(f"  ✓ verified — provider={provider}")
    print(f"     hosts: {hosts}")
    if sorted(hosts) == sorted(CF_NS):
        print(f"  ✓ MATCHES CF-assigned NS — migration successful!")
    else:
        print(f"  ✗ NS mismatch:")
        print(f"     Spaceship has: {hosts}")
        print(f"     CF expects:    {CF_NS}")

print(f"""
== Next steps ==
- Wait 5–30 min for NS propagation
- Run: python3 scripts/20_final_verify.py
- Watch CF zone status change from 'pending' to 'active'
- Once active, Email Routing will auto-enable (re-run 06_configure_root_zone.py)
""")
