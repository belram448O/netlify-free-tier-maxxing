#!/usr/bin/env python3
"""30_provision_pod.py — Provision a new regional pod.

PREREQUISITE: User has manually created the underlying accounts (CF, Supabase, Neon,
Vercel) and recorded them in infra/pods.csv.

Usage:
  python3 30_provision_pod.py app-us-east-01

The script will:
  1. Read the pod's row from pods.csv
  2. Look up secrets in infra/pods/<pod_id>.json (or fall back to main secrets.json)
  3. Create DNS A record in the parent service's Netlify zone (e.g., add app-us-east-01 to app.example.com zone)
  4. If CF account: mint scoped tokens, deploy Worker, set up Routes
  5. If Supabase: verify project exists, capture connection string
  6. If Neon: verify project exists, capture connection string
  7. Update Netlify apex _redirects to route traffic to the new pod (manual edit for v1)
  8. Print next-steps (verify with dig, curl, etc.)
"""
import csv, json, os, pathlib, sys, urllib.request, urllib.error
PROJECT_ROOT = pathlib.Path(__file__).resolve().parent.parent

PODS_CSV = PROJECT_ROOT / 'infra' / 'pods.csv'
PODS_DIR = PROJECT_ROOT / 'infra' / 'pods'

def load_pods():
    if not PODS_CSV.exists():
        return {}
    with open(PODS_CSV) as f:
        return {row['pod_id']: row for row in csv.DictReader(f)}

def load_pod_secrets(pod_id):
    p = PODS_DIR / f"{pod_id}.json"
    if p.exists():
        return json.loads(p.read_text())
    # Fallback to main secrets.json (for v1 with shared accounts)
    main = PROJECT_ROOT / 'infra' / 'secrets.json'
    if main.exists():
        return json.loads(main.read_text())
    return {}

def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    pod_id = sys.argv[1]
    pods = load_pods()
    if pod_id not in pods:
        print(f"✗ Pod {pod_id} not found in {PODS_CSV}")
        print(f"  Available: {list(pods.keys())}")
        sys.exit(1)
    pod = pods[pod_id]
    print(f"=== Provisioning pod: {pod_id} ===")
    print(f"  service: {pod.get('service')}")
    print(f"  region:  {pod.get('region')}")
    print(f"  shard:   {pod.get('shard')}")
    print()
    print("⚠️  STUB: This script is not yet implemented.")
    print("    See infra/FLEET.md Phase 3 for the planned implementation.")
    print()
    print("    Manual steps required before this script can be fully automated:")
    print("    1. Create CF account at https://dash.cloudflare.com/sign-up")
    print(f"       (use a unique email like admin+{pod_id}@example.com)")
    print("    2. Create Supabase project at https://supabase.com/dashboard")
    print(f"       region: {pod.get('region')}")
    print("    3. Create Neon project at https://neon.com (if DB needed)")
    print(f"       region: aws-{pod.get('region')}")
    print("    4. Add a row to infra/pods.csv with the new account IDs")
    print("    5. Save per-pod secrets to infra/pods/{pod_id}.json")
    print()
    print("    Once the above is done, this script will (TODO):")
    print(f"    a. Add DNS A record for {pod_id}.example.com in the {pod.get('service')}.example.com Netlify zone")
    print(f"    b. Mint scoped CF tokens for the new CF account")
    print(f"    c. Deploy a Worker to the new CF account")
    print(f"    d. Add the pod to the Netlify apex _redirects file")
    print()
    sys.exit(2)  # exit code 2 = "not implemented"

if __name__ == '__main__':
    main()
