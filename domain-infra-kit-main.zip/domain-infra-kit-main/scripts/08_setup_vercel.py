#!/usr/bin/env python3
"""08_setup_vercel.py — Create Vercel projects for docs.example.com and blog.example.com.

Approach:
  - Create a Next.js starter project locally (minimal docs/blog)
  - Push to the your-site-artifacts-user GH account (linked to Vercel)
  - Create Vercel projects pointing at those repos
  - Attach docs.example.com / blog.example.com as project domains
  - Vercel will issue SSL certs once DNS CNAMEs resolve (they already point to cname.vercel-dns.com)
"""
import json, pathlib, sys, time, urllib.request, urllib.error, os, subprocess, tempfile
PROJECT_ROOT = pathlib.Path(__file__).resolve().parent.parent

SECRETS = json.loads((PROJECT_ROOT / 'infra' / 'secrets.json').read_text())
API_V = "https://api.vercel.com"
API_GH = "https://api.github.com"

VERCEL_TOKEN = SECRETS["vercel_token"]
VERCEL_TEAM  = SECRETS["vercel_team_id"]
GH2_TOKEN    = SECRETS["gh_secondary_token"]
GH2_USER     = SECRETS["gh_secondary_user"]
DOMAIN       = SECRETS["domain"]

def api(method, url, token, body=None, expect_json=True):
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url, data=data, method=method)
    req.add_header("Authorization", f"Bearer {token}")
    if body is not None:
        req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            text = r.read().decode()
            if not text: return r.status, {}
            if not expect_json: return r.status, {"_raw": text}
            try: return r.status, json.loads(text)
            except json.JSONDecodeError: return r.status, {"_raw": text}
    except urllib.error.HTTPError as e:
        text = e.read().decode()
        if not text: return e.code, {}
        try: return e.code, json.loads(text)
        except: return e.code, {"_raw": text}

# ──────────────────────────────────────────────────────────────────────────────
# Step 1: Verify Vercel team and current projects
# ──────────────────────────────────────────────────────────────────────────────
print("== Step 1: Vercel — list teams and projects ==")
code, body = api("GET", f"{API_V}/v2/teams", VERCEL_TOKEN)
teams = body.get("teams", []) if isinstance(body, dict) else []
print(f"  teams: {len(teams)}")
for t in teams:
    print(f"    id={t['id']} slug={t['slug']} name={t['name']}")

code, body = api("GET", f"{API_V}/v9/projects?teamId={VERCEL_TEAM}", VERCEL_TOKEN)
projects = body.get("projects", []) if isinstance(body, dict) else []
print(f"  existing projects: {len(projects)}")
for p in projects[:20]:
    print(f"    {p['name']}  latest={p.get('latestDeployments',[{}])[0].get('readyState','-')}")

# ──────────────────────────────────────────────────────────────────────────────
# Step 2: Create repos for example-docs and example-blog in your-site-artifacts-user GH
# ──────────────────────────────────────────────────────────────────────────────
print("\n== Step 2: Create GH repos (your-site-artifacts-user) for docs and blog starters ==")
DOCS_REPO = "example-docs"
BLOG_REPO = "example-blog"
for repo in [DOCS_REPO, BLOG_REPO]:
    code, body = api("GET", f"{API_GH}/repos/{GH2_USER}/{repo}", GH2_TOKEN)
    if code == 200:
        print(f"  ✓ {repo} already exists (skip)")
    elif code == 404:
        body = {
            "name": repo,
            "private": True,
            "description": f"example.com {repo.replace('example-','')} site (Vercel-hosted, SSR)",
            "auto_init": False,
            "has_issues": False,
            "has_wiki": False,
            "has_projects": False,
        }
        code2, body2 = api("POST", f"{API_GH}/user/repos", GH2_TOKEN, body)
        if code2 == 201:
            print(f"  ✓ created {repo} at {GH2_USER}/{repo}")
        else:
            print(f"  ✗ create {repo} failed: {code2} {body2}")
    else:
        print(f"  ✗ check {repo} failed: {code} {body}")

# ──────────────────────────────────────────────────────────────────────────────
# Step 3: Generate minimal Next.js starter content for each repo
# ──────────────────────────────────────────────────────────────────────────────
print("\n== Step 3: Generate minimal Next.js starter content ==")
def write_repo_contents(repo_name, title, domain_prefix):
    """Generate minimal Next.js 15 starter files; commit each via GH Contents API."""
    files = {
        "package.json": json.dumps({
            "name": repo_name,
            "version": "0.1.0",
            "private": True,
            "scripts": {
                "dev": "next dev",
                "build": "next build",
                "start": "next start"
            },
            "dependencies": {
                "next": "^15.0.0",
                "react": "^19.0.0",
                "react-dom": "^19.0.0"
            }
        }, indent=2),
        "next.config.mjs": """/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
};
export default nextConfig;
""",
        "tsconfig.json": json.dumps({
            "compilerOptions": {
                "target": "ES2022",
                "lib": ["dom", "dom.iterable", "esnext"],
                "allowJs": True, "skipLibCheck": True,
                "strict": True, "noEmit": True, "esModuleInterop": True,
                "module": "esnext", "moduleResolution": "bundler",
                "resolveJsonModule": True, "isolatedModules": True, "jsx": "preserve",
                "incremental": True, "plugins": [{"name": "next"}],
                "paths": {"@/*": ["./*"]}
            },
            "include": ["next-env.d.ts", "**/*.ts", "**/*.tsx", ".next/types/**/*.ts"],
            "exclude": ["node_modules"]
        }, indent=2),
        "app/layout.tsx": f"""import './globals.css'

export const metadata = {{
  title: '{title}',
  description: '{title} — powered by Next.js SSR on Vercel',
}}

export default function RootLayout({{ children }}: {{ children: React.ReactNode }}) {{
  return (
    <html lang="en">
      <body>{{children}}</body>
    </html>
  )
}}
""",
        "app/page.tsx": f"""export default function Home() {{
  return (
    <main style={{{{ fontFamily: 'system-ui, sans-serif', maxWidth: 720, margin: '4rem auto', padding: '0 1.5rem' }}}}>
      <h1>{title}</h1>
      <p>This is a placeholder {title.lower()} page rendered via Next.js App Router on Vercel.</p>
      <p>Domain: <code>{domain_prefix}.{DOMAIN}</code></p>
      <p>Hosting: Vercel (SSR enabled)</p>
      <p>DNS: Cloudflare CNAME → cname.vercel-dns.com (DNS-only / grey cloud)</p>
    </main>
  )
}}
""",
        "app/globals.css": """* { box-sizing: border-box; }
html, body { padding: 0; margin: 0; background: #fff; color: #1a1a1a; }
a { color: #0070f3; }""",
        ".gitignore": "node_modules/\n.next/\nout/\n.env*.local\n.DS_Store\n*.tsbuildinfo\nnext-env.d.ts\n",
        "README.md": f"""# {title}

Vercel-hosted SSR site for `{domain_prefix}.{DOMAIN}`.

## Architecture
- **Domain**: `{domain_prefix}.{DOMAIN}` (CNAME → `cname.vercel-dns.com`, DNS-only at Cloudflare)
- **Hosting**: Vercel (Hobby tier for now; upgrade to Pro for production)
- **DNS provider**: Cloudflare (separate CF account per the example architecture)
- **Framework**: Next.js 15 App Router + TypeScript

## Deploy
- Push to `main` branch → Vercel auto-deploys
- Verify domain in Vercel dashboard → Settings → Domains
""",
    }
    return files

# Helper: get current commit SHA of default branch (for tree updates)
def get_default_branch_sha(repo):
    code, body = api("GET", f"{API_GH}/repos/{GH2_USER}/{repo}", GH2_TOKEN)
    if code != 200: return None
    return body.get("default_branch", "main")

def create_or_update_file(repo, path, content, commit_msg="[bot] init"):
    """PUT /repos/{owner}/{repo}/contents/{path} with base64 content."""
    import base64
    b64 = base64.b64encode(content.encode()).decode()
    # Check if file exists to get its sha (for update)
    code, body = api("GET", f"{API_GH}/repos/{GH2_USER}/{repo}/contents/{path}", GH2_TOKEN)
    file_sha = body.get("sha") if code == 200 else None
    payload = {"message": commit_msg, "content": b64, "branch": "main"}
    if file_sha: payload["sha"] = file_sha
    code, body = api("PUT", f"{API_GH}/repos/{GH2_USER}/{repo}/contents/{path}", GH2_TOKEN, payload)
    return code, body

# Commit each file for both repos
for repo, title, prefix in [
    (DOCS_REPO, "example docs", "docs"),
    (BLOG_REPO, "example blog", "blog"),
]:
    print(f"\n  -> populating {repo}")
    files = write_repo_contents(repo, title, prefix)
    for path, content in files.items():
        code, body = create_or_update_file(repo, path, content, f"[infra-bot] init {repo}: {path}")
        if code in (200, 201):
            print(f"     ✓ {path}")
        else:
            msg = body.get("message", "")[:120] if isinstance(body, dict) else str(body)[:120]
            print(f"     ✗ {path}  code={code} err={msg}")
        time.sleep(0.3)  # GH secondary rate limit

# ──────────────────────────────────────────────────────────────────────────────
# Step 4: Create Vercel projects linked to those GH repos + attach domains
# ──────────────────────────────────────────────────────────────────────────────
print("\n== Step 4: Create Vercel projects + attach domains ==")
for repo, domain_prefix in [
    (DOCS_REPO, "docs"),
    (BLOG_REPO, "blog"),
]:
    project_name = repo  # Vercel project name = repo name
    domain = f"{domain_prefix}.{DOMAIN}"
    print(f"\n  -> {project_name} (target: {domain})")
    # Check if project exists
    code, body = api("GET", f"{API_V}/v9/projects/{project_name}?teamId={VERCEL_TEAM}", VERCEL_TOKEN)
    if code == 200:
        print(f"     ✓ project exists (skip create)")
        project_id = body["id"]
    else:
        # Use gitRepository field (verified via probe)
        payload = {
            "name": project_name,
            "gitRepository": {
                "type": "github",
                "repo": f"{GH2_USER}/{repo}",
            },
            "framework": "nextjs",
            "buildCommand": "npm run build",
            "outputDirectory": ".next",
            "installCommand": "npm install",
        }
        code2, body2 = api("POST", f"{API_V}/v11/projects?teamId={VERCEL_TEAM}", VERCEL_TOKEN, payload)
        if code2 == 200 or code2 == 201:
            project_id = body2["id"]
            print(f"     ✓ created project (id={project_id[:12]}…)")
        else:
            print(f"     ✗ create failed: {code2} {body2}")
            continue
    # Attach domain to project
    code, body = api("GET", f"{API_V}/v9/projects/{project_id}/domains?teamId={VERCEL_TEAM}", VERCEL_TOKEN)
    existing_domains = body.get("domains", []) if isinstance(body, dict) else []
    already = any(d.get("name") == domain for d in existing_domains)
    if already:
        print(f"     ✓ domain {domain} already attached")
    else:
        code, body = api("POST", f"{API_V}/v9/projects/{project_id}/domains?teamId={VERCEL_TEAM}", VERCEL_TOKEN, {
            "name": domain, "gitBranch": "main"
        })
        if code in (200, 201):
            print(f"     ✓ domain {domain} attached to project")
        else:
            msg = body.get("message", "")[:200] if isinstance(body, dict) else str(body)[:200]
            err = body.get("error", {})
            if isinstance(err, dict):
                msg = err.get("message", msg)
            print(f"     ✗ attach domain failed: {code} {msg}")
            # If domain already attached to another project, Vercel returns conflict

print("\n✓ Vercel setup done.")
print("  Next: User pushes commits → Vercel auto-deploys")
print("  DNS already points docs./blog. → cname.vercel-dns.com (grey cloud)")
print("  Vercel will issue SSL after first deploy + verify domain ownership")
