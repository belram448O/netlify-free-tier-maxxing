#!/usr/bin/env python3
"""15_clean_gh_repo.py — Remove deleted scripts from the GitHub repo.

When scripts are deleted locally, the GH Contents API doesn't auto-delete them
from the remote repo. This script:
  1. Lists all files currently in the GH repo
  2. For each, checks if the file still exists locally
  3. Deletes the orphan files from GH
  4. Also deletes tool-results/ files (those got accidentally uploaded)
"""
import json, os, pathlib, urllib.request, urllib.error
PROJECT_ROOT = pathlib.Path(__file__).resolve().parent.parent

SECRETS = json.loads((PROJECT_ROOT / 'infra' / 'secrets.json').read_text())
GH = SECRETS['gh_primary_token']
USER = SECRETS['gh_primary_user']
REPO = 'domain-infra-kit'
API = 'https://api.github.com'
LOCAL_ROOT = PROJECT_ROOT

def gh(method, path, body=None):
    url = f"{API}{path}"
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url, data=data, method=method)
    req.add_header("Authorization", f"token {GH}")
    req.add_header("Accept", "application/vnd.github+json")
    if body is not None: req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            text = r.read().decode()
            return r.status, (json.loads(text) if text else {})
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read().decode() or "{}")

# Step 1: List all files at root + subdirectories in the GH repo
print("== Listing files in GH repo ==")
all_files = []
for path in ['', 'scripts', 'infra', '.github', '.github/workflows']:
    code, body = gh("GET", f"/repos/{USER}/{REPO}/contents/{path}")
    if code == 200 and isinstance(body, list):
        for f in body:
            if f.get('type') == 'file':
                all_files.append(f)

print(f"  found {len(all_files)} files in GH repo")

# Step 2: For each, check if it exists locally; if not, delete from GH
deleted = 0
for f in all_files:
    gh_path = f['path']  # e.g. "scripts/foo.py"
    local_path = LOCAL_ROOT / gh_path
    if not local_path.exists():
        print(f"  DELETE: {gh_path} (no local file)")
        code, body = gh("DELETE", f"/repos/{USER}/{REPO}/contents/{gh_path}", {
            "message": f"[infra-bot] Wave 2 cleanup: delete {gh_path}",
            "sha": f['sha'],
            "branch": "main"
        })
        if code in (200, 204):
            deleted += 1
        else:
            print(f"    err: {code} {body.get('message', '')[:100]}")
    else:
        # Also check if it's a tool-results file (those should never be in repo)
        if 'tool-results' in gh_path:
            print(f"  DELETE: {gh_path} (tool-results should not be in repo)")
            code, body = gh("DELETE", f"/repos/{USER}/{REPO}/contents/{gh_path}", {
                "message": f"[infra-bot] remove tool-results/{gh_path} (gitignored)",
                "sha": f['sha'],
                "branch": "main"
            })
            if code in (200, 204):
                deleted += 1
            else:
                print(f"    err: {code} {body.get('message', '')[:100]}")

print(f"\n✓ Deleted {deleted} orphan files from GH repo")
