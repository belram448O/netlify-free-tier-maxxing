#!/usr/bin/env python3
"""20_final_verify.py — End-to-end verification after NS migration + Netlify subzone setup.

Tests:
  1. Public DNS resolution via multiple resolvers (1.1.1.1, 8.8.8.8, 9.9.9.9)
  2. CF zone status (pending→active)
  3. Worker Routes bound (cannot query without master token — skip if zone-scoped)
  4. Email Routing enable (retry — should work now that NS migrated)
  5. Vercel deployments READY
  6. Netlify sub-zone resolves via public DNS
  7. NS delegation end-to-end (root → NS1)
"""
import json, pathlib, subprocess, urllib.request, urllib.error, sys
PROJECT_ROOT = pathlib.Path(__file__).resolve().parent.parent

SECRETS = json.loads((PROJECT_ROOT / 'infra' / 'secrets.json').read_text())
STATE = json.loads((PROJECT_ROOT / 'infra' / 'state.json').read_text())
API = "https://api.cloudflare.com/client/v4"
MAIN_TOKEN = SECRETS.get('root_zone_token') or SECRETS.get('cf_main_zone_scoped_token')
DOMAIN = SECRETS['domain']

def cf(method, path):
    req = urllib.request.Request(f"{API}{path}", method=method)
    req.add_header("Authorization", f"Bearer {MAIN_TOKEN}")
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            return r.status, json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read().decode() or "{}")

def dig(rec_type, name, server="1.1.1.1"):
    try:
        out = subprocess.check_output(
            ["dig", "+short", rec_type, name, f"@{server}"],
            timeout=10, stderr=subprocess.DEVNULL
        ).decode().strip()
        return [l for l in out.split("\n") if l]
    except Exception:
        return []

def curl(url, expect_status=None):
    cmd = ["curl", "-sS", "-o", "/dev/null", "-w", "%{http_code}|%{remote_ip}|%{time_total}",
           "-m", "15", url, "-L"]
    try:
        out = subprocess.check_output(cmd, timeout=20, stderr=subprocess.DEVNULL).decode().strip()
        parts = out.split("|")
        code = int(parts[0]) if parts[0].isdigit() else 0
        ip = parts[1] if len(parts) > 1 else "?"
        t = parts[2] if len(parts) > 2 else "?"
        ok_ = (expect_status is None) or (code == expect_status)
        return ok_, code, ip, t
    except Exception:
        return False, 0, "?", "?"

results = []
def check(label, ok_, detail=""):
    icon = "✓" if ok_ else "✗"
    line = f"  {icon} {label}"
    if detail: line += f"  —  {detail}"
    print(line)
    results.append((label, ok_, detail))

print("=" * 78)
print("example.com — FINAL VERIFICATION (after NS migration + Netlify subzone)")
print("=" * 78)

# 1. CF zone status
print("\n[1] CF zone status")
code, body = cf("GET", f"/zones/{STATE['root_zone']['id']}")
z = body.get("result", {}) if isinstance(body, dict) else {}
check(f"zone exists (id={z.get('id','?')[:12]})", z.get("id") == STATE['root_zone']['id'])
# CF's observed_name_servers lags ~1 hour after NS migration; the real source of truth is public DNS.
# Treat empty observed_name_servers as "active" (CF clears it once zone is active)
observed = z.get("observed_name_servers") or []
status = z.get("status", "?")
if status == "active":
    check(f"zone status (active)", True, "fully provisioned")
elif observed:
    check(f"CF observed NS", any("cloudflare" in ns for ns in observed), f"observed={observed}")
else:
    check(f"zone status", False, f"status={status}, observed=[] (may lag)")

# 2. Public DNS resolution via multiple resolvers
print("\n[2] Public DNS resolution — multi-resolver")
for resolver in ["1.1.1.1", "8.8.8.8", "9.9.9.9"]:
    ns = dig("NS", DOMAIN, resolver)
    cf_seen = any("cloudflare" in n for n in ns)
    check(f"NS via {resolver}", cf_seen, ", ".join(ns))

# 3. Apex A + TXT (proves CF is authoritative now)
print("\n[3] Apex records (CF is now authoritative)")
a = dig("A", DOMAIN)
check(f"{DOMAIN} A", len(a) > 0, ", ".join(a))
txt = dig("TXT", DOMAIN)
spf = [t for t in txt if "spf" in t.lower()]
check(f"{DOMAIN} SPF (TXT)", len(spf) > 0, spf[0] if spf else "(none)")
dmarc = dig("TXT", f"_dmarc.{DOMAIN}")
check(f"_dmarc.{DOMAIN}", any("DMARC1" in d for d in dmarc), dmarc[0][:80] if dmarc else "")
mta = dig("TXT", f"_mta-sts.{DOMAIN}")
check(f"_mta-sts.{DOMAIN}", len(mta) > 0, mta[0] if mta else "")

# 4. NS delegation for users.example.com
print("\n[4] NS delegation: users.example.com → Netlify NS1")
users_ns = dig("NS", f"users.{DOMAIN}")
nl_seen = any("nsone" in n for n in users_ns)
check(f"users.{DOMAIN} NS", nl_seen, ", ".join(users_ns))

# 5. Records inside the Netlify sub-zone (via NS1 directly, since resolvers cache)
print("\n[5] Records in Netlify sub-zone (users.example.com)")
ns1 = "<ns1>"
for rtype, name, expected in [
    ("A", f"users.{DOMAIN}", "192.0.2.1"),
    ("TXT", f"users.{DOMAIN}", "v=spf1"),
    ("TXT", f"_dmarc.users.{DOMAIN}", "v=DMARC1"),  # FIXED: was _dmarc.{DOMAIN} (typo)
]:
    recs = dig(rtype, name, ns1)
    if rtype == "TXT":
        check(f"{rtype:5s} {name}", len([r for r in recs if expected in r]) > 0, ", ".join(recs)[:80])
    else:
        check(f"{rtype:5s} {name}", expected in recs, ", ".join(recs))

# 6. Worker health check (HTTP)
print("\n[6] Worker HTTP reachability")
ok_, code, ip, t = curl(f"https://{DOMAIN}/__health", expect_status=200)
check(f"https://{DOMAIN}/__health", ok_, f"code={code} ip={ip} t={t}s")
ok_, code, ip, t = curl(f"https://www.{DOMAIN}/__health", expect_status=200)
check(f"https://www.{DOMAIN}/__health", ok_, f"code={code} ip={ip} t={t}s")

# 7. Email Routing enable retry
print("\n[7] Email Routing retry (now that NS migrated)")
code, body = cf("POST", f"/zones/{STATE['root_zone']['id']}/email/routing/enable")
succ = body.get("success") if isinstance(body, dict) else False
if succ:
    check("Email Routing enabled", True)
else:
    errs = body.get("errors") if isinstance(body, dict) else None
    msg = errs[0].get("message", "")[:100] if errs and isinstance(errs, list) and errs else ""
    if "already" in msg.lower():
        check("Email Routing enabled", True, "already enabled")
    else:
        check("Email Routing enabled", False, f"code={code} err={msg}")

# 8. Vercel deployments (use projectId instead of app filter — that's the working API)
print("\n[8] Vercel deployments")
V = SECRETS['vercel_token']
T = SECRETS['vercel_team_id']
# First list projects to get IDs
try:
    req = urllib.request.Request(
        f"https://api.vercel.com/v9/projects?teamId={T}&limit=20",
        headers={"Authorization": f"Bearer {V}"})
    body = json.loads(urllib.request.urlopen(req).read())
    projects = body.get("projects", [])
    for proj in projects:
        if proj.get("name", "").startswith("example-"):
            pid = proj["id"]
            pname = proj["name"]
            # Now list deployments for this project
            req = urllib.request.Request(
                f"https://api.vercel.com/v6/deployments?teamId={T}&projectId={pid}&limit=3",
                headers={"Authorization": f"Bearer {V}"})
            body = json.loads(urllib.request.urlopen(req).read())
            deps = body.get("deployments", [])
            ready = [d for d in deps if d.get("readyState") == "READY"]
            check(f"{pname} has READY deployment", len(ready) > 0, f"({len(ready)}/{len(deps)} READY)")
except Exception as e:
    check("Vercel projects", False, str(e)[:80])

# 9. Verify docs./blog. resolve (will resolve via CF once apex zone active)
print("\n[9] docs./blog. CNAME resolution")
docs_cname = dig("CNAME", f"docs.{DOMAIN}")
check(f"docs.{DOMAIN} CNAME", any("vercel-dns" in c for c in docs_cname), ", ".join(docs_cname))
blog_cname = dig("CNAME", f"blog.{DOMAIN}")
check(f"blog.{DOMAIN} CNAME", any("vercel-dns" in c for c in blog_cname), ", ".join(blog_cname))

# Summary
print("\n" + "=" * 78)
total = len(results)
passed = sum(1 for _, ok_, _ in results if ok_)
print(f"SUMMARY: {passed}/{total} checks passed")
print("=" * 78)
if passed < total:
    print("\nFailures:")
    for label, ok_, detail in results:
        if not ok_:
            print(f"  ✗ {label}  —  {detail}")
    sys.exit(1)
print("\nAll checks passed! 🎉")
