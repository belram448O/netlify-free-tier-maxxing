#!/usr/bin/env python3
"""Rebuild state.json — fetch the CF root zone info directly from CF API."""
import json, pathlib, urllib.request, urllib.error
PROJECT_ROOT = pathlib.Path(__file__).resolve().parent.parent

SECRETS = json.loads((PROJECT_ROOT / 'infra' / 'secrets.json').read_text())
API = "https://api.cloudflare.com/client/v4"
TOKEN = SECRETS.get("root_zone_token") or SECRETS.get("cf_main_zone_scoped_token")
MAIN_ACCT = SECRETS["cf_main_account_id"]

def cf(method, path):
    req = urllib.request.Request(f"{API}{path}", method=method)
    req.add_header("Authorization", f"Bearer {TOKEN}")
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            return r.status, json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read().decode() or "{}")

# Fetch the root zone
code, body = cf("GET", f"/zones?name=example.com")
if code != 200 or not body.get("result"):
    print(f"FATAL: zone not found. code={code} body={body}")
    exit(1)

z = body["result"][0]
print(f"Found root zone: {z['name']} id={z['id']} status={z['status']}")
print(f"  assigned NS: {z.get('name_servers')}")

state = {
    "root_zone": {
        "name": z["name"],
        "id": z["id"],
        "account_id": MAIN_ACCT,
        "status": z["status"],
        "name_servers": z.get("name_servers", []),
    }
}

# Fetch root zone DNS records count (for drift detection baseline)
code, body = cf("GET", f"/zones/{z['id']}/dns_records?per_page=200")
if code == 200 and isinstance(body, dict):
    recs = body.get("result", [])
    state["root_zone_records_count"] = len(recs)
    print(f"  DNS records: {len(recs)}")

# Also try to fetch the worker name
code, body = cf("GET", f"/accounts/{MAIN_ACCT}/workers/scripts")
if code == 200 and isinstance(body, dict):
    scripts = body.get("result", [])
    if scripts:
        state["root_worker"] = {"name": scripts[0].get("id"), "account_id": MAIN_ACCT}
        print(f"  worker found: {scripts[0].get('id')}")

# Also fetch the worker routes bound to root zone
code, body = cf("GET", f"/zones/{z['id']}/workers/routes")
if code == 200 and isinstance(body, dict):
    routes = body.get("result", [])
    if routes:
        state["root_worker"]["routes"] = routes
        print(f"  routes bound: {[r.get('pattern') for r in routes]}")

# Email Routing status
code, body = cf("GET", f"/zones/{z['id']}/email/routing")
if code == 200 and isinstance(body, dict) and body.get("result"):
    er = body["result"]
    state["root_email_routing"] = {
        "zone_id": z["id"],
        "enabled": er.get("status") == "ready",
        "last_error": None if er.get("status") == "ready" else er.get("status"),
    }
    print(f"  email routing: {er.get('status')}")

# Fetch Netlify sub-zones (extension to original 00b_rebuild_state.py)
print("\n== Fetching Netlify sub-zones ==")
NL_TOKEN = SECRETS.get('netlify_token')
if NL_TOKEN:
    try:
        req = urllib.request.Request(
            "https://api.netlify.com/api/v1/dns_zones",
            headers={"Authorization": f"Bearer {NL_TOKEN}"})
        with urllib.request.urlopen(req, timeout=15) as r:
            zones = json.loads(r.read().decode())
        subzones = {}
        for z in zones:
            name = z.get("name", "")
            if name.endswith(f".{SECRETS['domain']}") and name != SECRETS['domain']:
                prefix = name.split(".")[0]
                subzones[prefix] = {
                    "name": name,
                    "id": z["id"],
                    "account_id": z.get("account_id"),
                    "dns_servers": z.get("dns_servers", []),
                    "hosting": "placeholder",
                    "email_routing_required": prefix in ("users", "corp"),
                }
                print(f"  found sub-zone: {name} (id={z['id'][:12]}…)")
        state["subzones"] = subzones
    except Exception as e:
        print(f"  ⚠ Netlify fetch failed: {e}")

# Set restrictive permissions
state_path = PROJECT_ROOT / 'infra' / 'state.json'
state_path.write_text(json.dumps(state, indent=2, sort_keys=True))
state_path.chmod(0o600)
print(f"\n✓ state.json rebuilt at {state_path} (mode 0600)")
print(f"  keys: {list(state.keys())}")
