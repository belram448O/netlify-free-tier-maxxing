#!/usr/bin/env python3
"""Probe CF token capabilities — figure out what permissions cfat_ tokens actually have."""
import json, pathlib, urllib.request, urllib.error
PROJECT_ROOT = pathlib.Path(__file__).resolve().parent.parent
SECRETS = json.loads((PROJECT_ROOT / 'infra' / 'secrets.json').read_text())
API = "https://api.cloudflare.com/client/v4"

def cf(method, path, token, body=None, expect_json=True):
    url = f"{API}{path}"
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url, data=data, method=method)
    req.add_header("Authorization", f"Bearer {token}")
    if body is not None:
        req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            body_text = r.read().decode()
            if not expect_json: return r.status, body_text
            return r.status, json.loads(body_text) if body_text else {}
    except urllib.error.HTTPError as e:
        body_text = e.read().decode()
        try: return e.code, json.loads(body_text)
        except: return e.code, body_text

def probe(token_name, token, acct):
    print(f"\n========== TOKEN: {token_name} (acct {acct[:8]}…) ==========")
    probes = [
        # (label, method, path, body)
        ("list_account_tokens",   "GET",  f"/accounts/{acct}/tokens", None),
        ("list_account_members",  "GET",  f"/accounts/{acct}/members", None),
        ("list_account_roles",    "GET",  f"/accounts/{acct}/roles", None),
        ("list_zones",            "GET",  "/zones", None),
        ("list_workers_scripts",  "GET",  f"/accounts/{acct}/workers/scripts", None),
        ("list_kv_namespaces",    "GET",  f"/accounts/{acct}/storage/kv/namespaces", None),
        ("list_r2_buckets",        "GET",  f"/accounts/{acct}/r2/buckets", None),
        ("email_routing_list",     "GET",  f"/zones", None),  # list zones (zone-id not available pre-bootstrap)
        ("account_settings",      "GET",  f"/accounts/{acct}", None),
        ("billing_history",       "GET",  f"/accounts/{acct}/billing/history", None),
        ("create_token_policy",   "GET",  f"/accounts/{acct}/tokens/permission_groups", None),
    ]
    for label, m, p, b in probes:
        code, body = cf(m, p, token, b)
        if code == 200:
            succ = body.get("success") if isinstance(body, dict) else None
            n = len(body.get("result", [])) if isinstance(body, dict) and isinstance(body.get("result"), list) else "-"
            print(f"  ✓ {label:30s}  {code}  success={succ}  count={n}")
        else:
            msg = ""
            if isinstance(body, dict):
                errs = body.get("errors") or []
                if errs and isinstance(errs, list):
                    msg = errs[0].get("message", "")[:80]
            print(f"  ✗ {label:30s}  {code}  {msg}")

probe("CF_MAIN", SECRETS["cf_main_token"], SECRETS["cf_main_account_id"])
probe("CF_SUB",  SECRETS["cf_sub_token"],  SECRETS["cf_sub_account_id"])
