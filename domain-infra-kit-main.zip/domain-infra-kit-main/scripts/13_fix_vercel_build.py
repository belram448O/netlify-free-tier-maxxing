#!/usr/bin/env python3
"""13_fix_vercel_build.py — Push missing devDependencies + ESLint config to make Next.js build pass."""
import json, base64, time, pathlib, urllib.request, urllib.error

SECRETS = json.loads(open(pathlib.Path(__file__).resolve().parent.parent / "infra" / "secrets.json").read())
GH2_TOKEN = SECRETS["gh_secondary_token"]
GH2_USER  = SECRETS["gh_secondary_user"]

API_GH = "https://api.github.com"

def gh(method, path, body=None):
    url = f"{API_GH}{path}"
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url, data=data, method=method)
    req.add_header("Authorization", f"token {GH2_TOKEN}")
    req.add_header("Accept", "application/vnd.github+json")
    if body is not None: req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            text = r.read().decode()
            return r.status, (json.loads(text) if text else {})
    except urllib.error.HTTPError as e:
        text = e.read().decode()
        try: return e.code, json.loads(text)
        except: return e.code, {"_raw": text}

def upsert_file(repo, path, content, commit_msg):
    code, body = gh("GET", f"/repos/{GH2_USER}/{repo}/contents/{path}")
    file_sha = body.get("sha") if code == 200 else None
    b64 = base64.b64encode(content.encode()).decode()
    payload = {"message": commit_msg, "content": b64, "branch": "main"}
    if file_sha: payload["sha"] = file_sha
    code, body = gh("PUT", f"/repos/{GH2_USER}/{repo}/contents/{path}", payload)
    return code, body

# Common files for both repos
def get_fixed_files(repo, title, prefix):
    pkg = {
        "name": repo, "version": "0.1.0", "private": True,
        "scripts": {"dev": "next dev", "build": "next build", "start": "next start", "lint": "next lint"},
        "dependencies": {
            "next": "^15.0.0",
            "react": "^19.0.0",
            "react-dom": "^19.0.0",
        },
        "devDependencies": {
            "typescript": "^5.6.0",
            "@types/node": "^22.0.0",
            "@types/react": "^19.0.0",
            "@types/react-dom": "^19.0.0",
            "eslint": "^9.0.0",
            "eslint-config-next": "^15.0.0",
        },
    }
    return {
        "package.json": json.dumps(pkg, indent=2),
        "next.config.mjs": """/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  // NOTE: eslint.ignoreDuringBuilds was previously true for the starter.
  // Now that .eslintrc.json + eslint-config-next are installed, lint runs
  // during builds. If you want lint to NOT block builds, flip this to true.
  // For production, leave it false so quality issues surface during deploy.
  eslint: { ignoreDuringBuilds: false },
  typescript: { ignoreBuildErrors: false },
};
export default nextConfig;
""",
        ".eslintrc.json": json.dumps({
            "extends": "next/core-web-vitals",
        }, indent=2),
        "next-env.d.ts": "/// <reference types=\"next\" />\n/// <reference types=\"next/image-types/global\" />\n\n// NOTE: This file should not be edited\n// see https://nextjs.org/docs/app/api-reference/config/typescript for more information.\n",
    }

for repo, title, prefix in [
    ("example-docs", "example docs", "docs"),
    ("example-blog", "example blog", "blog"),
]:
    print(f"\n== {repo} ==")
    files = get_fixed_files(repo, title, prefix)
    for path, content in files.items():
        code, body = upsert_file(repo, path, content, f"[infra-bot] fix build: add {path}")
        if code in (200, 201):
            print(f"  ✓ {path}")
        else:
            msg = body.get("message", "")[:120] if isinstance(body, dict) else ""
            print(f"  ✗ {path}  code={code}  err={msg}")
        time.sleep(0.4)

print("\n✓ Done. Next push to main will trigger a new Vercel deploy.")
print("  Trigger manually via script 11_trigger_vercel_deploys.py")
