#!/usr/bin/env python3
"""01_create_zones.py — Create CF zones for example.com (MAIN) and users.example.com (SUB).

Idempotent: if a zone already exists, reuses it. Saves zone IDs + NS to
infra/state.json for downstream scripts.
"""
import json
import os
import pathlib
import sys
import time
import urllib.request
import urllib.error
PROJECT_ROOT = pathlib.Path(__file__).resolve().parent.parent

STATE_PATH = PROJECT_ROOT / 'infra' / 'state.json'
SECRETS_PATH = PROJECT_ROOT / 'infra' / 'secrets.json'

SECRETS = json.loads(SECRETS_PATH.read_text())
# Use the scoped minted tokens (NOT the master cfat_ tokens which can only mint other tokens)
CF_MAIN_TOKEN = SECRETS["root_zone_token"]
CF_SUB_TOKEN = SECRETS["sub_zone_token"]
CF_MAIN_ACCT = SECRETS["cf_main_account_id"]
CF_SUB_ACCT = SECRETS["cf_sub_account_id"]

API = "https://api.cloudflare.com/client/v4"


def cf(method, path, token, body=None):
    url = f"{API}{path}"
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url, data=data, method=method)
    req.add_header("Authorization", f"Bearer {token}")
    req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            return r.status, json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read().decode() or "{}")


def load_state():
    if STATE_PATH.exists():
        return json.loads(STATE_PATH.read_text())
    return {}


def save_state(state):
    STATE_PATH.parent.mkdir(parents=True, exist_ok=True)
    STATE_PATH.write_text(json.dumps(state, indent=2, sort_keys=True))


def find_zone(name, token):
    """Return existing zone dict for `name` or None."""
    code, body = cf("GET", f"/zones?name={name}", token)
    if code != 200 or not body.get("success"):
        return None
    results = body.get("result", []) or []
    return results[0] if results else None


def create_zone(name, account_id, token):
    """Create a zone; returns existing zone if already present."""
    existing = find_zone(name, token)
    if existing:
        print(f"  [skip] zone {name} already exists (id={existing['id']}, status={existing['status']})")
        return existing
    print(f"  [create] zone {name} in account {account_id}")
    code, body = cf("POST", "/zones", token, {
        "name": name,
        "account": {"id": account_id},
        "type": "full",
    })
    if code != 200 or not body.get("success"):
        print(f"    ERROR: {code} {body}")
        sys.exit(1)
    z = body["result"]
    print(f"    created: id={z['id']} status={z['status']}")
    print(f"    assigned NS: {z.get('name_servers')}")
    return z


def main():
    state = load_state()

    print("== Step 1: Create zone example.com at CF MAIN ==")
    root_zone = create_zone("example.com", CF_MAIN_ACCT, CF_MAIN_TOKEN)
    state["root_zone"] = {
        "name": root_zone["name"],
        "id": root_zone["id"],
        "account_id": CF_MAIN_ACCT,
        "status": root_zone["status"],
        "name_servers": root_zone.get("name_servers", []),
        "original_name_servers": root_zone.get("original_name_servers", []),
    }

    print("\n== Step 2: Create zone users.example.com at CF SUB ==")
    sub_zone = create_zone("users.example.com", CF_SUB_ACCT, CF_SUB_TOKEN)
    state["sub_zone"] = {
        "name": sub_zone["name"],
        "id": sub_zone["id"],
        "account_id": CF_SUB_ACCT,
        "status": sub_zone["status"],
        "name_servers": sub_zone.get("name_servers", []),
        "original_name_servers": sub_zone.get("original_name_servers", []),
    }

    save_state(state)
    print(f"\nState saved to {STATE_PATH}")
    print(json.dumps(state, indent=2))


if __name__ == "__main__":
    main()
