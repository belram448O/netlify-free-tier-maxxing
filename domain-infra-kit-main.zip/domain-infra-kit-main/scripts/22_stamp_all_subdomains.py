#!/usr/bin/env python3
"""22_stamp_all_subdomains.py — Stamp out all remaining subdomain Netlify DNS zones.

Creates Netlify DNS zones for: app, content, corp, api, cdn (help is already done as CNAME placeholder).
For each: adds A, SPF, DMARC, MTA-STS, CAA records; adds NS delegation in CF MAIN root zone.

This is the single idempotent "stamp out everything" script.

After this script runs, the only remaining manual steps are:
  1. ImprovMX signup + API key (for users.* and corp.* email) — see SECURITY.md
  2. CF Email Routing destination verification (click link in inbox of admin@example.com)
  3. Vercel SSL cert auto-issuance for docs.*/blog.* (5-15 min — no action needed)
  4. (Optional) Replace help.example.com CNAME placeholder with real vendor hostname
"""
import json, pathlib, urllib.request, urllib.error, sys, time
PROJECT_ROOT = pathlib.Path(__file__).resolve().parent.parent

SECRETS = json.loads((PROJECT_ROOT / 'infra' / 'secrets.json').read_text())
STATE = json.loads((PROJECT_ROOT / 'infra' / 'state.json').read_text())
API_NL = "https://api.netlify.com/api/v1"
API_CF = "https://api.cloudflare.com/client/v4"
NETLIFY_TOKEN = SECRETS['netlify_token']
NETLIFY_ACCT  = SECRETS['netlify_account_id']
CF_TOKEN = SECRETS.get('admin_token') or SECRETS.get('root_zone_token') or SECRETS.get('cf_main_zone_scoped_token')
ROOT_ZONE_ID = STATE['root_zone']['id']
DOMAIN = SECRETS['domain']

# All subdomains we want
ALL_SUBDOMAINS = [
    # (prefix, hosting_type, has_email_routing)
    ("users",    "placeholder",  True),   # already created — idempotent
    ("app",      "placeholder",  False),
    ("content",  "placeholder",  False),
    ("corp",     "placeholder",  True),   # needs email routing
    ("api",      "placeholder",  False),
    ("cdn",      "placeholder",  False),
    # docs and blog are at CF MAIN (CNAME → Vercel) — skip here
    # help is a CNAME placeholder at CF MAIN — skip here
]

def nl(method, path, body=None):
    url = f"{API_NL}{path}"
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url, data=data, method=method)
    req.add_header("Authorization", f"Bearer {NETLIFY_TOKEN}")
    if body is not None: req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            text = r.read().decode()
            if not text: return r.status, {}
            try: return r.status, json.loads(text)
            except: return r.status, {"_raw": text}
    except urllib.error.HTTPError as e:
        text = e.read().decode()
        try: return e.code, json.loads(text)
        except: return e.code, {"_raw": text}

def cf(method, path, body=None):
    url = f"{API_CF}{path}"
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url, data=data, method=method)
    req.add_header("Authorization", f"Bearer {CF_TOKEN}")
    if body is not None: req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            text = r.read().decode()
            if not text: return r.status, {}
            try: return r.status, json.loads(text)
            except: return r.status, {"_raw": text}
    except urllib.error.HTTPError as e:
        text = e.read().decode()
        try: return e.code, json.loads(text)
        except: return e.code, {"_raw": text}

def list_records(zone_id):
    code, body = nl("GET", f"/dns_zones/{zone_id}/dns_records")
    return body if isinstance(body, list) else []

def add_record(zone_id, rtype, hostname, value, ttl=3600, priority=None, flag=None, tag=None):
    recs = list_records(zone_id)
    existing = [r for r in recs if r.get("type") == rtype and r.get("hostname") == hostname and r.get("value") == value]
    if existing:
        print(f"    skip: {rtype:6s} {hostname:35s} → {value} (exists)")
        return
    body = {"type": rtype, "hostname": hostname, "value": value, "ttl": ttl}
    if priority is not None: body["priority"] = priority
    if flag is not None: body["flag"] = flag
    if tag is not None: body["tag"] = tag
    code, resp = nl("POST", f"/dns_zones/{zone_id}/dns_records", body)
    if 200 <= code < 300:
        print(f"    ✓ {rtype:6s} {hostname:35s} → {value}")
    else:
        errs = resp.get("errors") if isinstance(resp, dict) else None
        msg = json.dumps(errs)[:100] if errs else str(resp)[:100]
        print(f"    ✗ {rtype:6s} {hostname:35s} → {value}  code={code}  err={msg}")

def get_root_recs():
    code, body = cf("GET", f"/zones/{ROOT_ZONE_ID}/dns_records?per_page=200")
    return body.get("result", []) if isinstance(body, dict) else []

def add_root_ns(name, content):
    recs = get_root_recs()
    already = [r for r in recs if r["type"] == "NS" and r["name"] == name and r["content"] == content]
    if already:
        print(f"    skip: NS {name} → {content} (exists)")
        return
    code, resp = cf("POST", f"/zones/{ROOT_ZONE_ID}/dns_records", {
        "type": "NS", "name": name, "content": content, "ttl": 1, "proxied": False
    })
    if isinstance(resp, dict) and resp.get("success"):
        print(f"    ✓ NS {name} → {content}")
    else:
        print(f"    ✗ NS {name} → {content}  err={resp}")

def add_root_txt(name, content):
    recs = get_root_recs()
    already = [r for r in recs if r["type"] == "TXT" and r["name"] == name and r.get("content") == content]
    if already:
        print(f"    skip: TXT {name} → {content[:60]}… (exists)")
        return
    code, resp = cf("POST", f"/zones/{ROOT_ZONE_ID}/dns_records", {
        "type": "TXT", "name": name, "content": content, "ttl": 1, "proxied": False
    })
    if isinstance(resp, dict) and resp.get("success"):
        print(f"    ✓ TXT {name} → {content[:60]}…")

# ════════════════════════════════════════════════════════════════════════════
# Main loop: stamp out each subdomain
# ════════════════════════════════════════════════════════════════════════════
print("=" * 78)
print("STAMP OUT ALL SUBDOMAIN NETLIFY DNS ZONES")
print("=" * 78)

new_state_subzones = {}
for prefix, hosting, has_email in ALL_SUBDOMAINS:
    sub = f"{prefix}.{DOMAIN}"
    print(f"\n── {sub} (hosting={hosting}, email={has_email}) ──")

    # Step 1: Find or create Netlify zone
    code, body = nl("GET", "/dns_zones")
    zones = body if isinstance(body, list) else []
    existing = [z for z in zones if z.get("name") == sub]
    if existing:
        zone = existing[0]
        print(f"  ✓ zone exists: id={zone['id']}")
    else:
        print(f"  creating new zone…")
        code, body = nl("POST", "/dns_zones", {"name": sub, "account_id": NETLIFY_ACCT})
        if code == 201:
            zone = body
            print(f"  ✓ created: id={zone['id']}")
        else:
            print(f"  ✗ create failed: {code} {body}")
            continue

    ZONE_ID = zone["id"]
    NL_NS = zone.get("dns_servers", [])
    print(f"  NS: {NL_NS}")

    # Step 2: Add DNS records in sub-zone
    print(f"  -- DNS records in {sub} zone --")
    add_record(ZONE_ID, "A", sub, "192.0.2.1")
    add_record(ZONE_ID, "CNAME", f"www.{sub}", sub)
    add_record(ZONE_ID, "TXT", sub, "v=spf1 include:_spf.mx.cloudflare.net ~all")
    add_record(ZONE_ID, "TXT", f"_dmarc.{sub}", "v=DMARC1; p=quarantine; rua=mailto:admin@example.com; ruf=mailto:admin@example.com; pct=100; adkim=s; aspf=s")
    add_record(ZONE_ID, "TXT", f"_mta-sts.{sub}", "v=STSv1; id=20260815T000000")
    add_record(ZONE_ID, "CAA", sub, "letsencrypt.org", flag=0, tag="issue")
    add_record(ZONE_ID, "CAA", sub, "cloudflare.com", flag=0, tag="issue")

    # Step 3: Add NS delegation in CF root zone
    print(f"  -- NS delegation in CF root zone --")
    # Remove any stale NS records for this subdomain that don't match NL_NS
    root_recs = get_root_recs()
    existing_ns = [r for r in root_recs if r["type"] == "NS" and r["name"] == f"{prefix}.{DOMAIN}"]
    for r in existing_ns:
        if r["content"] not in NL_NS:
            cf("DELETE", f"/zones/{ROOT_ZONE_ID}/dns_records/{r['id']}")
            print(f"    deleted stale NS: {r['content']}")
    # Add the correct NS records
    for ns in NL_NS:
        add_root_ns(f"{prefix}.{DOMAIN}", ns)

    # Step 4: Add DMARC record in CF root zone for this subdomain (so even if a mail provider
    # checks the parent zone, DMARC is found)
    # (already added for users.example.com earlier; skip duplicates for others)
    if prefix not in ("users",):
        add_root_txt(f"_dmarc.{prefix}.{DOMAIN}", "v=DMARC1; p=quarantine; rua=mailto:admin@example.com; ruf=mailto:admin@example.com; pct=100; adkim=s; aspf=s")

    new_state_subzones[prefix] = {
        "name": sub,
        "id": ZONE_ID,
        "account_id": NETLIFY_ACCT,
        "dns_servers": NL_NS,
        "hosting": hosting,
        "email_routing_required": has_email,
    }
    print(f"  ✓ {sub} done.")
    time.sleep(0.5)

# Save state
STATE["subzones"] = new_state_subzones
(PROJECT_ROOT / 'infra' / 'state.json').write_text(json.dumps(STATE, indent=2, sort_keys=True))
print(f"\n✓ State saved: {len(new_state_subzones)} sub-zones tracked in state.json")

# Summary
print("\n" + "=" * 78)
print("STAMP-OUT COMPLETE")
print("=" * 78)
for prefix, info in new_state_subzones.items():
    print(f"  {prefix:8s} → {info['name']:30s} (NS: {info['dns_servers'][0]})")

print(f"""
Next steps (AUTOMATED-AS-MUCH-AS-POSSIBLE):
- Verify NS delegation propagates: python3 scripts/20_final_verify.py
- Wait ~5-15 min for DNS propagation
- For users.* and corp.* email routing: sign up at https://improvmx.com (free), 
  generate API key, then run scripts/24_setup_improvmx.py (after you provide the key)

Truly manual (cannot automate):
- ImprovMX signup (no API to create account; web-only)
- CF Email Routing destination verification (click link in admin@example.com inbox)
- Help-desk vendor hostname (replace help.example.com CNAME placeholder)
""")
