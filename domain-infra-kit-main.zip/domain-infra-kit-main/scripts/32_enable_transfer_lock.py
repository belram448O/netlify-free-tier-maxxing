#!/usr/bin/env python3
"""32_enable_transfer_lock.py — Enable Spaceship transfer lock on example.com.

Prevents unauthorized domain transfers if Spaceship account is compromised.
"""
import json, pathlib, urllib.request, urllib.error
PROJECT_ROOT = pathlib.Path(__file__).resolve().parent.parent

SECRETS = json.loads((PROJECT_ROOT / 'infra' / 'secrets.json').read_text())
SP_KEY = SECRETS['spaceship_key']
SP_SECRET = SECRETS['spaceship_secret']
DOMAIN = SECRETS['domain']

API = "https://spaceship.dev/api"
HEADERS = {
    "X-Api-Key": SP_KEY,
    "X-Api-Secret": SP_SECRET,
    "Accept": "application/json",
    "Content-Type": "application/json",
}

def sp(method, path, body=None):
    url = f"{API}{path}"
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url, data=data, method=method)
    for k, v in HEADERS.items():
        req.add_header(k, v)
    try:
        with urllib.request.urlopen(req, timeout=20) as r:
            text = r.read().decode()
            if not text: return r.status, {}
            try: return r.status, json.loads(text)
            except: return r.status, {"_raw": text}
    except urllib.error.HTTPError as e:
        text = e.read().decode()
        try: return e.code, json.loads(text)
        except: return e.code, {"_raw": text}

# Check current state
print(f"== Current transfer lock state for {DOMAIN} ==")
code, body = sp("GET", f"/v1/domains/{DOMAIN}")
if code != 200:
    print(f"  ✗ err: {code} {body}")
    exit(1)
epp = body.get('eppStatuses', [])
print(f"  EPP statuses: {epp}")
has_lock = 'clientTransferProhibited' in epp
print(f"  transfer lock: {'✓ already enabled' if has_lock else '✗ NOT enabled'}")

if has_lock:
    print("\n  ✓ No action needed.")
    exit(0)

# Try enabling — check if Spaceship has a transfer-lock endpoint
# Per the OpenAPI spec, the endpoint is: PUT /v1/domains/{domain}/transfer/lock
print(f"\n== Enabling transfer lock via PUT /v1/domains/{DOMAIN}/transfer/lock ==")
code, body = sp("PUT", f"/v1/domains/{DOMAIN}/transfer/lock", {"lock": True})
print(f"  code={code}")
print(f"  body={json.dumps(body, indent=2)[:500]}")

# Verify
code, body = sp("GET", f"/v1/domains/{DOMAIN}")
epp = body.get('eppStatuses', [])
print(f"\n  EPP statuses after: {epp}")
if 'clientTransferProhibited' in epp:
    print("  ✓ Transfer lock enabled!")
else:
    print("  ⚠ Lock not enabled — manual action required:")
    print(f"    Visit https://www.spaceship.com/control-panel/domains/{DOMAIN}/transfer-lock")
