#!/usr/bin/env python3
"""gitlab_backup.py — Mirror GitHub repos to GitLab with automatic retry.

GitLab has stricter rate limits than GitHub AND may geo-block certain IPs.
If git push fails, this script falls back to GitLab's Repository Files API
(POST /api/v4/projects/:id/repository/files/:filepath) to push files one by one.

Usage:
  python3 scripts/gitlab_backup.py                    # backup both repos
  python3 scripts/gitlab_backup.py domain-infra-kit      # backup one repo
  python3 scripts/gitlab_backup.py --retries 5          # custom retry count
  python3 scripts/gitlab_backup.py --daemon              # run continuously (every 5 min)
  python3 scripts/gitlab_backup.py --api-only            # skip git push, use API only

Requires:
  - infra/secrets.json with 'gitlab_pat' and 'gh_primary_token' keys
"""
import json, pathlib, subprocess, sys, time, argparse, urllib.request, urllib.error, base64, os

SECRETS = json.loads((pathlib.Path(__file__).resolve().parent.parent / 'infra' / 'secrets.json').read_text())
GL_PAT = SECRETS.get('gitlab_pat', '')
GH_TOKEN = SECRETS.get('gh_primary_token', '')
GH_USER = SECRETS.get('gh_primary_user', '')

if not GL_PAT:
    print("✗ Missing 'gitlab_pat' in infra/secrets.json")
    sys.exit(1)

REPOS = {
    'domain-infra-kit': {
        'gh_url': f'https://{GH_TOKEN}@github.com/{GH_USER}/domain-infra-kit.git',
        'gh_api': f'https://api.github.com/repos/{GH_USER}/domain-infra-kit',
        'gl_name': 'domain-infra-kit',
        'gl_description': 'example.com — multi-account Cloudflare + Netlify + Vercel infra (mirror)',
    },
    'domain-infra-kit': {
        'gh_url': f'https://{GH_TOKEN}@github.com/{GH_USER}/domain-infra-kit.git',
        'gh_api': f'https://api.github.com/repos/{GH_USER}/domain-infra-kit',
        'gl_name': 'domain-infra-kit',
        'gl_description': 'Generalized multi-account custom domain infrastructure kit (mirror)',
    },
}

GL_API = 'https://gitlab.com/api/v4'

def gl_api(method, path, body=None, raw_body=None):
    url = f"{GL_API}{path}"
    if raw_body is not None:
        data = raw_body
    else:
        data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url, data=data, method=method)
    req.add_header("PRIVATE-TOKEN", GL_PAT)
    if body is not None or raw_body is not None:
        req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            text = r.read().decode()
            return r.status, (json.loads(text) if text else {})
    except urllib.error.HTTPError as e:
        text = e.read().decode()
        # Check if it's a Cloudflare block page
        if 'blocked IP' in text or 'cf-error' in text.lower():
            return 403, {"_blocked": True, "_raw": text[:200]}
        try:
            return e.code, json.loads(text)
        except:
            return e.code, {"_raw": text[:200]}

def get_gl_user():
    code, body = gl_api("GET", "/user")
    if code == 200:
        return body.get("id"), body.get("username")
    if isinstance(body, dict) and body.get("_blocked"):
        print("  ✗ GitLab API is IP-blocked (Cloudflare)")
    return None, None

def create_gl_repo(name, description):
    code, body = gl_api("GET", f"/projects?search={name}&owned=true")
    if isinstance(body, list):
        for p in body:
            if p.get("name") == name:
                return p["id"], p["http_url_to_repo"]
    if isinstance(body, dict) and body.get("_blocked"):
        return None, None
    code, body = gl_api("POST", "/projects", {
        "name": name,
        "description": description,
        "visibility": "private",
        "initialize_with_readme": False,
    })
    if code in (201, 200):
        return body["id"], body["http_url_to_repo"]
    elif isinstance(body, dict) and body.get("_blocked"):
        print(f"  ✗ GitLab API blocked")
        return None, None
    else:
        print(f"  ✗ Create failed: {code} {str(body)[:200]}")
        return None, None

def mirror_via_git_push(repo_name, repo_info, retries=3, delay=30):
    """Try git clone --mirror + git push --mirror."""
    gl_id, gl_url = create_gl_repo(repo_info['gl_name'], repo_info['gl_description'])
    if not gl_id:
        return False

    gl_url_auth = gl_url.replace("https://", f"https://oauth2:{GL_PAT}@")
    tmp_dir = pathlib.Path("/tmp") / f"gl-mirror-{repo_name}-{int(time.time())}"
    if tmp_dir.exists():
        import shutil; shutil.rmtree(tmp_dir)

    print(f"  Cloning from GitHub...")
    result = subprocess.run(
        ["git", "clone", "--mirror", repo_info['gh_url'], str(tmp_dir)],
        capture_output=True, text=True, timeout=120
    )
    if result.returncode != 0:
        print(f"  ✗ Clone failed: {result.stderr[:200]}")
        return False

    result = subprocess.run(
        ["git", "-C", str(tmp_dir), "remote", "set-url", "--push", "origin", gl_url_auth],
        capture_output=True, text=True, timeout=10
    )

    for attempt in range(retries):
        print(f"  Pushing to GitLab (attempt {attempt + 1}/{retries})...")
        result = subprocess.run(
            ["git", "-C", str(tmp_dir), "push", "--mirror", "origin"],
            capture_output=True, text=True, timeout=180
        )
        if result.returncode == 0:
            print(f"  ✓ Pushed to GitLab successfully")
            import shutil; shutil.rmtree(tmp_dir, ignore_errors=True)
            return True
        elif "403" in result.stderr or "429" in result.stderr:
            wait = delay * (attempt + 1)
            print(f"  ⚠ Rate limited. Waiting {wait}s...")
            time.sleep(wait)
        else:
            print(f"  ✗ Push failed: {result.stderr[:300]}")
            time.sleep(delay)

    import shutil; shutil.rmtree(tmp_dir, ignore_errors=True)
    return False

def mirror_via_api(repo_name, repo_info):
    """Fallback: use GitLab Repository Files API to push files one by one."""
    print(f"  Using GitLab Repository Files API fallback...")
    gl_id, gl_url = create_gl_repo(repo_info['gl_name'], repo_info['gl_description'])
    if not gl_id:
        return False

    # Get file list from GitHub
    req = urllib.request.Request(
        f"{repo_info['gh_api']}/git/trees/main?recursive=1",
        headers={"Authorization": f"token {GH_TOKEN}", "Accept": "application/vnd.github+json"})
    body = json.loads(urllib.request.urlopen(req, timeout=30).read())
    files = [t for t in body.get("tree", []) if t["type"] == "blob"]

    print(f"  Found {len(files)} files to push via API")

    # Get the default branch SHA (for creating commits)
    req = urllib.request.Request(
        f"{repo_info['gh_api']}/branches/main",
        headers={"Authorization": f"token {GH_TOKEN}", "Accept": "application/vnd.github+json"})
    branch_body = json.loads(urllib.request.urlopen(req, timeout=15).read())
    base_sha = branch_body["commit"]["sha"]

    success = 0
    failed = 0
    for i, f in enumerate(files):
        path = f["path"]
        # Fetch file content from GitHub
        req = urllib.request.Request(
            f"{repo_info['gh_api']}/contents/{path}?ref=main",
            headers={"Authorization": f"token {GH_TOKEN}", "Accept": "application/vnd.github+json"})
        try:
            gh_body = json.loads(urllib.request.urlopen(req, timeout=15).read())
            content = base64.b64decode(gh_body["content"]).decode()
        except Exception as e:
            print(f"    ✗ {path}: fetch failed ({e})")
            failed += 1
            continue

        # Push to GitLab via API
        b64_content = base64.b64encode(content.encode()).decode()
        # URL-encode the path for GitLab API
        encoded_path = urllib.request.quote(path, safe='')
        body = {
            "branch": "main",
            "content": b64_content,
            "commit_message": f"[mirror] {path}",
        }
        code, resp = gl_api("POST", f"/projects/{gl_id}/repository/files/{encoded_path}", body)
        if code in (200, 201):
            success += 1
            if (i + 1) % 10 == 0:
                print(f"    {i+1}/{len(files)} files pushed...")
        elif code == 400 and "already exists" in str(resp).lower():
            # File exists — try update
            body["action"] = "update"
            code, resp = gl_api("PUT", f"/projects/{gl_id}/repository/files/{encoded_path}", body)
            if code in (200, 201):
                success += 1
            else:
                failed += 1
                print(f"    ✗ {path}: update failed ({code})")
        else:
            failed += 1
            if isinstance(resp, dict) and resp.get("_blocked"):
                print(f"    ✗ GitLab API blocked — stopping")
                break
            print(f"    ✗ {path}: push failed ({code})")

        time.sleep(0.3)  # GitLab rate limit

    print(f"  ✓ {success}/{len(files)} files pushed, {failed} failed")
    return failed == 0

def mirror_repo(repo_name, repo_info, retries=3, delay=30, api_only=False):
    print(f"\n== Mirroring {repo_name} to GitLab ==")
    if api_only:
        return mirror_via_api(repo_name, repo_info)
    # Try git push first
    if mirror_via_git_push(repo_name, repo_info, retries, delay):
        return True
    # Fallback to API
    print(f"  Git push failed — falling back to API...")
    return mirror_via_api(repo_name, repo_info)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("repo", nargs="?", help="Specific repo to mirror (default: both)")
    ap.add_argument("--retries", type=int, default=3, help="Number of push retries")
    ap.add_argument("--delay", type=int, default=30, help="Seconds between retries")
    ap.add_argument("--daemon", action="store_true", help="Run continuously every 5 min")
    ap.add_argument("--api-only", action="store_true", help="Skip git push, use API only")
    args = ap.parse_args()

    user_id, username = get_gl_user()
    if not user_id:
        print("✗ Cannot authenticate to GitLab — check gitlab_pat or IP may be blocked")
        print("  GitHub backup is already complete. GitLab will retry automatically.")
        sys.exit(1)
    print(f"✓ GitLab user: {username} (id={user_id})")

    if args.daemon:
        while True:
            for name, info in REPOS.items():
                if args.repo and name != args.repo:
                    continue
                mirror_repo(name, info, args.retries, args.delay, args.api_only)
            print(f"\n--- Sleeping 300s before next cycle ---")
            time.sleep(300)
    else:
        success = True
        for name, info in REPOS.items():
            if args.repo and name != args.repo:
                continue
            if not mirror_repo(name, info, args.retries, args.delay, args.api_only):
                success = False
        if not success:
            print("\n⚠ GitLab backup incomplete — GitHub backup is complete.")
            print("  Run this script again later (IP may be unblocked) or use --api-only")
            sys.exit(1)

if __name__ == "__main__":
    main()
