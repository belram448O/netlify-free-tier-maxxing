#!/usr/bin/env python3
"""14_archive_to_gh.py — Archive all non-secret infra files to a private GitHub repo.

Under: your-backup-user (primary GH account, designated for backup)
Repo: domain-infra-kit (private)

Includes:
- scripts/  (all .py + .sh)
- infra/    (ARCHITECTURE.md, REPLICATE.md, SECURITY.md, worklog.md — NOT secrets.json/state.json/perms_*.json)
- top-level README.md

Excludes (via .gitignore):
- infra/secrets.json
- infra/state.json (contains non-secret IDs but kept out for cleanliness)
- infra/perms_*.json
- infra/credentials_inventory.json
"""
import json, base64, time, os, pathlib, urllib.request, urllib.error
PROJECT_ROOT = pathlib.Path(__file__).resolve().parent.parent

import pathlib; SECRETS = json.loads(open(pathlib.Path(__file__).resolve().parent.parent / "infra" / "secrets.json").read())
GH1_TOKEN = SECRETS["gh_primary_token"]
GH1_USER  = SECRETS["gh_primary_user"]
API_GH = "https://api.github.com"
REPO = "domain-infra-kit"

def gh(method, path, body=None):
    url = f"{API_GH}{path}"
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url, data=data, method=method)
    req.add_header("Authorization", f"token {GH1_TOKEN}")
    req.add_header("Accept", "application/vnd.github+json")
    if body is not None: req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            text = r.read().decode()
            return r.status, (json.loads(text) if text else {})
    except urllib.error.HTTPError as e:
        text = e.read().decode()
        try: return e.code, json.loads(text)
        except: return e.code, {"_raw": text}

# Step 1: Create repo if missing
print(f"== Creating repo {GH1_USER}/{REPO} (private) ==")
code, body = gh("GET", f"/repos/{GH1_USER}/{REPO}")
if code == 200:
    print(f"  ✓ already exists (skip)")
elif code == 404:
    code, body = gh("POST", "/user/repos", {
        "name": REPO, "private": True,
        "description": "example.com infrastructure — multi-account Cloudflare + Vercel orchestration",
        "auto_init": True, "has_issues": False, "has_wiki": False,
    })
    if code == 201:
        print(f"  ✓ created {REPO}")
    else:
        print(f"  ✗ create failed: {code} {body}")
        exit(1)
else:
    print(f"  ✗ check failed: {code} {body}")
    exit(1)

# Step 2: Walk PROJECT_ROOT and collect files to upload
ROOT = PROJECT_ROOT
EXCLUDE_DIRS = {"skills", "upload", "download", "node_modules", "__pycache__", ".git", ".venv", "tool-results"}
EXCLUDE_FILES = {".env", "secrets.json", "state.json", "credentials_inventory.json"}
EXCLUDE_PATTERNS = ["perms_", ".pyc", "credentials_inventory"]

def should_include(path):
    rel = path.relative_to(ROOT)
    parts = rel.parts
    if any(p in EXCLUDE_DIRS for p in parts):
        return False
    if path.name in EXCLUDE_FILES:
        return False
    if any(pat in path.name for pat in EXCLUDE_PATTERNS):
        return False
    if path.name.startswith(".git"):
        return False
    return True

# Collect files
files_to_upload = []
for p in ROOT.rglob("*"):
    if p.is_file() and should_include(p):
        files_to_upload.append(p)
files_to_upload.sort()
print(f"\n== Files to upload ({len(files_to_upload)}) ==")
for p in files_to_upload:
    rel = p.relative_to(ROOT)
    print(f"  {rel}")

# Step 3: Upload each file via GH Contents API
print(f"\n== Uploading files to {GH1_USER}/{REPO} ==")
def upsert_file(repo, path, content, commit_msg):
    code, body = gh("GET", f"/repos/{GH1_USER}/{repo}/contents/{path}")
    file_sha = body.get("sha") if code == 200 else None
    b64 = base64.b64encode(content.encode()).decode()
    payload = {"message": commit_msg, "content": b64, "branch": "main"}
    if file_sha: payload["sha"] = file_sha
    code, body = gh("PUT", f"/repos/{GH1_USER}/{repo}/contents/{path}", payload)
    return code, body

success = 0
failed = 0
for p in files_to_upload:
    rel = p.relative_to(ROOT).as_posix()
    content = p.read_text(errors="ignore")  # all our files are text
    # Skip binary-looking files
    if "\x00" in content[:1024]:
        print(f"  ✗ {rel} (binary, skip)")
        continue
    code, body = upsert_file(REPO, rel, content, f"[infra-bot] archive {rel}")
    if code in (200, 201):
        success += 1
        print(f"  ✓ {rel}")
    else:
        msg = body.get("message", "")[:120] if isinstance(body, dict) else ""
        print(f"  ✗ {rel}  code={code}  err={msg}")
        failed += 1
    time.sleep(0.5)  # GH secondary rate limit

print(f"\n✓ Upload complete: {success} succeeded, {failed} failed")
print(f"  Repo: https://github.com/{GH1_USER}/{REPO}")
