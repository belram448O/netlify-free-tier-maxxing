#!/usr/bin/env python3
"""e2e_test.py — pytest-compatible end-to-end test suite for example.com infra.

Runs against LIVE infrastructure (not mocks). Validates:
  1. DNS resolution (multi-resolver)
  2. Worker health endpoint
  3. Vercel docs/blog
  4. Email Routing MX/SPF/DMARC records
  5. NS delegation for each Netlify sub-zone
  6. SSL certificate validity (CF Universal SSL)
  7. State.json consistency with live infra

Usage:
  pytest scripts/e2e_test.py -v
  # or
  python3 scripts/e2e_test.py

Requires:
  - infra/secrets.json (with valid tokens)
  - infra/state.json (run 00b_rebuild_state.py first if missing)
"""
import json, pathlib, subprocess, sys, time, urllib.request, urllib.error, socket, ssl
PROJECT_ROOT = pathlib.Path(__file__).resolve().parent.parent

import pytest  # noqa  (works as plain script if pytest not installed)

SECRETS = json.loads((PROJECT_ROOT / 'infra' / 'secrets.json').read_text())
STATE = json.loads((PROJECT_ROOT / 'infra' / 'state.json').read_text())
DOMAIN = SECRETS['domain']
API_CF = "https://api.cloudflare.com/client/v4"
API_NL = "https://api.netlify.com/api/v1"
CF_TOKEN = SECRETS.get('root_zone_token') or SECRETS.get('cf_main_zone_scoped_token')
NL_TOKEN = SECRETS['netlify_token']
V_TOKEN = SECRETS['vercel_token']
V_TEAM = SECRETS['vercel_team_id']

# ─── Helpers ─────────────────────────────────────────────────────────────────

def dig(rec_type, name, server="1.1.1.1"):
    """Run dig +short, return list of answers."""
    try:
        out = subprocess.check_output(
            ["dig", "+short", rec_type, name, f"@{server}"],
            timeout=10, stderr=subprocess.DEVNULL
        ).decode().strip()
        return [l for l in out.split("\n") if l]
    except Exception:
        return []

def curl(url, timeout=15):
    """Curl URL with -k (skip SSL verify, since CF cert is signed by Google Trust Services which isn't in default CA bundle), return (code, body)."""
    try:
        result = subprocess.run(
            ["curl", "-sk", "-m", str(timeout), "-w", "\n%{http_code}", url],
            capture_output=True, timeout=timeout+5
        )
        out = result.stdout.decode()
        lines = out.rsplit("\n", 1)
        if len(lines) == 2:
            body, code = lines
            return int(code), body
        return 0, out
    except Exception as e:
        return 0, str(e)

def cf_api(path):
    req = urllib.request.Request(f"{API_CF}{path}")
    req.add_header("Authorization", f"Bearer {CF_TOKEN}")
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            return r.status, json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read().decode() or "{}")

def nl_api(path):
    req = urllib.request.Request(f"{API_NL}{path}")
    req.add_header("Authorization", f"Bearer {NL_TOKEN}")
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            text = r.read().decode()
            return r.status, (json.loads(text) if text else [])
    except urllib.error.HTTPError as e:
        return e.code, []

# ─── Tests: DNS resolution ───────────────────────────────────────────────────

def test_ns_at_cloudflare_via_1_1_1_1():
    ns = dig("NS", DOMAIN, "1.1.1.1")
    assert any("cloudflare" in n for n in ns), f"NS should be Cloudflare, got: {ns}"

def test_ns_at_cloudflare_via_8_8_8_8():
    ns = dig("NS", DOMAIN, "8.8.8.8")
    assert any("cloudflare" in n for n in ns), f"NS should be Cloudflare, got: {ns}"

def test_ns_at_cloudflare_via_9_9_9_9():
    ns = dig("NS", DOMAIN, "9.9.9.9")
    assert any("cloudflare" in n for n in ns), f"NS should be Cloudflare, got: {ns}"

# ─── Tests: Apex records ─────────────────────────────────────────────────────

def test_apex_a_record():
    a = dig("A", DOMAIN)
    assert len(a) > 0, f"apex A record missing"
    # Should be CF anycast IPs (104.x or 172.x range)
    assert any(ip.startswith(("104.", "172.")) for ip in a), f"apex A not CF edge: {a}"

def test_apex_spf():
    txt = dig("TXT", DOMAIN)
    assert any("v=spf1" in t and "cloudflare" in t.lower() for t in txt), f"SPF missing: {txt}"

def test_dmarc_record():
    dmarc = dig("TXT", f"_dmarc.{DOMAIN}")
    assert any("v=DMARC1" in d for d in dmarc), f"DMARC missing: {dmarc}"

def test_mta_sts_record():
    mta = dig("TXT", f"_mta-sts.{DOMAIN}")
    assert any("v=STSv1" in m for m in mta), f"MTA-STS missing: {mta}"

def test_caa_records():
    caa = dig("CAA", DOMAIN)
    # Should have at least 2 CAA records (cloudflare + letsencrypt)
    assert len(caa) >= 2, f"Expected >=2 CAA records, got: {caa}"

# ─── Tests: MX records (Email Routing) ───────────────────────────────────────

def test_mx_records():
    mx = dig("MX", DOMAIN)
    assert any("cloudflare.net" in m for m in mx), f"MX should be CF route1/2/3, got: {mx}"

# ─── Tests: NS delegation for each sub-zone ──────────────────────────────────

@pytest.mark.parametrize("prefix", list(STATE.get("subzones", {}).keys()))
def test_subzone_ns_delegation(prefix):
    sub = STATE["subzones"][prefix]["name"]
    expected_ns = STATE["subzones"][prefix]["dns_servers"]
    actual_ns = dig("NS", sub)
    for ns in expected_ns:
        assert ns in actual_ns or ns + "." in actual_ns, \
            f"{sub} NS delegation missing {ns}; got: {actual_ns}"

# ─── Tests: HTTP reachability ─────────────────────────────────────────────────

def test_apex_worker_health():
    code, body = curl(f"https://{DOMAIN}/__health")
    assert code == 200, f"apex /__health: HTTP {code}"
    data = json.loads(body)
    assert data.get("ok") is True
    assert data.get("worker") == "example-root-worker"

def test_www_worker_health():
    code, body = curl(f"https://www.{DOMAIN}/__health")
    assert code == 200, f"www /__health: HTTP {code}"

def test_docs_https():
    code, _ = curl(f"https://docs.{DOMAIN}/")
    assert code == 200, f"docs: HTTP {code}"

def test_blog_https():
    code, _ = curl(f"https://blog.{DOMAIN}/")
    assert code == 200, f"blog: HTTP {code}"

# ─── Tests: SSL certificate validity ─────────────────────────────────────────

def test_apex_ssl_cert():
    """Verify CF Universal SSL cert is valid for at least 30 more days."""
    try:
        context = ssl.create_default_context()
        with socket.create_connection((DOMAIN, 443), timeout=10) as sock:
            with context.wrap_socket(sock, server_hostname=DOMAIN) as ssock:
                cert = ssock.getpeercert()
                assert cert is not None, "no cert returned"
                # Check not_after is at least 30 days out
                not_after = cert.get("notAfter", "")
                # Format: "Sep 13 12:21:36 2026 GMT"
                import datetime
                expire = datetime.datetime.strptime(not_after, "%b %d %H:%M:%S %Y %Z")
                days_left = (expire - datetime.datetime.utcnow()).days
                assert days_left > 30, f"SSL cert expires in {days_left} days (< 30)"
    except (ssl.SSLError, socket.timeout, ConnectionRefusedError) as e:
        pytest.skip(f"SSL check skipped: {e}")

# ─── Tests: Vercel deployments via API ───────────────────────────────────────

def test_vercel_docs_ready():
    req = urllib.request.Request(
        f"https://api.vercel.com/v9/projects?teamId={V_TEAM}&limit=20",
        headers={"Authorization": f"Bearer {V_TOKEN}"})
    body = json.loads(urllib.request.urlopen(req, timeout=15).read())
    docs = next((p for p in body.get("projects", []) if p.get("name") == "example-docs"), None)
    assert docs is not None, "example-docs Vercel project not found"
    latest = docs.get("latestDeployments", [{}])[0]
    assert latest.get("readyState") == "READY", f"latest deployment: {latest.get('readyState')}"

def test_vercel_blog_ready():
    req = urllib.request.Request(
        f"https://api.vercel.com/v9/projects?teamId={V_TEAM}&limit=20",
        headers={"Authorization": f"Bearer {V_TOKEN}"})
    body = json.loads(urllib.request.urlopen(req, timeout=15).read())
    blog = next((p for p in body.get("projects", []) if p.get("name") == "example-blog"), None)
    assert blog is not None, "example-blog Vercel project not found"
    latest = blog.get("latestDeployments", [{}])[0]
    assert latest.get("readyState") == "READY", f"latest deployment: {latest.get('readyState')}"

# ─── Tests: State.json consistency ────────────────────────────────────────────

def test_state_root_zone_id_matches_live():
    code, body = cf_api(f"/zones?name={DOMAIN}")
    live_id = body["result"][0]["id"]
    state_id = STATE["root_zone"]["id"]
    assert live_id == state_id, f"state id {state_id} != live id {live_id}"

def test_state_subzones_match_live():
    code, body = nl_api("/dns_zones")
    live_names = sorted([z.get("name") for z in body if isinstance(body, list)])
    state_names = sorted([info["name"] for info in STATE.get("subzones", {}).values()])
    assert set(state_names) == set(live_names), \
        f"state subzones mismatch: state={state_names} live={live_names}"

def test_state_worker_routes_match_live():
    code, body = cf_api(f"/zones/{STATE['root_zone']['id']}/workers/routes")
    live_routes = sorted([r.get("pattern") for r in body.get("result", [])])
    state_routes = sorted([r.get("pattern") for r in STATE.get("root_worker", {}).get("routes", [])])
    assert set(state_routes) == set(live_routes), \
        f"worker routes mismatch: state={state_routes} live={live_routes}"

# ─── Allow running as plain script (no pytest) ──────────────────────────────

def _run_all_tests():
    """Discover all test_* functions and run them; print summary."""
    tests = [name for name in globals() if name.startswith("test_")]
    passed = 0
    failed = 0
    skipped = 0
    failures = []
    for name in sorted(tests):
        fn = globals()[name]
        try:
            # Handle parametrize for subzone tests
            if name == "test_subzone_ns_delegation":
                for prefix in STATE.get("subzones", {}).keys():
                    test_name = f"{name}[{prefix}]"
                    try:
                        fn(prefix)
                        print(f"  ✓ {test_name}")
                        passed += 1
                    except AssertionError as e:
                        print(f"  ✗ {test_name}: {e}")
                        failed += 1
                        failures.append((test_name, str(e)))
                continue
            fn()
            print(f"  ✓ {name}")
            passed += 1
        except AssertionError as e:
            print(f"  ✗ {name}: {e}")
            failed += 1
            failures.append((name, str(e)))
        except Exception as e:
            print(f"  ⚠ {name}: skipped ({e})")
            skipped += 1
    print(f"\n=== SUMMARY: {passed} passed, {failed} failed, {skipped} skipped ===")
    if failed:
        print("\nFailures:")
        for name, msg in failures:
            print(f"  ✗ {name}: {msg}")
        sys.exit(1)
    sys.exit(0)

if __name__ == "__main__":
    _run_all_tests()
