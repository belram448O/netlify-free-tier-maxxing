#!/usr/bin/env python3
"""21_mint_admin_token.py — Mint a token with full Account Settings:Write + Members:Edit
so we can attempt 2FA enforcement programmatically. Also adds Memberships:Read.
"""
import json, urllib.request, urllib.error, pathlib
PROJECT_ROOT = pathlib.Path(__file__).resolve().parent.parent

SECRETS = json.loads((PROJECT_ROOT / 'infra' / 'secrets.json').read_text())
master = SECRETS['cf_main_token']
acct = SECRETS['cf_main_account_id']

def cf(method, path, body=None):
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(f"https://api.cloudflare.com/client/v4{path}", data=data, method=method)
    req.add_header("Authorization", f"Bearer {master}")
    if body is not None: req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            return r.status, json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read().decode() or "{}")

# Catalog
code, body = cf("GET", f"/accounts/{acct}/tokens/permission_groups?audience=account")
groups = body.get("result", [])

# We want ALL permissions to find any 2FA-related ones
print("=== Searching for 2FA / member-related permissions ===")
keywords = ["two", "2fa", "factor", "member", "account setting", "user"]
for g in sorted(groups, key=lambda x: x["name"]):
    name_lower = g["name"].lower()
    if any(k in name_lower for k in keywords):
        print(f"  {g['id']}  {g['name']}")

# Mint a token with Account Settings Write + Account Member Read/Write
needed_names = [
    "Account Settings Read", "Account Settings Write",
    "Memberships Read", "Account API Tokens Read",
    # Plus the standard ops we already have
    "Zone Read", "Zone Write", "Zone Settings Read", "Zone Settings Write",
    "DNS Read", "DNS Write",
    "Workers Scripts Read", "Workers Scripts Write",
    "Workers Routes Read", "Workers Routes Write",
    "Email Routing Addresses Read", "Email Routing Addresses Write",
    "Email Routing Rules Read", "Email Routing Rules Write",
    "Email Security DMARC Reports Read",
    "Workers KV Storage Read", "Workers KV Storage Write",
    "Workers R2 Storage Read", "Workers R2 Storage Write",
    "Pages Read", "Pages Write",
    "SSL and Certificates Read", "SSL and Certificates Write",
]
perm_ids = [{"id": g["id"]} for g in groups if g["name"] in needed_names]
print(f"\n=== Minting token with {len(perm_ids)} permission groups ===")
print(f"  resolved: {[n for n in needed_names if any(g['name']==n for g in groups)]}")
missing = [n for n in needed_names if not any(g['name']==n for g in groups)]
if missing:
    print(f"  MISSING: {missing}")

body = {
    "name": "example-admin-ops",
    "policies": [{
        "effect": "allow",
        "resources": {f"com.cloudflare.api.account.{acct}": "*"},
        "permission_groups": perm_ids,
    }],
}
code, resp = cf("POST", f"/accounts/{acct}/tokens", body)
if resp.get("success"):
    tok = resp["result"]["value"]
    print(f"\n✓ minted: id={resp['result']['id']} name={resp['result']['name']}")
    SECRETS["admin_token"] = tok
    (PROJECT_ROOT / 'infra' / 'secrets.json').write_text(json.dumps(SECRETS, indent=2, sort_keys=True))
    (PROJECT_ROOT / 'infra' / 'secrets.json').chmod(0o600)
    print(f"  saved as admin_token in secrets.json")
else:
    print(f"  err: {resp}")
