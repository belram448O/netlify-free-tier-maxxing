#!/usr/bin/env python3
"""11_trigger_vercel_deploys.py — Trigger production deploys for example-docs and example-blog."""
import json, pathlib, urllib.request, urllib.error, time
PROJECT_ROOT = pathlib.Path(__file__).resolve().parent.parent

SECRETS = json.loads((PROJECT_ROOT / 'infra' / 'secrets.json').read_text())
API_V = "https://api.vercel.com"
VERCEL_TOKEN = SECRETS["vercel_token"]
VERCEL_TEAM  = SECRETS["vercel_team_id"]
GH2_TOKEN    = SECRETS["gh_secondary_token"]
GH2_USER     = SECRETS["gh_secondary_user"]

def api(method, url, token, body=None):
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url, data=data, method=method)
    req.add_header("Authorization", f"Bearer {token}")
    if body is not None: req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            text = r.read().decode()
            if not text: return r.status, {}
            try: return r.status, json.loads(text)
            except: return r.status, {"_raw": text}
    except urllib.error.HTTPError as e:
        text = e.read().decode()
        try: return e.code, json.loads(text or "{}")
        except: return e.code, {"_raw": text}

# Get projects
code, body = api("GET", f"{API_V}/v9/projects?teamId={VERCEL_TEAM}", VERCEL_TOKEN)
projects = body.get("projects", [])

# Get the latest commit SHA of each GH repo (for the deployment ref)
def get_latest_commit_sha(repo):
    code, body = api("GET", f"https://api.github.com/repos/{GH2_USER}/{repo}/commits?per_page=1", GH2_TOKEN)
    if code == 200 and isinstance(body, list) and body:
        return body[0].get("sha"), body[0].get("commit", {}).get("message", "")
    return None, None

# Trigger a production deploy for each
for proj in projects:
    pid = proj["id"]
    pname = proj["name"]
    if "docs" in pname:
        repo = "example-docs"
    elif "blog" in pname:
        repo = "example-blog"
    else:
        continue
    print(f"\n== {pname} (repo: {repo}) ==")
    sha, msg = get_latest_commit_sha(repo)
    if not sha:
        print(f"  no commits found")
        continue
    print(f"  latest commit: {sha[:12]}…  msg={msg[:60]}")
    # Trigger deploy via Vercel API: POST /v13/deployments
    payload = {
        "name": pname,
        "project": pname,
        "target": "production",
        "gitSource": {
            "type": "github",
            "org": GH2_USER,
            "repo": repo,
            "ref": sha,
            "sha": sha,
        },
    }
    # Wait — gitSource is the field name for the DEPLOY endpoint (different from project create)
    code, body = api("POST", f"{API_V}/v13/deployments?teamId={VERCEL_TEAM}", VERCEL_TOKEN, payload)
    if code in (200, 201):
        d = body
        print(f"  ✓ deploy triggered (id={d.get('id', '?')[:12]}… url={d.get('url', '?')[:60]})")
    else:
        msg = body.get("error", {}).get("message", "") if isinstance(body, dict) else ""
        if not msg: msg = str(body)[:200]
        print(f"  ✗ deploy failed: code={code} err={msg}")

# Poll deployment status for up to 60s
print("\n== Polling deploy status (60s timeout) ==")
end = time.time() + 60
while time.time() < end:
    time.sleep(5)
    code, body = api("GET", f"{API_V}/v6/deployments?teamId={VERCEL_TEAM}&limit=10", VERCEL_TOKEN)
    deps = body.get("deployments", [])
    for d in deps:
        pname = d.get("name", "?")
        state = d.get("readyState", "?")
        ready = d.get("ready", False)
        url = d.get("url", "")
        created = d.get("createdAt", 0)
        if time.time() - created/1000 > 300: continue
        print(f"  {pname:30s}  state={state:14s}  ready={ready}  url={url[:50]}")
    if all(d.get("readyState") in ("READY", "ERROR") for d in deps[:2]):
        break
