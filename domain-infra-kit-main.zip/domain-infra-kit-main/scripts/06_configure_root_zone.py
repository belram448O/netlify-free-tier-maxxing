#!/usr/bin/env python3
"""06_configure_root_zone.py — Full configuration of the root example.com zone at CF MAIN.

Implements peer-review recommendations:
  - I1 (grey-cloud / DNS-only for Vercel CNAMEs)
  - I3 (DMARC records per email-routing zone)
  - I2 (2FA enforcement) — flagged as manual user step at end

Steps:
  1. Verify root zone exists (created earlier, status=pending)
  2. Create DNS records:
     a. Apex placeholder A record → 192.0.2.1 (will be replaced by Worker custom domain)
     b. www CNAME → example.com (legacy compat)
     c. NS delegation for users.example.com → CF SUB zone's NS (will succeed once user creates sub-zone)
     d. CNAME docs.example.com  → cname.vercel-dns.com  (DNS-only / grey cloud)
     e. CNAME blog.example.com  → cname.vercel-dns.com  (DNS-only / grey cloud)
     f. CNAME help.example.com  → placeholder.example.com (DNS-only; user replaces with vendor)
     g. NS delegation for app/content/corp/api/cdn — placeholders for future subdomain accounts
     h. TXT _dmarc.example.com → DMARC record (per I3)
     i. TXT _dmarc.users.example.com → DMARC record (for sub-zone, only applies if user creates it)
     j. TXT example.com → SPF (CF Email Routing will set this when enabled; we set baseline)
  3. Deploy Worker "example-root-worker" at CF MAIN
  4. Bind Worker to custom domain example.com (replaces apex placeholder A record)
  5. Enable Email Routing on example.com
  6. Set up catch-all rule: *@example.com → external destination (placeholder)
  7. Add DMARC report destination mailbox
"""
import json, pathlib, sys, time, urllib.request, urllib.error
PROJECT_ROOT = pathlib.Path(__file__).resolve().parent.parent

SECRETS = json.loads((PROJECT_ROOT / 'infra' / 'secrets.json').read_text())
STATE_PATH = PROJECT_ROOT / 'infra' / 'state.json'
STATE = json.loads(STATE_PATH.read_text()) if STATE_PATH.exists() else {}
API = "https://api.cloudflare.com/client/v4"

MAIN_TOKEN = SECRETS["root_zone_token"]
MAIN_ACCT  = SECRETS["cf_main_account_id"]
SUB_TOKEN  = SECRETS["sub_zone_token"]
SUB_ACCT   = SECRETS["cf_sub_account_id"]
DOMAIN     = SECRETS["domain"]

# Email routing destination (placeholder — user edits later via dashboard or API)
EMAIL_DEST = "admin@example.com"  # CF Email Routing will require verifying this via email link

def cf(method, path, token, body=None):
    url = f"{API}{path}"
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url, data=data, method=method)
    req.add_header("Authorization", f"Bearer {token}")
    if body is not None: req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            return r.status, json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read().decode() or "{}")

def ok(label, code, body):
    succ = body.get("success") if isinstance(body, dict) else False
    errs = body.get("errors") if isinstance(body, dict) else None
    if succ:
        print(f"  ✓ {label}")
        return True
    else:
        # Common idempotent case: record already exists
        msg = errs[0].get("message", "")[:200] if errs and isinstance(errs, list) and errs else ""
        print(f"  ✗ {label}  code={code}  err={msg}")
        return False

def get_zone(name, token):
    code, body = cf("GET", f"/zones?name={name}", token)
    if code == 200 and body.get("result"):
        return body["result"][0]
    return None

def get_records(zone_id, token):
    code, body = cf("GET", f"/zones/{zone_id}/dns_records?per_page=200", token)
    if code == 200:
        return body.get("result", [])
    return []

def upsert_record(zone_id, token, rtype, name, content, proxied=False, ttl=1, priority=None):
    """Create a DNS record; if same name+type exists, update it."""
    recs = get_records(zone_id, token)
    existing = [r for r in recs if r["type"] == rtype and r["name"] == name]
    body = {"type": rtype, "name": name, "content": content, "ttl": ttl, "proxied": proxied}
    if priority is not None:
        body["priority"] = priority
    if existing:
        rid = existing[0]["id"]
        code, resp = cf("PUT", f"/zones/{zone_id}/dns_records/{rid}", token, body)
        ok_ = ok(f"update {rtype:6s} {name:35s} → {content[:40]}{'…' if len(content)>40 else ''}", code, resp)
        return ok_
    else:
        code, resp = cf("POST", f"/zones/{zone_id}/dns_records", token, body)
        ok_ = ok(f"create {rtype:6s} {name:35s} → {content[:40]}{'…' if len(content)>40 else ''}", code, resp)
        return ok_

# ──────────────────────────────────────────────────────────────────────────────
# STEP 1: Verify root zone
# ──────────────────────────────────────────────────────────────────────────────
print("== Step 1: Verify root zone example.com at CF MAIN ==")
root_zone = get_zone(DOMAIN, MAIN_TOKEN)
if not root_zone:
    print(f"  FATAL: root zone {DOMAIN} not found at CF MAIN. Run 01_create_zones.py first.")
    sys.exit(1)
print(f"  found: id={root_zone['id']} status={root_zone['status']}")
print(f"  assigned NS: {root_zone.get('name_servers')}")
ROOT_ZONE_ID = root_zone["id"]
STATE["root_zone"] = {
    "name": root_zone["name"], "id": root_zone["id"],
    "account_id": MAIN_ACCT, "status": root_zone["status"],
    "name_servers": root_zone.get("name_servers", []),
}

# ──────────────────────────────────────────────────────────────────────────────
# STEP 2: Check if subdomain zone users.example.com exists at CF SUB
# ──────────────────────────────────────────────────────────────────────────────
print("\n== Step 2: Check if users.example.com zone exists at CF SUB ==")
sub_zone = get_zone("users.example.com", SUB_TOKEN)
if sub_zone:
    print(f"  ✓ EXISTS: id={sub_zone['id']} status={sub_zone['status']}")
    print(f"    NS: {sub_zone.get('name_servers')}")
    STATE["sub_zone"] = {
        "name": sub_zone["name"], "id": sub_zone["id"],
        "account_id": SUB_ACCT, "status": sub_zone["status"],
        "name_servers": sub_zone.get("name_servers", []),
    }
    SUB_ZONE_NS = sub_zone.get("name_servers", [])
else:
    print("  ✗ NOT FOUND at CF SUB.")
    print("     This is expected — CF API cannot create subdomain zones automatically.")
    print("     Manual creation required. See instructions at end of run.")
    SUB_ZONE_NS = None

# ──────────────────────────────────────────────────────────────────────────────
# STEP 3: Create DNS records in root zone
# ──────────────────────────────────────────────────────────────────────────────
print("\n== Step 3: Configure DNS records in root zone ==")
DMARC_RUA = "mailto:admin@example.com"
DMARC_TXT = f"v=DMARC1; p=quarantine; rua={DMARC_RUA}; ruf={DMARC_RUA}; pct=100; adkim=s; aspf=s"
SPF_TXT   = "v=spf1 include:_spf.mx.cloudflare.net ~all"  # CF Email Routing SPF include
MTA_STS   = "v=STSv1; id=20260815T000000"

# a. Apex A placeholder (CF Workers custom domain will override this)
upsert_record(ROOT_ZONE_ID, MAIN_TOKEN, "A",     DOMAIN,                "192.0.2.1", proxied=True)
# b. www CNAME → apex (legacy compatibility)
upsert_record(ROOT_ZONE_ID, MAIN_TOKEN, "CNAME", f"www.{DOMAIN}",       DOMAIN, proxied=True)
# c. NS delegation for users.example.com (if sub-zone exists at CF SUB)
if SUB_ZONE_NS:
    for ns in SUB_ZONE_NS:
        upsert_record(ROOT_ZONE_ID, MAIN_TOKEN, "NS", f"users.{DOMAIN}", ns)
# d. CNAME docs. → Vercel (DNS-only / grey cloud per peer-review I1)
upsert_record(ROOT_ZONE_ID, MAIN_TOKEN, "CNAME", f"docs.{DOMAIN}", "cname.vercel-dns.com", proxied=False)
# e. CNAME blog. → Vercel (DNS-only)
upsert_record(ROOT_ZONE_ID, MAIN_TOKEN, "CNAME", f"blog.{DOMAIN}", "cname.vercel-dns.com", proxied=False)
# f. CNAME help. → placeholder third-party (DNS-only; user replaces with vendor hostname)
upsert_record(ROOT_ZONE_ID, MAIN_TOKEN, "CNAME", f"help.{DOMAIN}", "helpdesk.example.com", proxied=False)
# g. TXT SPF at apex (will be merged with CF Email Routing's SPF include)
upsert_record(ROOT_ZONE_ID, MAIN_TOKEN, "TXT",   DOMAIN,     SPF_TXT)
# h. TXT DMARC at _dmarc.example.com (per peer-review I3)
upsert_record(ROOT_ZONE_ID, MAIN_TOKEN, "TXT",   f"_dmarc.{DOMAIN}",       DMARC_TXT)
# i. TXT DMARC for users. subdomain (for when sub-zone exists)
upsert_record(ROOT_ZONE_ID, MAIN_TOKEN, "TXT",   f"_dmarc.users.{DOMAIN}", DMARC_TXT)
# j. TXT MTA-STS for email security hardening
upsert_record(ROOT_ZONE_ID, MAIN_TOKEN, "TXT",   f"_mta-sts.{DOMAIN}",     MTA_STS)
# k. CAA — restrict cert issuance to Lets Encrypt + CF (defensive)
# Use direct POST with structured `data` field — NOT upsert_record (which matches
# by type+name only and would silently truncate to 1 of 3 CAA records).
# (Historical note: this fix was originally in a separate 07_fix_root_zone_issues.py
# script, but was backported here in Wave 2 — 07 was deleted as redundant.)
print("  -- CAA records (direct POST, idempotent via match on data field) --")
existing_recs_root = get_records(ROOT_ZONE_ID, MAIN_TOKEN)
existing_caas_root = [r for r in existing_recs_root if r["type"] == "CAA" and r["name"] == DOMAIN]
caa_specs_root = [
    {"flags": 0, "tag": "issue",   "value": "cloudflare.com"},
    {"flags": 0, "tag": "issue",   "value": "letsencrypt.org"},
    {"flags": 0, "tag": "iodef",   "value": f"mailto:admin@{DOMAIN}"},
]
for caa in caa_specs_root:
    if any(r.get("data", {}).get("tag") == caa["tag"] and r.get("data", {}).get("value") == caa["value"] for r in existing_caas_root):
        print(f"     skip CAA {caa['tag']:6s} {caa['value']} (already exists)")
        continue
    body = {"type": "CAA", "name": DOMAIN, "data": caa, "ttl": 1, "proxied": False}
    code, resp = cf("POST", f"/zones/{ROOT_ZONE_ID}/dns_records", MAIN_TOKEN, body)
    ok(f"create CAA {caa['tag']:6s} {caa['value']}", code, resp)

# ──────────────────────────────────────────────────────────────────────────────
# STEP 4: Deploy Worker at CF MAIN
# ──────────────────────────────────────────────────────────────────────────────
print("\n== Step 4: Deploy Worker 'example-root-worker' at CF MAIN ==")
WORKER_NAME = "example-root-worker"
WORKER_SCRIPT = r"""
// example.com root worker — landing page + health check
// Auto-deployed by infra orchestration; safe to replace with real landing later.

const HTML = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>example.com — Landing</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    :root { color-scheme: light dark; }
    body { font: 16px/1.5 system-ui, -apple-system, sans-serif; max-width: 640px;
           margin: 4rem auto; padding: 0 1.5rem; color: #1a1a1a; }
    h1 { font-size: 2rem; margin: 0 0 0.5rem; }
    code { background: #f4f4f4; padding: 0.1em 0.3em; border-radius: 4px; }
    .meta { color: #666; font-size: 0.9rem; margin-top: 2rem; border-top: 1px solid #eee; padding-top: 1rem; }
  </style>
</head>
<body>
  <h1>example.com</h1>
  <p>Placeholder landing page served from a Cloudflare Worker on the root account.</p>
  <p>Replace this with the real landing site when ready.</p>
  <div class="meta">
    <strong>Worker:</strong> example-root-worker<br>
    <strong>Account:</strong> CF MAIN (isolated)<br>
    <strong>Routing:</strong> custom domain bound at the apex
  </div>
</body>
</html>`;

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    if (url.pathname === '/__health') {
      return new Response(JSON.stringify({
        ok: true,
        service: 'example.com root',
        worker: 'example-root-worker',
        ts: new Date().toISOString(),
        region: request.cf?.colo || 'unknown',
      }), { headers: { 'content-type': 'application/json' } });
    }
    return new Response(HTML, { headers: { 'content-type': 'text/html;charset=utf-8' } });
  },
};
"""

# Upload worker script (ES module syntax)
module_body = {
    "main_module": "worker.js",
    "bindings": [],
    "compatibility_date": "2024-09-23",
    "compatibility_flags": ["nodejs_compat"],
}
multipart_body = (
    f'--formdata-boundary\r\n'
    f'Content-Disposition: form-data; name="metadata"\r\n'
    f'Content-Type: application/json\r\n\r\n'
    f'{json.dumps(module_body)}\r\n'
    f'--formdata-boundary\r\n'
    f'Content-Disposition: form-data; name="worker.js"; filename="worker.js"\r\n'
    f'Content-Type: application/javascript+module\r\n\r\n'
    f'{WORKER_SCRIPT}\r\n'
    f'--formdata-boundary--\r\n'
).encode()
req = urllib.request.Request(
    f"{API}/accounts/{MAIN_ACCT}/workers/scripts/{WORKER_NAME}",
    data=multipart_body, method="PUT",
)
req.add_header("Authorization", f"Bearer {MAIN_TOKEN}")
req.add_header("Content-Type", 'multipart/form-data; boundary=formdata-boundary')
try:
    with urllib.request.urlopen(req, timeout=30) as r:
        code, resp = r.status, json.loads(r.read().decode())
except urllib.error.HTTPError as e:
    code, resp = e.code, json.loads(e.read().decode() or "{}")
ok(f"deploy worker {WORKER_NAME}", code, resp)
STATE["root_worker"] = {"name": WORKER_NAME, "account_id": MAIN_ACCT}

# ──────────────────────────────────────────────────────────────────────────────
# STEP 5: Bind Worker via Worker Routes (NOT Custom Domain binding)
#
# HISTORY: We initially tried POST /accounts/{acct}/workers/scripts/{name}/domains
# (Worker Custom Domain binding). That endpoint doesn't exist — the correct endpoint
# is PUT /accounts/{acct}/workers/domains with body
# {"hostname": ..., "service": "production.<worker_name>", "zone_id": ...}.
# We received error "Method not allowed for this authentication scheme" which
# we initially misdiagnosed as a token permission issue — actually it was a
# 405 from CF's catch-all handler for unknown sub-paths.
#
# We chose to keep Worker Routes as the binding mechanism because:
#   - Both approaches rely on CF Universal SSL (no SSL difference)
#   - Worker Custom Domain auto-manages the apex A record; Worker Routes
#     requires manual 192.0.2.1 placeholder (created in STEP 3 above)
#   - Worker Routes supports wildcard patterns (*.example.com/*) which
#     Worker Custom Domain does NOT — more flexible for future expansion
#
# Reference: https://developers.cloudflare.com/dns/llms-full.txt (apex A 192.0.2.1
# proxied pattern is the canonical recommendation for worker-backed zones)
# ──────────────────────────────────────────────────────────────────────────────
print("\n== Step 5: Bind Worker via Route (example.com/* → example-root-worker) ==")
# Check existing route
code, resp = cf("GET", f"/zones/{ROOT_ZONE_ID}/workers/routes", MAIN_TOKEN)
existing_routes = resp.get("result", []) if isinstance(resp, dict) else []

apex_route = [r for r in existing_routes if r.get("pattern") == f"{DOMAIN}/*"]
if apex_route:
    print(f"  ✓ skip: route {DOMAIN}/* already bound to {apex_route[0].get('script')}")
else:
    code, resp = cf("POST", f"/zones/{ROOT_ZONE_ID}/workers/routes", MAIN_TOKEN, {
        "pattern": f"{DOMAIN}/*", "script": WORKER_NAME
    })
    ok(f"create route {DOMAIN}/* → {WORKER_NAME}", code, resp)

# Also bind www.example.com/* to the same worker (legacy compat)
www_route = [r for r in existing_routes if r.get("pattern") == f"www.{DOMAIN}/*"]
if www_route:
    print(f"  ✓ skip: route www.{DOMAIN}/* already bound to {www_route[0].get('script')}")
else:
    code, resp = cf("POST", f"/zones/{ROOT_ZONE_ID}/workers/routes", MAIN_TOKEN, {
        "pattern": f"www.{DOMAIN}/*", "script": WORKER_NAME
    })
    ok(f"create route www.{DOMAIN}/* → {WORKER_NAME}", code, resp)

# ──────────────────────────────────────────────────────────────────────────────
# STEP 6: Enable Email Routing on example.com
# ──────────────────────────────────────────────────────────────────────────────
print("\n== Step 6: Enable Email Routing on example.com ==")
# POST /zones/{id}/email/routing/enable
code, resp = cf("POST", f"/zones/{ROOT_ZONE_ID}/email/routing/enable", MAIN_TOKEN)
er_enabled = False
er_last_error = None
if isinstance(resp, dict) and resp.get("success"):
    print(f"  ✓ Email Routing enabled on {DOMAIN}")
    er_enabled = True
elif isinstance(resp, dict) and resp.get("errors"):
    errs = resp["errors"]
    msg = errs[0].get("message", "")[:200] if errs and isinstance(errs, list) and errs else ""
    if "already enabled" in msg.lower() or code == 409:
        print(f"  ✓ Email Routing already enabled")
        er_enabled = True
    else:
        print(f"  ✗ enable failed: code={code} err={msg}")
        er_last_error = msg[:200]
STATE["root_email_routing"] = {"zone_id": ROOT_ZONE_ID, "enabled": er_enabled, "last_error": er_last_error}

# Fetch the MX records CF generated for email routing
code, resp = cf("GET", f"/zones/{ROOT_ZONE_ID}/email/routing", MAIN_TOKEN)
if isinstance(resp, dict) and resp.get("result"):
    er = resp["result"]
    print(f"  status: {er.get('status')}  name: {er.get('name')}")
    # CF auto-creates MX/SPF/TXT records when enabled; verify they exist
    mx_recs = [r for r in get_records(ROOT_ZONE_ID, MAIN_TOKEN) if r["type"] == "MX"]
    print(f"  MX records now in zone: {len(mx_recs)}")
    for r in mx_recs:
        print(f"    {r['name']}  MX  {r['content']} (pri {r.get('priority')})")

# ──────────────────────────────────────────────────────────────────────────────
# STEP 7: Set up Email Routing destination + catch-all rule
# ──────────────────────────────────────────────────────────────────────────────
print(f"\n== Step 7: Register Email Routing destination ({EMAIL_DEST}) ==")
# Note: CF requires verifying the destination by sending a verification email
# POST /zones/{id}/email/routing/addresses  body: {email: "..."}
code, resp = cf("POST", f"/zones/{ROOT_ZONE_ID}/email/routing/addresses", MAIN_TOKEN, {"email": EMAIL_DEST})
if isinstance(resp, dict) and resp.get("success"):
    print(f"  ✓ destination {EMAIL_DEST} registered (CHECK INBOX for verification link)")
elif isinstance(resp, dict) and resp.get("errors"):
    errs = resp["errors"]
    msg = errs[0].get("message", "")[:200] if errs and isinstance(errs, list) and errs else ""
    if "already" in msg.lower() or code == 409:
        print(f"  ✓ destination {EMAIL_DEST} already registered")
    else:
        print(f"  ✗ destination register failed: code={code} err={msg}")

# Set up catch-all rule
print("\n== Step 8: Set up Email Routing catch-all rule ==")
# GET existing catch-all
code, resp = cf("GET", f"/zones/{ROOT_ZONE_ID}/email/routing/rules/catch_all", MAIN_TOKEN)
existing = resp.get("result") if isinstance(resp, dict) else None
catchall_body = {
    "name": "example.com catch-all",
    "enabled": True,
    "matchers": [{"type": "all"}],
    "actions": [{"type": "forward", "value": [EMAIL_DEST]}],
}
if existing and existing.get("enabled"):
    print(f"  ✓ catch-all already enabled (id={existing.get('id')[:12]}…)")
else:
    code, resp = cf("PUT", f"/zones/{ROOT_ZONE_ID}/email/routing/rules/catch_all", MAIN_TOKEN, catchall_body)
    if isinstance(resp, dict) and resp.get("success"):
        print(f"  ✓ catch-all rule enabled: *@{DOMAIN} → {EMAIL_DEST}")
    else:
        errs = resp.get("errors") if isinstance(resp, dict) else None
        msg = errs[0].get("message", "")[:200] if errs and isinstance(errs, list) and errs else ""
        print(f"  ✗ catch-all failed: code={code} err={msg}")

# ──────────────────────────────────────────────────────────────────────────────
# Save state + print manual next steps
# ──────────────────────────────────────────────────────────────────────────────
STATE_PATH.write_text(json.dumps(STATE, indent=2, sort_keys=True))
print(f"\n✓ State saved to {STATE_PATH}")
print("\n" + "=" * 78)
print("NEXT STEPS FOR USER (manual — cannot be done via API):")
print("=" * 78)
print(f"""
1. MIGRATE NAMESERVERS at Spaceship web UI:
   - Login: https://www.spaceship.com/account/login/
   - Domains → example.com → Nameservers
   - Replace <your-registrar-default-ns-1> / <your-registrar-default-ns-2> with:
       • {root_zone.get('name_servers', ['?','?'])[0]}
       • {root_zone.get('name_servers', ['?','?'])[1]}
   - Wait 5-30 minutes for NS propagation (CF will mark zone as 'active')

2. CREATE SUBDOMAIN ZONE 'users.example.com' at CF SUB dashboard:
   - Login to Cloudflare with the Admin@example.com account
   - Account ID: {SUB_ACCT}
   - Add Site → enter 'users.example.com' → select plan: Free
   - CF will detect it's a subdomain and show NS records to add at parent
   - The CF-assigned NS will appear; SAVE them
   - Then re-run: python3 scripts/22_stamp_all_subdomains.py
     (it will detect the new zone, configure DNS records, worker, email routing)
     (AND add NS delegation records in the parent zone)

3. VERIFY EMAIL ROUTING DESTINATION:
   - Check inbox for {EMAIL_DEST}
   - Click verification link from Cloudflare
   - Without verification, the catch-all rule will not forward emails

4. ENFORCE 2FA ON BOTH CF ACCOUNTS (security hardening per peer review I2):
   - CF MAIN: Profile → My Profile → Authentication → App-Only 2FA enforcement ON
   - CF SUB:  Same steps
   - This protects against password leaks (you already use account API tokens
     which is good — 2FA on the underlying user account is the foundation)
""")
