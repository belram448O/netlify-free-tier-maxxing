#!/usr/bin/env python3
"""03_mint_scoped_tokens.py — Mint scoped CF API tokens for each task.

Strategy: the cfat_ master token has Account API Tokens:Edit. Use it to mint:
  - root_zone_token   (CF MAIN): Zone:Edit, Zone:Read, DNS:Edit, Workers Scripts:Edit,
                                  Workers Routes:Edit, Email Routing:Edit, Email Routing Addresses:Edit,
                                  Workers KV:Edit (for future)
  - sub_zone_token    (CF SUB):  same permissions, scoped to CF SUB account

Each minted token is scoped to a single account. Saves tokens back to secrets.json
so subsequent scripts can use them.
"""
import json, pathlib, urllib.request, urllib.error, sys, time
PROJECT_ROOT = pathlib.Path(__file__).resolve().parent.parent

SECRETS = json.loads((PROJECT_ROOT / 'infra' / 'secrets.json').read_text())
STATE = json.loads((PROJECT_ROOT / 'infra' / 'state.json').read_text()) if (PROJECT_ROOT / 'infra' / 'state.json').exists() else {}
API = "https://api.cloudflare.com/client/v4"

def cf(method, path, token, body=None):
    url = f"{API}{path}"
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url, data=data, method=method)
    req.add_header("Authorization", f"Bearer {token}")
    if body is not None: req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            return r.status, json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read().decode() or "{}")

# Permission group names we need (verified against actual CF catalog — naming uses spaces, not colons)
NEEDED_PERM_NAMES = [
    "Zone Read",
    "Zone Write",                  # creates new zones
    "Zone Settings Read",
    "Zone Settings Write",
    "DNS Read",
    "DNS Write",
    "Workers Scripts Read",
    "Workers Scripts Write",
    "Workers Routes Read",
    "Workers Routes Write",
    "Email Routing Addresses Read",
    "Email Routing Addresses Write",
    "Email Routing Rules Read",
    "Email Routing Rules Write",
    "Email Security DMARC Reports Read",
    "Email Security DMARC Reports Write",
    "Workers KV Storage Read",
    "Workers KV Storage Write",
    "Workers R2 Storage Read",
    "Workers R2 Storage Write",
    "Pages Read",
    "Pages Write",
    "Account Settings Read",
]

def fetch_perm_catalog(master_token, account_id):
    """Fetch the permission group catalog for the account."""
    code, body = cf("GET", f"/accounts/{account_id}/tokens/permission_groups?audience=account", master_token)
    if code != 200:
        print(f"ERROR fetching permission catalog: {code} {body}")
        sys.exit(1)
    return body["result"]

def find_perm_ids(catalog, names):
    """Return list of {id, name} dicts for matching names."""
    by_name = {p["name"]: p for p in catalog}
    out = []
    missing = []
    for n in names:
        if n in by_name:
            out.append({"id": by_name[n]["id"]})
        else:
            missing.append(n)
    if missing:
        print(f"  WARN: missing permission groups: {missing}")
    return out

def mint_token(master_token, account_id, name, perm_ids):
    """Mint a scoped account API token."""
    body = {
        "name": name,
        "policies": [{
            "effect": "allow",
            "resources": {f"com.cloudflare.api.account.{account_id}": "*"},
            "permission_groups": perm_ids,
        }],
    }
    code, resp = cf("POST", f"/accounts/{account_id}/tokens", master_token, body)
    if code != 200 or not resp.get("success"):
        print(f"  ERROR minting {name}: {code} {resp}")
        sys.exit(1)
    return resp["result"]

def main():
    secrets_to_add = {}
    for label, master_key, acct_key, name_prefix in [
        ("root_zone_token", "cf_main_token", "cf_main_account_id", "example-root-ops"),
        ("sub_zone_token",  "cf_sub_token",  "cf_sub_account_id",  "example-sub-ops"),
    ]:
        master = SECRETS[master_key]
        acct   = SECRETS[acct_key]
        print(f"\n== Minting {label} for account {acct[:8]}… ==")
        catalog = fetch_perm_catalog(master, acct)
        print(f"  catalog: {len(catalog)} permission groups available")
        perm_ids = find_perm_ids(catalog, NEEDED_PERM_NAMES)
        print(f"  resolved {len(perm_ids)}/{len(NEEDED_PERM_NAMES)} permission groups")
        tok = mint_token(master, acct, name_prefix, perm_ids)
        print(f"  ✓ minted token id={tok['id']} name={tok['name']}")
        # The actual secret value is in the response under 'value'
        secrets_to_add[label] = tok.get("value")
        secrets_to_add[f"{label}_id"] = tok["id"]
        secrets_to_add[f"{label}_name"] = tok["name"]
        time.sleep(0.5)

    # Persist back to secrets.json
    SECRETS.update(secrets_to_add)
    (PROJECT_ROOT / 'infra' / 'secrets.json').write_text(json.dumps(SECRETS, indent=2, sort_keys=True))
    (PROJECT_ROOT / 'infra' / 'secrets.json').chmod(0o600)
    print(f"\n✓ Updated infra/secrets.json with minted scoped tokens")
    print(f"  root_zone_token: {secrets_to_add['root_zone_token'][:12]}…")
    print(f"  sub_zone_token:  {secrets_to_add['sub_zone_token'][:12]}…")

if __name__ == "__main__":
    main()
