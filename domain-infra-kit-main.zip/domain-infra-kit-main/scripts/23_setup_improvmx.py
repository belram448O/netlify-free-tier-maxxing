#!/usr/bin/env python3
"""23_setup_improvmx.py — Set up ImprovMX email forwarding for users.* and corp.*.

PREREQUISITE: User signs up at https://improvmx.com (free, no API signup) and
generates an API key at https://app.improvmx.com/account/api/.

Then save the key to secrets.json:
  "improvmx_api_key": "<your-key-here>"

Then run this script. It will:
  1. Add each subdomain to ImprovMX via POST /v3/domains
  2. Set up catch-all alias: *@<sub> → admin@example.com (configurable)
  3. Update the sub-zone's MX records to point to ImprovMX (replaces placeholder)
  4. Update SPF to include ImprovMX's SPF
  5. Trigger ImprovMX's MX verification via GET /v3/domains/<sub>/check

Free tier: 1 domain / 25 aliases / 500 emails per day. Plenty for our 2 subdomains
(users.* and corp.*).
"""
import json, pathlib, urllib.request, urllib.error, sys, base64
PROJECT_ROOT = pathlib.Path(__file__).resolve().parent.parent

SECRETS = json.loads((PROJECT_ROOT / 'infra' / 'secrets.json').read_text())
STATE = json.loads((PROJECT_ROOT / 'infra' / 'state.json').read_text())
NETLIFY_TOKEN = SECRETS['netlify_token']
API_IM = "https://api.improvmx.com/v3"

if 'improvmx_api_key' not in SECRETS or not SECRETS['improvmx_api_key']:
    print("""
✗ Missing improvmx_api_key in secrets.json

TO FIX:
  1. Sign up at https://improvmx.com (free, web-only)
  2. Generate API key at https://app.improvmx.com/account/api/
  3. Add to infra/secrets.json:
       "improvmx_api_key": "<your-key>"
  4. Re-run this script

This step cannot be fully automated — ImprovMX does not expose account-creation
via API. Signup is web-only (takes ~2 minutes).
""")
    sys.exit(1)

IM_KEY = SECRETS['improvmx_api_key']
IM_AUTH = base64.b64encode(f"api:{IM_KEY}".encode()).decode()

# Default destination for catch-all (override via env or secrets)
DEFAULT_DEST = SECRETS.get('improvmx_destination', 'admin@example.com')

# Subdomains that need email routing
EMAIL_SUBDOMAINS = [
    ("users", "admin+users@example.com"),
    ("corp",  "admin+corp@example.com"),
]

def im(method, path, body=None):
    url = f"{API_IM}{path}"
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url, data=data, method=method)
    req.add_header("Authorization", f"Basic {IM_AUTH}")
    if body is not None: req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            text = r.read().decode()
            if not text: return r.status, {}
            try: return r.status, json.loads(text)
            except: return r.status, {"_raw": text}
    except urllib.error.HTTPError as e:
        text = e.read().decode()
        try: return e.code, json.loads(text)
        except: return e.code, {"_raw": text}

def nl(method, path, body=None):
    url = f"https://api.netlify.com/api/v1{path}"
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url, data=data, method=method)
    req.add_header("Authorization", f"Bearer {NETLIFY_TOKEN}")
    if body is not None: req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            text = r.read().decode()
            if not text: return r.status, {}
            try: return r.status, json.loads(text)
            except: return r.status, {"_raw": text}
    except urllib.error.HTTPError as e:
        text = e.read().decode()
        try: return e.code, json.loads(text)
        except: return e.code, {"_raw": text}

def list_records(zone_id):
    code, body = nl("GET", f"/dns_zones/{zone_id}/dns_records")
    return body if isinstance(body, list) else []

def delete_record(zone_id, record_id):
    nl("DELETE", f"/dns_zones/{zone_id}/dns_records/{record_id}")

def add_or_update_record(zone_id, rtype, hostname, value, ttl=3600, priority=None):
    """Add a record; if same type+hostname exists, update its value."""
    recs = list_records(zone_id)
    existing = [r for r in recs if r.get("type") == rtype and r.get("hostname") == hostname]
    if existing:
        # Update first existing
        rid = existing[0]["id"]
        body = {"type": rtype, "hostname": hostname, "value": value, "ttl": ttl}
        if priority is not None: body["priority"] = priority
        code, resp = nl("PUT", f"/dns_zones/{zone_id}/dns_records/{rid}", body)
        return code, resp, "updated"
    else:
        body = {"type": rtype, "hostname": hostname, "value": value, "ttl": ttl}
        if priority is not None: body["priority"] = priority
        code, resp = nl("POST", f"/dns_zones/{zone_id}/dns_records", body)
        return code, resp, "created"

print("=" * 78)
print("IMPROVMX EMAIL FORWARDING SETUP")
print("=" * 78)
print(f"Default destination: {DEFAULT_DEST}")

for prefix, dest in EMAIL_SUBDOMAINS:
    sub = f"{prefix}.{SECRETS['domain']}"
    print(f"\n── {sub} → catch-all → {dest} ──")

    # Step 1: Add domain to ImprovMX
    code, body = im("POST", "/domains", {"domain": sub})
    if code == 200 and body.get("success"):
        print(f"  ✓ ImprovMX: added domain {sub}")
    elif code == 400 and "already" in str(body).lower():
        print(f"  ✓ ImprovMX: domain {sub} already added")
    else:
        print(f"  ✗ ImprovMX add domain: {code} {body}")
        continue

    # Step 2: Set catch-all alias
    code, body = im("POST", f"/domains/{sub}/aliases", {
        "alias": "*",
        "forward": dest,
    })
    if code == 200 and body.get("success"):
        print(f"  ✓ ImprovMX: catch-all *@{sub} → {dest}")
    else:
        # Maybe alias already exists; try to update via list+PUT
        code, body = im("GET", f"/domains/{sub}/aliases")
        aliases = body.get("aliases", []) if isinstance(body, dict) else []
        catchall = next((a for a in aliases if a.get("alias") == "*"), None)
        if catchall:
            print(f"  ✓ ImprovMX: catch-all already exists (id={catchall.get('id')})")

    # Step 3: Update Netlify DNS zone MX records to ImprovMX
    zone_id = STATE["subzones"][prefix]["id"]
    print(f"  -- Netlify DNS zone {zone_id}: replacing MX + SPF --")

    # Delete existing MX records (the placeholder A record has no MX, but we may have
    # inherited some). Also delete the old SPF (will re-add with ImprovMX include).
    recs = list_records(zone_id)
    for r in recs:
        if r.get("type") == "MX":
            delete_record(zone_id, r["id"])
            print(f"    deleted old MX: {r.get('value')}")
    # Update A record (keep at 192.0.2.1 — ImprovMX doesn't need a hosting target)
    # Update TXT SPF to include ImprovMX's SPF
    new_spf = "v=spf1 include:spf.improvmx.com ~all"
    code, resp, action = add_or_update_record(zone_id, "TXT", sub, new_spf)
    print(f"    ✓ {action} TXT {sub} → {new_spf}")
    # Add the two MX records
    add_or_update_record(zone_id, "MX", sub, "mx1.improvmx.com", priority=10)
    print(f"    ✓ MX {sub} → mx1.improvmx.com (prio 10)")
    add_or_update_record(zone_id, "MX", sub, "mx2.improvmx.com", priority=20)
    print(f"    ✓ MX {sub} → mx2.improvmx.com (prio 20)")

    # Step 4: Trigger verification
    code, body = im("GET", f"/domains/{sub}/check")
    if isinstance(body, dict):
        valid = body.get("valid", False)
        mx_status = body.get("mx", {})
        print(f"  ImprovMX check: valid={valid}, mx_status={mx_status}")
    print(f"  ✓ {sub} done.")

print("""
═══════════════════════════════════════════════════════════════════════════════
EMAIL FORWARDING LIVE
═══════════════════════════════════════════════════════════════════════════════

Email sent to ANY address at users.example.com or corp.example.com will now
forward to admin+users@example.com / admin+corp@example.com respectively.

Note: admin@example.com itself still needs CF Email Routing destination
verification (one-time, manual — click link in inbox).

To test:
  echo "test from $(whoami)" | mail -s "test" anything@users.example.com
""")
