#!/usr/bin/env python3
"""19_configure_netlify_subzone.py — Configure the Netlify DNS zone for users.example.com.

Steps:
  1. List existing Netlify DNS zones, find users.example.com
  2. Add DNS records (A, MX, TXT SPF/DMARC, CAA, CNAME) inside the sub-zone
  3. Add NS delegation records in CF MAIN root zone pointing to Netlify's NS1 servers

Idempotent: safe to re-run.
"""
import json, pathlib, urllib.request, urllib.error
PROJECT_ROOT = pathlib.Path(__file__).resolve().parent.parent

SECRETS = json.loads((PROJECT_ROOT / 'infra' / 'secrets.json').read_text())
STATE = json.loads((PROJECT_ROOT / 'infra' / 'state.json').read_text())
NETLIFY_TOKEN = SECRETS['netlify_token']
NETLIFY_ACCT  = SECRETS['netlify_account_id']
MAIN_TOKEN = SECRETS.get('root_zone_token') or SECRETS.get('cf_main_zone_scoped_token')
ROOT_ZONE_ID = STATE['root_zone']['id']
DOMAIN     = SECRETS['domain']
SUB_DOMAIN = "users.example.com"

API_NL = "https://api.netlify.com/api/v1"
API_CF = "https://api.cloudflare.com/client/v4"

def nl(method, path, body=None):
    url = f"{API_NL}{path}"
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url, data=data, method=method)
    req.add_header("Authorization", f"Bearer {NETLIFY_TOKEN}")
    if body is not None: req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            text = r.read().decode()
            if not text: return r.status, {}
            try: return r.status, json.loads(text)
            except: return r.status, {"_raw": text}
    except urllib.error.HTTPError as e:
        text = e.read().decode()
        try: return e.code, json.loads(text)
        except: return e.code, {"_raw": text}

def cf(method, path, token, body=None):
    url = f"{API_CF}{path}"
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url, data=data, method=method)
    req.add_header("Authorization", f"Bearer {token}")
    if body is not None: req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            text = r.read().decode()
            if not text: return r.status, {}
            try: return r.status, json.loads(text)
            except: return r.status, {"_raw": text}
    except urllib.error.HTTPError as e:
        text = e.read().decode()
        try: return e.code, json.loads(text)
        except: return e.code, {"_raw": text}

def ok(label, code, body):
    succ = (200 <= code < 300) and (not isinstance(body, dict) or body.get("errors") is None or not body.get("errors"))
    if succ:
        print(f"  ✓ {label}")
        return True
    errs = body.get("errors") if isinstance(body, dict) else None
    msg = ""
    if isinstance(errs, dict):
        msg = json.dumps(errs)[:200]
    elif isinstance(body, dict):
        msg = str(body.get("message", body))[:200]
    else:
        msg = str(body)[:200]
    print(f"  ✗ {label}  code={code}  err={msg}")
    return False

# ──────────────────────────────────────────────────────────────────────────────
# STEP 1: Find existing Netlify DNS zone for users.example.com (or create)
# ──────────────────────────────────────────────────────────────────────────────
print(f"== Step 1: Find/create Netlify DNS zone for {SUB_DOMAIN} ==")
code, body = nl("GET", "/dns_zones")
zones = body if isinstance(body, list) else []
existing = [z for z in zones if z.get("name") == SUB_DOMAIN]
if existing:
    zone = existing[0]
    print(f"  ✓ existing zone found: id={zone['id']}")
else:
    print(f"  not found — creating new zone…")
    code, body = nl("POST", "/dns_zones", {
        "name": SUB_DOMAIN,
        "account_id": NETLIFY_ACCT,
    })
    if code == 201:
        zone = body
        print(f"  ✓ created: id={zone['id']}")
    else:
        print(f"  ✗ create failed: {code} {body}")
        exit(1)

ZONE_ID = zone["id"]
NL_NS = zone.get("dns_servers", [])
print(f"  Netlify-assigned NS: {NL_NS}")

# ──────────────────────────────────────────────────────────────────────────────
# STEP 2: Add DNS records inside the sub-zone
# ──────────────────────────────────────────────────────────────────────────────
print(f"\n== Step 2: Add DNS records in {SUB_DOMAIN} Netlify zone ==")

def list_records(zone_id):
    code, body = nl("GET", f"/dns_zones/{zone_id}/dns_records")
    return body if isinstance(body, list) else []

def add_record(zone_id, rtype, hostname, value, ttl=3600, priority=None, flag=None, tag=None):
    recs = list_records(zone_id)
    # Idempotency check: match by type+hostname+value
    existing = [r for r in recs if r.get("type") == rtype and r.get("hostname") == hostname and r.get("value") == value]
    if existing:
        print(f"  skip: {rtype:6s} {hostname:30s} → {value} (already exists)")
        return
    body = {"type": rtype, "hostname": hostname, "value": value, "ttl": ttl}
    if priority is not None: body["priority"] = priority
    if flag is not None: body["flag"] = flag
    if tag is not None: body["tag"] = tag
    code, resp = nl("POST", f"/dns_zones/{zone_id}/dns_records", body)
    ok(f"create {rtype:6s} {hostname:30s} → {value}", code, resp)

# Apex A placeholder (will be replaced when we add Worker / Vercel / etc.)
add_record(ZONE_ID, "A", SUB_DOMAIN, "192.0.2.1")
# www.users CNAME → apex
add_record(ZONE_ID, "CNAME", f"www.{SUB_DOMAIN}", SUB_DOMAIN)
# SPF (Email Routing-like)
add_record(ZONE_ID, "TXT", SUB_DOMAIN, "v=spf1 include:_spf.mx.cloudflare.net ~all")
# DMARC
add_record(ZONE_ID, "TXT", f"_dmarc.{SUB_DOMAIN}", "v=DMARC1; p=quarantine; rua=mailto:admin@example.com; ruf=mailto:admin@example.com; pct=100; adkim=s; aspf=s")
# MTA-STS
add_record(ZONE_ID, "TXT", f"_mta-sts.{SUB_DOMAIN}", "v=STSv1; id=20260815T000000")
# CAA
add_record(ZONE_ID, "CAA", SUB_DOMAIN, "letsencrypt.org", flag=0, tag="issue")
add_record(ZONE_ID, "CAA", SUB_DOMAIN, "cloudflare.com", flag=0, tag="issue")

# ──────────────────────────────────────────────────────────────────────────────
# STEP 3: Add NS delegation records in CF MAIN root zone
# ──────────────────────────────────────────────────────────────────────────────
print(f"\n== Step 3: Add NS delegation in CF MAIN root zone ==")
# Get existing DNS records in root zone
code, body = cf("GET", f"/zones/{ROOT_ZONE_ID}/dns_records?per_page=200", MAIN_TOKEN)
root_recs = body.get("result", []) if isinstance(body, dict) else []
# Remove old NS records for users (if any)
old_ns = [r for r in root_recs if r["type"] == "NS" and r["name"] == f"users.{DOMAIN}"]
print(f"  found {len(old_ns)} existing NS records for users.{DOMAIN}")
for r in old_ns:
    if r["content"] not in NL_NS:
        cf("DELETE", f"/zones/{ROOT_ZONE_ID}/dns_records/{r['id']}", MAIN_TOKEN)
        print(f"    deleted stale NS: {r['content']}")

# Add Netlify NS records
for ns in NL_NS:
    already = any(r["type"] == "NS" and r["name"] == f"users.{DOMAIN}" and r["content"] == ns for r in root_recs)
    if already:
        print(f"  skip: NS {ns} already present")
    else:
        code, resp = cf("POST", f"/zones/{ROOT_ZONE_ID}/dns_records", MAIN_TOKEN, {
            "type": "NS", "name": f"users.{DOMAIN}", "content": ns, "ttl": 1, "proxied": False
        })
        ok(f"create NS users.{DOMAIN} → {ns}", code, resp)

# ──────────────────────────────────────────────────────────────────────────────
# Save state
# ──────────────────────────────────────────────────────────────────────────────
STATE["netlify_subzone"] = {
    "name": SUB_DOMAIN,
    "id": ZONE_ID,
    "account_id": NETLIFY_ACCT,
    "dns_servers": NL_NS,
    "ns_delegated_in_root_zone": True,
}
(PROJECT_ROOT / 'infra' / 'state.json').write_text(json.dumps(STATE, indent=2, sort_keys=True))
print(f"\n✓ State saved to infra/state.json")

# Final records list in Netlify sub-zone
print(f"\n== Final records in {SUB_DOMAIN} Netlify zone ==")
recs = list_records(ZONE_ID)
for r in sorted(recs, key=lambda x: (x.get("type", ""), x.get("hostname", ""))):
    print(f"  {r.get('type','?'):6s} {r.get('hostname','?'):40s} → {r.get('value','?')[:60]}")
print(f"  total: {len(recs)} records")
