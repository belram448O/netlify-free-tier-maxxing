#!/usr/bin/env python3
"""31_drift_check.py — Compare state.json to live CF + Netlify API state; report drift.

Run daily from GitHub Actions cron to catch:
- DNS records added/removed via CF dashboard (not via script)
- Netlify DNS zones added/removed manually
- Worker routes added/removed
- Email Routing disabled
- Sub-zone NS delegation broken

Exit codes:
  0 = no drift
  1 = drift detected (printed to stderr)
  2 = error fetching live state
"""
import json, pathlib, sys, urllib.request, urllib.error
PROJECT_ROOT = pathlib.Path(__file__).resolve().parent.parent

SECRETS = json.loads((PROJECT_ROOT / 'infra' / 'secrets.json').read_text())
STATE_PATH = PROJECT_ROOT / 'infra' / 'state.json'
STATE = json.loads(STATE_PATH.read_text()) if STATE_PATH.exists() else {}
API_CF = "https://api.cloudflare.com/client/v4"
API_NL = "https://api.netlify.com/api/v1"
CF_TOKEN = SECRETS.get('root_zone_token') or SECRETS.get('cf_main_zone_scoped_token')
NL_TOKEN = SECRETS['netlify_token']
DOMAIN = SECRETS['domain']

DRIFT = []

def cf(method, path):
    req = urllib.request.Request(f"{API_CF}{path}", method=method)
    req.add_header("Authorization", f"Bearer {CF_TOKEN}")
    try:
        with urllib.request.urlopen(req, timeout=20) as r:
            return r.status, json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read().decode() or "{}")

def nl(method, path):
    req = urllib.request.Request(f"{API_NL}{path}", method=method)
    req.add_header("Authorization", f"Bearer {NL_TOKEN}")
    try:
        with urllib.request.urlopen(req, timeout=20) as r:
            text = r.read().decode()
            return r.status, (json.loads(text) if text else [])
    except urllib.error.HTTPError as e:
        return e.code, []

def drift(label, expected, actual):
    if expected != actual:
        DRIFT.append((label, expected, actual))
        print(f"  ✗ DRIFT: {label}", file=sys.stderr)
        print(f"     expected: {expected}", file=sys.stderr)
        print(f"     actual:   {actual}", file=sys.stderr)

# ──────────────────────────────────────────────────────────────────────────────
# Check 1: CF root zone exists + status
# ──────────────────────────────────────────────────────────────────────────────
print("[1] CF root zone state")
if "root_zone" not in STATE:
    drift("state.root_zone", "exists in state.json", "missing")
else:
    code, body = cf("GET", f"/zones?name={DOMAIN}")
    zones = body.get("result", []) if isinstance(body, dict) else []
    if not zones:
        drift("CF root zone", f"zone for {DOMAIN}", "NOT FOUND in CF")
    else:
        z = zones[0]
        drift("CF root zone status", STATE["root_zone"].get("status"), z.get("status"))
        drift("CF root zone NS", sorted(STATE["root_zone"].get("name_servers", [])),
              sorted(z.get("name_servers", [])))

# ──────────────────────────────────────────────────────────────────────────────
# Check 2: CF root zone DNS records — count
# ──────────────────────────────────────────────────────────────────────────────
print("[2] CF root zone DNS records count")
if "root_zone" in STATE:
    code, body = cf("GET", f"/zones/{STATE['root_zone']['id']}/dns_records?per_page=200")
    live_recs = body.get("result", []) if isinstance(body, dict) else []
    # Just check the count — diff each record would be too noisy
    state_count = STATE.get("root_zone_records_count")
    live_count = len(live_recs)
    if state_count is None:
        # First run — record the count
        STATE["root_zone_records_count"] = live_count
        STATE_PATH.write_text(json.dumps(STATE, indent=2, sort_keys=True))
        print(f"  ℹ first run: recorded root zone records count = {live_count}")
    elif state_count != live_count:
        drift("CF root zone records count", state_count, live_count)

# ──────────────────────────────────────────────────────────────────────────────
# Check 3: Worker Routes (skip if state.root_worker.routes is missing — operator
# must run `make rebuild-state` first; the 06_configure_root_zone.py script doesn't
# fetch routes, only 00b_rebuild_state.py does)
# ──────────────────────────────────────────────────────────────────────────────
print("[3] CF Worker Routes")
if "root_worker" in STATE:
    state_routes = STATE["root_worker"].get("routes")
    if state_routes is None:
        print("  ⚠ SKIP: state.root_worker.routes missing — run `make rebuild-state` first")
    else:
        code, body = cf("GET", f"/zones/{STATE['root_zone']['id']}/workers/routes")
        if code != 200:
            print(f"  ✗ API error fetching routes: code={code} err={body}")
            sys.exit(2)
        live_routes = body.get("result", []) if isinstance(body, dict) else []
        state_patterns = sorted([r.get("pattern") for r in state_routes])
        live_patterns = sorted([r.get("pattern") for r in live_routes])
        drift("Worker Routes patterns", state_patterns, live_patterns)

# ──────────────────────────────────────────────────────────────────────────────
# Check 4: Email Routing status
# ──────────────────────────────────────────────────────────────────────────────
print("[4] Email Routing status")
code, body = cf("GET", f"/zones/{STATE['root_zone']['id']}/email/routing")
er_status = body.get("result", {}).get("status") if isinstance(body, dict) else None
state_er = STATE.get("root_email_routing", {})
state_status = "ready" if state_er.get("enabled") else "disabled"
if state_status == "ready" and er_status != "ready":
    drift("Email Routing status", state_status, er_status or "unknown")

# ──────────────────────────────────────────────────────────────────────────────
# Check 5: Netlify DNS zones — count + names
# ──────────────────────────────────────────────────────────────────────────────
print("[5] Netlify DNS zones")
code, body = nl("GET", "/dns_zones")
live_zones = body if isinstance(body, list) else []
live_zone_names = sorted([z.get("name") for z in live_zones])

state_zones = STATE.get("subzones", {})
state_zone_names = sorted([info["name"] for info in state_zones.values()])

# Live zones might be MORE than state (someone added a new one via dashboard)
# or FEWER (someone deleted). Both are drift.
if set(state_zone_names) != set(live_zone_names):
    state_only = set(state_zone_names) - set(live_zone_names)
    live_only = set(live_zone_names) - set(state_zone_names)
    msg = f"state_only={state_only}, live_only={live_only}"
    drift("Netlify zone names", state_zone_names, live_zone_names)
    print(f"    {msg}", file=sys.stderr)

# ──────────────────────────────────────────────────────────────────────────────
# Check 6: For each sub-zone, NS records in CF root zone
# ──────────────────────────────────────────────────────────────────────────────
print("[6] NS delegation for each sub-zone in CF root zone")
code, body = cf("GET", f"/zones/{STATE['root_zone']['id']}/dns_records?type=NS&per_page=100")
ns_recs = body.get("result", []) if isinstance(body, dict) else []
for prefix, info in state_zones.items():
    sub_name = info["name"]
    expected_ns = sorted(info.get("dns_servers", []))
    actual_ns = sorted([r["content"] for r in ns_recs if r["name"] == sub_name])
    drift(f"NS delegation for {sub_name}", expected_ns, actual_ns)

# ──────────────────────────────────────────────────────────────────────────────
# Summary
# ──────────────────────────────────────────────────────────────────────────────
print(f"\n=== DRIFT SUMMARY ===")
print(f"  total drifts: {len(DRIFT)}")
if DRIFT:
    print(f"\nDrift details:")
    for label, expected, actual in DRIFT:
        print(f"  ✗ {label}")
        print(f"     expected: {expected}")
        print(f"     actual:   {actual}")
    sys.exit(1)
else:
    print("  ✓ No drift detected — state.json matches live infra")
    sys.exit(0)
