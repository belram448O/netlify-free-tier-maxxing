#!/usr/bin/env python3
"""Dump the CF permission group catalog so we can find the right names/IDs."""
import json, pathlib, urllib.request, urllib.error
PROJECT_ROOT = pathlib.Path(__file__).resolve().parent.parent
SECRETS = json.loads((PROJECT_ROOT / 'infra' / 'secrets.json').read_text())
API = "https://api.cloudflare.com/client/v4"

def cf(method, path, token):
    req = urllib.request.Request(f"{API}{path}", method=method)
    req.add_header("Authorization", f"Bearer {token}")
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            return r.status, json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read().decode() or "{}")

for label, tok_key, acct_key in [
    ("MAIN", "cf_main_token", "cf_main_account_id"),
    ("SUB",  "cf_sub_token",  "cf_sub_account_id"),
]:
    tok = SECRETS[tok_key]
    acct = SECRETS[acct_key]
    print(f"\n=== {label} (acct {acct[:8]}…) ===")
    code, body = cf("GET", f"/accounts/{acct}/tokens/permission_groups?audience=account", tok)
    if code != 200:
        print(f"err: {code} {body}"); continue
    groups = body["result"]
    # Filter to groups we likely care about
    keywords = ["zone", "dns", "worker", "email", "kv", "r2", "page", "snippet", "rules"]
    relevant = [g for g in groups if any(k in g["name"].lower() for k in keywords)]
    print(f"  total: {len(groups)}, relevant: {len(relevant)}")
    for g in sorted(relevant, key=lambda x: x["name"]):
        print(f"    {g['id']}  {g['name']}")
    # Also dump to file
    out = PROJECT_ROOT / 'infra' / 'perms_{label.lower()}.json'
    out.write_text(json.dumps(groups, indent=2))
    print(f"  → dumped to {out}")
