// Old v1 handler — should capture console.log per docs
export async function handler(event, context) {
  console.log('HELLO_FROM_V1_FUNCTION');
  console.log(`request_id=${context?.awsRequestId}`);
  console.log(`timestamp=${new Date().toISOString()}`);
  console.log('==========DATA_START==========');
  console.log(JSON.stringify({test: 'data', value: 42, ts: new Date().toISOString()}));
  console.log('==========DATA_END==========');
  console.error('THIS_IS_AN_ERROR_LOG');
  return {
    statusCode: 200,
    body: JSON.stringify({ok: true, format: 'v1'}),
  };
}
